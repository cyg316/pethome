# -*- coding: utf-8 -*-
{
    'name': 'Payment Alipay',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Payment Acquirers',
    'sequence': 350,
    'summary': 'Payment Acquirer: Alipay Implementation',
    'description': """
        Alipay Payment Acquirer for Odoo.
        This module implements the Alipay payment gateway.
    """,
    'author': "OdooMaster PetHome Technology",
    'website': "https://www.catlover.cn",
    'depends': ['payment'],
    'data': [
        'security/ir.model.access.csv',
        'security/data.xml',
        'views/templates.xml',
        'views/views.xml',
        'data/payment_provider_data.xml',
    ],
    'demo': [],
    'images': [
        'static/src/image/alipay.png',
    ],
    'installable': True,
    'application': True,
    'post_init_hook': 'post_init_hook',
    'uninstall_hook': 'uninstall_hook',
    'license': 'LGPL-3',
}
