#!/bin/bash
# 支付宝支付模块依赖安装脚本
# 用于在Odoo服务器上安装所有必要的Python依赖
# 使用方法: sudo bash install_dependencies.sh

# 检查是否以root权限运行
if [ "$(id -u)" != "0" ]; then
   echo "此脚本需要以root权限运行" 1>&2
   echo "请使用 sudo bash install_dependencies.sh" 1>&2
   exit 1
fi

# 获取Python可执行文件路径
PYTHON_CMD=$(which python3)
if [ -z "$PYTHON_CMD" ]; then
    echo "找不到Python3，尝试使用python命令..."
    PYTHON_CMD=$(which python)
    if [ -z "$PYTHON_CMD" ]; then
        echo "找不到Python，请确保Python已安装" 1>&2
        exit 1
    fi
fi

# 获取pip可执行文件路径
PIP_CMD=$(which pip3)
if [ -z "$PIP_CMD" ]; then
    echo "找不到pip3，尝试使用pip命令..."
    PIP_CMD=$(which pip)
    if [ -z "$PIP_CMD" ]; then
        echo "找不到pip，请确保pip已安装" 1>&2
        exit 1
    fi
fi

echo "使用Python: $PYTHON_CMD"
echo "使用pip: $PIP_CMD"

# 显示Python和pip版本
$PYTHON_CMD --version
$PIP_CMD --version

# 安装支付宝支付模块所需的依赖
echo "正在安装支付宝支付模块依赖..."
$PIP_CMD install --upgrade pip
$PIP_CMD install rsa>=4.8 pycryptodome>=3.17.0 pyasn1>=0.4.8

# 验证安装结果
echo "正在验证依赖安装状态..."
$PYTHON_CMD -c "
try:
    import rsa
    print('rsa安装成功')
except ImportError:
    print('rsa安装失败!')

try:
    from Crypto.PublicKey import RSA
    from Crypto.Signature import pkcs1_15
    from Crypto.Hash import SHA256
    print('pycryptodome安装成功')
except ImportError:
    print('pycryptodome安装失败!')

try:
    import pyasn1
    print('pyasn1安装成功')
except ImportError:
    print('pyasn1安装失败!')
"

echo ""
echo "安装完成。如果有任何依赖显示安装失败，请手动解决安装问题。"
echo "提示: 您可能需要重启Odoo服务以使新安装的依赖生效。"
echo "可以使用命令: sudo service odoo restart" 