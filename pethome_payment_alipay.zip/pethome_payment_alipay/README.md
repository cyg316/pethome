# 支付宝支付模块 - Odoo 18.0

这是一个适用于Odoo 18.0的支付宝支付模块，支持RSA2签名算法。

## 依赖

此模块依赖以下Python库：

- `rsa` >= 4.8
- `pycryptodome` >= 3.17.0
- `pyasn1` >= 0.4.8

## 安装指南

### 1. 安装依赖

在安装模块前，需确保服务器已安装所需的Python依赖。

**自动安装**：

```bash
sudo bash install_dependencies.sh
```

**手动安装**：

```bash
sudo pip3 install rsa>=4.8 pycryptodome>=3.17.0 pyasn1>=0.4.8
```

### 2. 安装模块

在Odoo管理后台，进入应用程序菜单，搜索"支付宝"并安装此模块。

## 配置说明

### 基本配置

1. 进入Odoo后台，导航至"网站 > 配置 > 支付方式"
2. 启用"支付宝"支付提供商
3. 配置以下项目:
   - Alipay AppId - 支付宝应用ID
   - Merchant Private Key - 商户私钥
   - Alipay Public Key - 支付宝公钥
   - Sign Type - 签名类型(选择RSA2)

### 沙盒测试环境

1. 保持支付提供商状态为"测试"
2. 配置以下项目:
   - Alipay SandBox AddId - 沙盒应用ID
   - Alipay SandBox Secret - 沙盒商户私钥
   - Alipay SandBox Public Key - 沙盒支付宝公钥
   - SandBox Sign Type - 沙盒签名类型(选择RSA2)

## 安全说明

- 本模块使用RSA2签名算法，保证支付请求的安全性和完整性
- 如果缺少RSA相关依赖，模块会回退到使用简单签名方法，但安全性将大幅降低
- 请确保在生产环境中安装了所有必要的依赖

## 常见问题

### 问题："ModuleNotFoundError: No module named 'rsa'"

这表示服务器缺少rsa库。请运行安装脚本或手动安装依赖。

### 问题："invalid-signature-type-said-interface"

这表示签名类型配置有误。请确保:
1. 在支付宝平台配置的签名方式为RSA2
2. 在Odoo中配置的签名类型也为RSA2
3. 服务器已正确安装RSA相关依赖库

### 问题："支付宝签名验证失败"

可能的原因:
1. 公钥或私钥格式不正确
2. 签名算法不匹配
3. 缺少相关依赖

请重新检查密钥格式和依赖安装情况。

## 支持


————————————————————————————————————————————————————————————

当需要为运行在Docker中的Odoo 18安装Python依赖时，您需要在Docker容器内部安装这些包。以下是详细步骤：
1. 查找并进入Docker容器
首先，找到Odoo容器的ID或名称：
docker ps | grep odoo
然后进入容器内部的shell：
docker exec -it [容器ID或名称] bash
2. 安装依赖
在容器内部，安装必要的Python依赖：
pip3 install rsa>=4.8 pycryptodome>=3.17.0 pyasn1>=0.4.8
如果pip3命令不可用，尝试使用pip：
pip install rsa>=4.8 pycryptodome>=3.17.0 pyasn1>=0.4.8
3. 验证安装
确认依赖已正确安装：
python3 -c "import rsa; from Crypto.PublicKey import RSA; import pyasn1; print('所有依赖已成功安装')"
4. 重启Odoo服务
在容器内部重启Odoo服务，或者从外部重启整个容器：
# 从容器外部
docker restart [容器ID或名称]
5. 持久化安装（可选但推荐）
Docker容器重启后可能会丢失安装的依赖，有两种解决方案：
方案A：创建自定义Dockerfile
1、创建新的Dockerfile，基于您当前的Odoo镜像：
FROM [您当前的odoo镜像]

USER root
RUN pip3 install rsa>=4.8 pycryptodome>=3.17.0 pyasn1>=0.4.8
USER odoo
2、构建新镜像并使用它来替换当前容器。

————————————————————————————————————————————————————————
在Docker容器中，默认的odoo用户没有安装Python包的权限。
解决方法如下：
方法1：切换到root用户再安装
# 退出当前容器
exit

# 重新进入容器，但使用root用户
docker exec -it -u root 5d26f45ebb5e bash

# 安装依赖包
pip3 install rsa>=4.8 pycryptodome>=3.17.0 pyasn1>=0.4.8

# 验证安装
python3 -c "import rsa; from Crypto.PublicKey import RSA; import pyasn1; print('所有依赖已成功安装')"

# 退出容器
exit

# 重启容器使更改生效
docker restart 5d26f45ebb5e
方法2：如果上述命令还是有问题，尝试这种写法
错误可能是由于shell解释 >= 符号导致的。尝试用引号包裹包版本：
docker exec -it -u root 5d26f45ebb5e bash
pip3 install "rsa>=4.8" "pycryptodome>=3.17.0" "pyasn1>=0.4.8"

——————————————————————————————————————————————————————————————
Python 3.12"外部管理环境"的限制，这是Debian/Ubuntu新版本的安全特性。您有以下几种解决方案：
方案1：使用系统包管理器安装
apt update
apt install python3-rsa python3-pycryptodome python3-pyasn1
方案2：使用虚拟环境安装
# 安装必要的包
apt update
apt install python3-venv

# 创建虚拟环境
python3 -m venv /opt/odoo_venv

# 在虚拟环境中安装依赖
/opt/odoo_venv/bin/pip install "rsa>=4.8" "pycryptodome>=3.17.0" "pyasn1>=0.4.8"

# 修改Odoo启动脚本使用虚拟环境
# 这需要编辑Odoo的启动脚本，将Python路径指向虚拟环境

方案3：使用--break-system-packages标志（不推荐，但最快）
pip3 install --break-system-packages "rsa>=4.8" "pycryptodome>=3.17.0" "pyasn1>=0.4.8"

方案4：创建新的Docker镜像（最佳持久解决方案）
# 在宿主机上创建Dockerfile
FROM odoo:18 (或当前使用的镜像)

USER root
RUN apt update && apt install -y python3-rsa python3-pycryptodome python3-pyasn1
USER odoo