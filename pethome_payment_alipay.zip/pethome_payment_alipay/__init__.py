# -*- coding: utf-8 -*-

import logging
_logger = logging.getLogger(__name__)

_logger.info("正在加载支付宝支付模块...")

from . import controllers
from . import models

from odoo.addons.payment import setup_provider, reset_payment_provider

def post_init_hook(*args, **kwargs):
    """
    初始化钩子 - 在模块安装完成后运行
    此函数设计为可同时兼容不同版本的Odoo调用方式
    """
    _logger.info("执行支付宝支付模块安装后钩子...")
    
    try:
        # 确定env对象
        env = None
        if args and len(args) == 1 and hasattr(args[0], 'registry'):
            # Odoo 18调用：post_init_hook(env)
            env = args[0]
            _logger.info("使用Odoo 18风格的参数调用(单个env参数)")
        elif args and len(args) >= 2:
            # Odoo 17调用：post_init_hook(cr, registry)
            cr, registry = args[0], args[1]
            _logger.info("使用Odoo 17风格的参数调用(cr, registry)")
            from odoo.api import Environment
            with Environment.manage():
                env = Environment(cr, registry)
        
        if not env:
            _logger.error("无法确定环境，可能是不兼容的Odoo版本调用")
            return
            
        # 调用激活支付方法的函数
        provider_model = env['payment.provider'].sudo()
        provider_model._register_payment_methods()
        provider_model._activate_payment_methods()
        
        _logger.info("支付宝支付模块安装完成")
    except Exception as e:
        _logger.error(f"支付宝支付模块安装钩子执行失败: {str(e)}")

def uninstall_hook(cr, registry):
    """
    卸载钩子 - 在模块卸载时运行
    """
    _logger.info("执行支付宝支付模块卸载钩子...")
    
    try:
        from odoo.api import Environment
        with Environment.manage():
            env = Environment(cr, registry)
            reset_payment_provider(env, 'alipay')
        
        _logger.info("支付宝支付模块卸载完成")
    except Exception as e:
        _logger.error(f"支付宝支付模块卸载钩子执行失败: {str(e)}")