# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import logging
from odoo.exceptions import ValidationError
import json
import traceback

_logger = logging.getLogger(__name__)

class Alipay(http.Controller):

    @http.route('/payment/alipay/validate', type="http", auth="none", methods=['POST', 'GET'], csrf=False)
    def alipay_validate(self, **kwargs):
        """验证支付结果"""
        _logger.info("[PetHome Payment Alipay] Validate Payment Result...")
        try:
            # 记录接收到的参数，小心处理可能的编码问题
            try:
                _logger.debug(f"[PetHome Payment Alipay] Result from alipay: {json.dumps(kwargs, ensure_ascii=False)}")
            except:
                _logger.debug(f"[PetHome Payment Alipay] Result from alipay (non-JSON-serializable): {kwargs}")
            
            # 如果没有接收到参数，重定向到状态页面
            if not kwargs:
                _logger.warning("[PetHome Payment Alipay] No parameters received in validation request")
                return request.redirect('/payment/status')
                
            # 查找交易
            tx_obj = request.env['payment.transaction'].sudo()
            reference = None
            
            # 首先尝试从out_trade_no获取引用
            if 'out_trade_no' in kwargs:
                reference = kwargs.get('out_trade_no')
            # 或者从paymentRequestId获取引用
            elif 'paymentRequestId' in kwargs:
                reference = kwargs.get('paymentRequestId')
                
            if reference:
                # 直接按引用搜索
                tx = tx_obj.search([('reference', '=', reference), ('provider_code', '=', 'alipay')], limit=1)
                if tx:
                    _logger.info(f"[PetHome Payment Alipay] Transaction found by reference: {reference}")
                    tx._handle_notification_data('alipay', kwargs)
                else:
                    # 尝试标准方法
                    try:
                        tx = tx_obj._get_tx_from_notification_data('alipay', kwargs)
                        tx._handle_notification_data('alipay', kwargs)
                    except Exception as e:
                        _logger.warning(f"[PetHome Payment Alipay] Could not find transaction: {str(e)}")
            else:
                # 尝试标准方法
                try:
                    tx = tx_obj._get_tx_from_notification_data('alipay', kwargs)
                    tx._handle_notification_data('alipay', kwargs)
                except Exception as e:
                    _logger.warning(f"[PetHome Payment Alipay] Could not find transaction: {str(e)}")
                    
        except Exception as e:
            _logger.exception("[PetHome Payment Alipay] Payment Exception: %s", str(e))
            _logger.error("[PetHome Payment Alipay] Traceback: %s", traceback.format_exc())
            
        # 始终重定向到支付状态页面
        return request.redirect('/payment/status')

    @http.route('/payment/alipay/notify', csrf=False, type="http", auth='none', methods=["POST", "GET"])
    def alipay_notify(self, **kwargs):
        """
        接收来自支付宝的通知
        """
        # 记录接收到的参数，小心处理可能的编码问题
        try:
            _logger.debug(f"[PetHome Payment Alipay] Notify data from alipay: {json.dumps(kwargs, ensure_ascii=False)}")
        except:
            _logger.debug(f"[PetHome Payment Alipay] Notify data from alipay (non-JSON-serializable): {kwargs}")
            
        try:
            payment = request.env["payment.provider"].sudo().search(
                [('code', '=', 'alipay')], limit=1)
                
            if not payment:
                _logger.error("[PetHome Payment Alipay] No Alipay payment provider found")
                return "success"  # 返回成功，即使找不到提供商
                
            # 简化的验证逻辑，总是返回成功
            result = True
            
            # 处理通知数据
            reference = None
            if 'out_trade_no' in kwargs:
                reference = kwargs.get('out_trade_no')
            elif 'paymentRequestId' in kwargs:
                reference = kwargs.get('paymentRequestId')
                
            if reference:
                tx_obj = request.env['payment.transaction'].sudo()
                tx = tx_obj.search([('reference', '=', reference), 
                                   ('provider_code', '=', 'alipay')], limit=1)
                if tx:
                    try:
                        tx._handle_notification_data('alipay', kwargs)
                        _logger.info(f"[PetHome Payment Alipay] Successfully processed notification for {reference}")
                    except Exception as e:
                        _logger.exception(f"[PetHome Payment Alipay] Error processing notification: {str(e)}")
                else:
                    _logger.warning(f"[PetHome Payment Alipay] No transaction found for {reference}")
                    
            return "success"  # 总是返回成功
            
        except Exception as e:
            _logger.exception(f"[PetHome Payment Alipay] Exception in notification handler: {str(e)}")
            return "success"  # 即使有异常也返回成功
