# Part of Odoo. See LICENSE file for full copyright and licensing details.

# ISO 4217 codes of currencies supported by PayPal
# See https://developer.paypal.com/docs/reports/reference/paypal-supported-currencies/.
# Last seen on: 22 September 2022.

# -*- coding: utf-8 -*-

# 支持的货币
SUPPORTED_CURRENCIES = ['CNY', 'USD', 'EUR', 'HKD', 'GBP', 'JPY']

# 默认支付方式
DEFAULT_PAYMENT_METHODS_CODES = [
    'alipay',
]

PAYMENT_STATUS_MAPPING = {
    'pending': ('WAIT_BUYER_PAY',),
    'done': ('TRADE_SUCCESS','TRADE_FINISHED'),
    'cancel': ('TRADE_CLOSED'),
}