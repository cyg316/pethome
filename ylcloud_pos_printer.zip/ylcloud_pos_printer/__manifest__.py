# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': '易联云POS打印机插件',
    'version': '1.2',
    'summary': '集成易联云打印机的Odoo POS插件',
    'description': '该插件允许Odoo POS与易联云打印机集成，实现打印功能。',
    'author': 'petshop',
    'website': 'https://www.catlover.cn',
    'category': 'Point of Sale',
    'depends': ['point_of_sale'],
    'external_dependencies': {
        'python': ['yly-python-sdk'],
    },
    'data': [
        'security/ir.model.access.csv',
        'data/ir_sequence_data.xml',
        'views/pos_config_views.xml',
    ],
    'assets': {
        'point_of_sale.assets': [
            'ylcloud_pos_printer/static/src/js/pos_printer.js',
            'ylcloud_pos_printer/static/src/js/printer_service.js',
            'ylcloud_pos_printer/static/src/js/payment_hooks.js',
            'ylcloud_pos_printer/static/src/js/direct_print.js',
            'ylcloud_pos_printer/static/src/js/debug_helper.js',
            'ylcloud_pos_printer/static/src/xml/pos_printer.xml',
            'ylcloud_pos_printer/static/src/xml/button.xml',
            'ylcloud_pos_printer/static/src/scss/pos_printer.scss',
        ],
    },
    'images': [
        'static/description/icon.png',
       
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
