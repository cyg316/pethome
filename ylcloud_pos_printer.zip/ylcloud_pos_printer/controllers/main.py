# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging
import json
import traceback
from odoo import http, _
from odoo.http import request
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)

class YLCloudController(http.Controller):
    @http.route('/ylcloud/print', type='json', auth='user')
    def print_receipt(self, printer_id, content, order_id=None):
        """接收来自POS前端的打印请求"""
        _logger.info('接收到打印请求: printer_id=%s, order_id=%s', printer_id, order_id)
        
        try:
            if not printer_id:
                error_msg = '缺少打印机ID'
                _logger.error(error_msg)
                return {'success': False, 'error': error_msg}
                
            if not content:
                error_msg = '缺少打印内容'
                _logger.error(error_msg)
                return {'success': False, 'error': error_msg}
            
            _logger.info('开始调用打印服务')
            result = request.env['ylcloud.service'].sudo().print_receipt(
                printer_id=printer_id, 
                content=content, 
                order_id=order_id
            )
            _logger.info('打印服务返回结果: %s', json.dumps(result) if result else 'None')
            
            # 检查结果中是否有错误
            is_success = result and isinstance(result, dict) and result.get('error', -1) == 0
            
            if is_success:
                _logger.info('打印请求成功')
                return {'success': True, 'result': result}
            else:
                error_msg = result.get('error_description', '未知错误') if result and isinstance(result, dict) else '未知错误'
                _logger.warning('打印请求返回错误: %s', error_msg)
                return {'success': False, 'error': error_msg, 'result': result}
                
        except Exception as e:
            error_msg = '打印过程发生异常: %s' % str(e)
            _logger.error(error_msg)
            _logger.error(traceback.format_exc())
            return {'success': False, 'error': str(e)}
    
    @http.route('/ylcloud/status', type='json', auth='user')
    def get_print_status(self, printer_id, order_id):
        """查询打印状态"""
        _logger.info('接收到状态查询请求: printer_id=%s, order_id=%s', printer_id, order_id)
        
        try:
            if not printer_id:
                error_msg = '缺少打印机ID'
                _logger.error(error_msg)
                return {'success': False, 'error': error_msg}
                
            if not order_id:
                error_msg = '缺少订单ID'
                _logger.error(error_msg)
                return {'success': False, 'error': error_msg}
            
            _logger.info('开始调用状态查询服务')
            result = request.env['ylcloud.service'].sudo().get_print_status(printer_id, order_id)
            _logger.info('状态查询服务返回结果: %s', json.dumps(result) if result else 'None')
            
            # 检查结果中是否有错误
            is_success = result and isinstance(result, dict) and result.get('error', -1) == 0
            
            if is_success:
                _logger.info('状态查询成功')
                return {'success': True, 'result': result}
            else:
                error_msg = result.get('error_description', '未知错误') if result and isinstance(result, dict) else '未知错误'
                _logger.warning('状态查询返回错误: %s', error_msg)
                return {'success': False, 'error': error_msg, 'result': result}
                
        except Exception as e:
            error_msg = '状态查询过程发生异常: %s' % str(e)
            _logger.error(error_msg)
            _logger.error(traceback.format_exc())
            return {'success': False, 'error': str(e)}
    
    @http.route('/ylcloud/test_connection', type='json', auth='user')
    def test_connection(self, printer_id):
        """测试打印机连接"""
        _logger.info('接收到连接测试请求: printer_id=%s', printer_id)
        
        try:
            if not printer_id:
                error_msg = '缺少打印机ID'
                _logger.error(error_msg)
                return {'success': False, 'error': error_msg}
                
            _logger.info('开始查询打印机')
            printer = request.env['ylcloud.printer'].sudo().browse(printer_id)
            if not printer.exists():
                error_msg = '打印机不存在: ID=%s' % printer_id
                _logger.error(error_msg)
                return {'success': False, 'error': error_msg}
            
            _logger.info('开始测试打印机连接: %s', printer.name)
            # 调用测试连接方法
            test_result = printer.test_connection()
            _logger.info('测试连接结果: %s', json.dumps(test_result) if test_result else 'Success')
            
            return {'success': True}
        except Exception as e:
            error_msg = '测试连接过程发生异常: %s' % str(e)
            _logger.error(error_msg)
            _logger.error(traceback.format_exc())
            return {'success': False, 'error': str(e)} 