#!/bin/bash
# 易联云SDK安装脚本

echo "开始安装易联云打印机SDK..."

# 首先尝试使用pip安装
echo "尝试使用pip安装易联云SDK..."
pip install yly-python-sdk

# 检查安装结果
if python -c "import Lib.Config.config; print('SDK安装成功')" 2>/dev/null; then
    echo "易联云SDK安装成功！"
    exit 0
fi

# 如果pip安装失败，尝试从本地解压安装
echo "pip安装失败，尝试从本地安装..."

# 检查SDK压缩包是否存在
SDK_ZIP="yly-python-sdk-master.zip"
if [ -f "$SDK_ZIP" ]; then
    echo "发现SDK压缩包，开始解压..."
    unzip -o "$SDK_ZIP" -d .
    
    # 创建模块软链接
    echo "创建SDK模块软链接..."
    current_dir=$(pwd)
    ln -sf "$current_dir/yly-python-sdk-master" "$current_dir/Lib"
    
    # 检查模块是否可用
    if python -c "import Lib.Config.config; print('SDK本地安装成功')" 2>/dev/null; then
        echo "易联云SDK本地安装成功！"
        exit 0
    else
        echo "本地SDK安装失败，请检查SDK文件是否完整。"
    fi
else
    echo "未找到SDK压缩包 $SDK_ZIP"
    echo "请从 https://github.com/yilianyun/yly-python-sdk 下载SDK并放置在当前目录。"
fi

echo "易联云SDK安装失败。请尝试手动安装："
echo "1. 确保Python环境正确配置"
echo "2. 运行: pip install yly-python-sdk"
echo "3. 或访问 https://github.com/yilianyun/yly-python-sdk 下载SDK"

exit 1 