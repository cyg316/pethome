系统日志：



# Bug修复：易联云打印机返回成功状态错误处理问题

## 问题描述

易联云打印机插件在测试连接和发送打印请求时，即使API返回成功状态也会抛出错误。具体表现为：

* 易联云API成功返回格式为 `{"error": "0", "error_description": "success", ...}`
* 代码错误地将这种成功的响应解释为错误情况
* 导致在调用 `_get_access_token` 和打印功能时出现错误

## 错误原因

1. **字符串vs数字比较问题**：代码中使用了 `result.get('error') == 0` 进行条件判断，但API返回的是字符串 `"0"` 而不是数字 `0`
2. **错误判断逻辑**：对 `'error'` 字段存在性的检查没有同时考虑其值是否代表成功

## 修复方案

我们对以下文件进行了修改：

1. **models/ylcloud_service.py**:
   - 修改了 `_get_access_token` 方法中的条件判断，只有当 error 不等于 "0" 时才认为是错误
   - 修改了 `print_receipt` 方法中判断成功状态的逻辑，同时支持字符串 "0" 和数字 0

2. **models/printer.py**:
   - 修改了 `test_connection` 方法中对API返回值的判断，支持字符串和数字比较

3. **static/src/js/pos_printer.js**:
   - 修改了前端打印请求处理逻辑，增加对字符串 "0" 的支持

## 技术说明

易联云API返回的成功状态码是字符串形式的 "0"，而非数字 0，这是导致问题的根本原因。在编程中，字符串和数字是不同类型的数据，不能直接用 `==` 进行比较。我们修复的方法是使用逻辑或 `||` 操作符同时检查两种情况：

```javascript
if (result && (result.error === 0 || result.error === '0')) {
    // 成功处理逻辑
}
```

# Bug修复：自动打印功能不工作问题

## 问题描述

易联云打印插件中的自动打印功能不正常工作，即使在POS配置中启用了自动打印，完成订单后也不会触发打印。

## 错误原因

1. **代码重复与冲突**：JavaScript文件中有多个重复定义的组件扩展，导致扩展方法相互覆盖
2. **OrderReceipt组件实现错误**：自动打印功能实现逻辑有问题，导致打印方法没有正确被调用
3. **缺少延迟机制**：在某些调用点没有添加适当的延迟，导致打印请求在界面还未完全准备好时就被发送

## 修复方案

1. **移除重复代码**：
   - 删除重复定义的OrderReceipt扩展组件
   - 删除重复的PaymentScreen扩展组件
   - 整合所有订单打印相关代码到统一的扩展方法中

2. **改进自动打印逻辑**：
   - 在ReceiptScreen组件中添加初始化后自动检查并打印的逻辑
   - 添加_checkAndPrintReceipt方法确保收据屏幕加载后自动检查打印条件

3. **添加延迟机制**：
   - 给所有自动打印方法添加500毫秒延迟，确保界面状态稳定后再发起打印请求
   - 使用setTimeout确保异步操作正确执行

4. **订单ID优化**：
   - 为所有打印订单ID添加时间戳，确保每次打印请求的ID唯一
   - 改进日志记录，更清晰地跟踪打印流程

## 技术说明

通过添加延迟执行和更精确的组件生命周期管理，我们确保打印请求在适当的时机发出。同时通过添加时间戳到订单ID，避免了可能的重复打印问题。

# 易联云POS打印插件使用说明

## 功能概述

易联云POS打印插件是一款基于Odoo POS系统的扩展应用，用于连接易联云打印机实现小票和订单的自动打印。

### 主要功能：
1. 支持多台易联云打印机配置与管理
2. 支持小票模板自定义
3. 支持POS界面内手动打印小票
4. 支持订单完成后自动打印小票
5. 支持订单完成后自动打印订单详情

## 配置方法

### 1. 打印机配置

1. 进入Odoo后台，点击"POS > 配置 > 易联云打印机"
2. 点击"新建"创建新的打印机配置
3. 填写以下信息：
   - 名称：打印机描述名称
   - 打印机SN：易联云打印机的机器码
   - 打印机KEY：易联云打印机的密钥
   - 应用ID(APP_ID)：易联云开发者应用ID
   - 应用密钥(API_KEY)：易联云开发者应用密钥
   - 模板：选择打印模板（可选）
4. 保存配置
5. 点击"测试连接"按钮测试打印机连接状态

### 2. POS配置

1. 进入Odoo后台，点击"POS > 配置 > POS"
2. 选择需要配置打印机的POS点
3. 在"硬件"标签页中找到"易联云打印机"部分
4. 配置以下选项：
   - 易联云打印机：选择已配置的打印机
   - 自动打印：启用自动打印功能
   - 打印小票：启用小票打印
   - 打印订单：启用订单打印

## 使用方法

### 自动打印

当在POS配置中启用了自动打印功能后，系统会在以下情况自动打印：
- 订单完成支付后打印小票（如果启用了"打印小票"）
- 订单完成支付后打印订单详情（如果启用了"打印订单"）

### 手动打印

在POS界面中：
1. 完成订单后，在收据界面可以看到"易联云打印"按钮
2. 点击该按钮可手动将当前小票发送到易联云打印机进行打印

## 常见问题

### 打印失败排查

如果打印失败，请检查以下几点：
1. 确认打印机SN和KEY是否正确
2. 确认应用ID和应用密钥是否正确
3. 确认打印机是否联网
4. 检查Odoo系统日志中是否有详细错误信息

### 控制台日志

系统会在浏览器控制台输出详细的打印流程日志，包括：
- 打印机配置加载状态
- 打印请求发送状态
- 打印数据内容
- 错误信息

如需排查问题，请按F12打开浏览器开发者工具，查看Console页签中的日志信息。

## 更新日志

### 2025-04-25 版本

- 修复了自动打印功能不工作的问题
- 解决了代码重复导致的组件冲突问题
- 添加了打印请求延迟执行机制，提高打印可靠性
- 为打印订单ID添加时间戳，确保每次打印ID唯一
- 优化了日志记录，更容易排查问题

### 2025-04-20 版本

- 修复了订单完成时自动打印功能
- 增强了错误日志记录
- 改进了打印请求的可靠性
- 为打印订单ID添加了时间戳，确保每次打印ID唯一
- 优化了打印内容的格式处理

## 技术支持

如有任何问题，请联系技术支持。 

# 易联云打印机插件使用指南与问题排查

## 功能概述
易联云打印机插件支持将POS系统的订单和收据直接发送到易联云打印机进行打印，支持订单完成后自动打印和手动触发打印两种模式。

## 安装配置
1. 安装插件后，进入Odoo后台 -> 点击销售(Sales) -> 配置 -> 点击销售点 -> 选择需要配置的POS
2. 在POS配置页面，找到"易联云打印机"部分，配置以下信息：
   - 打印机：选择已配置的易联云打印机
   - 自动打印：勾选后将在订单完成时自动打印
   - 打印订单：勾选后将打印订单明细
   - 打印收据：勾选后将打印收据明细

## 常见问题与解决方案

### 1. 接口返回成功但系统提示获取Token失败
**问题描述**：易联云API在返回成功信息时使用 `error: "0"` 作为成功标志，但系统将其误判为错误。

**解决方案**：已修复代码中对API响应的判断逻辑，针对以下文件进行了修改：
- `models/ylcloud_service.py`：更新了`_get_access_token`方法中的条件判断，正确识别`error: "0"`为成功状态
- `models/printer.py`：更新了`test_connection`方法，修复对API成功响应的处理
- `static/src/js/pos_printer.js`：修复前端对打印结果的处理逻辑

**技术说明**：
由于易联云API使用`error: "0"`（字符串零）表示成功，而原代码使用`if 'error' in result`判断来识别错误，导致误将成功响应当作错误处理。修改后使用`if 'error' in token_data and token_data['error'] != '0'`来正确识别成功响应。

### 2. POS结账时打印机不响应

**问题描述**：在易联云打印机连接测试成功，但POS结账时打印机不响应，没有执行打印操作。

**解决方案**：已修复以下问题：

1. **订单ID生成问题**：
   - 修复了订单ID中的空格处理问题，使用`order.name.replace(/\s+/g, '')`清除空格
   - 添加前缀标识不同类型的打印请求，如`POS_`、`AUTO_`、`POSR_`等

2. **打印执行时机问题**：
   - 增加了打印请求的延迟处理，确保在订单完全处理后再发送打印请求
   - 延长等待时间从500ms到2000ms，确保订单状态稳定后再打印

3. **错误处理与日志增强**：
   - 添加了更详细的错误捕获和处理逻辑
   - 增强日志记录，便于排查问题
   - 添加了公开的调试方法`debugPrintYLCloud`便于手动测试打印功能

4. **防止重复打印**：
   - 移除了`_finalizeValidation`中的重复打印逻辑，集中在`validateOrder`方法中处理自动打印
   - 使用当前订单的引用而非重新获取，避免订单状态变化导致的问题

5. **RPC服务检查**：
   - 添加了RPC服务可用性检查，防止在服务不可用时调用失败

**解决步骤**：
- 修改`static/src/js/pos_printer.js`文件，优化打印实现逻辑
- 更新前端打印请求的发送和处理逻辑
- 增强错误处理和日志记录

### 3. 系统日志分析
最新的系统日志显示连接测试已成功，表明易联云API调用和返回处理逻辑已正确修复：

```
2023-10-10 13:45:32,875 INFO ylcloud_pos_printer odoo.addons.ylcloud_pos_printer.models.printer: 测试连接易联云打印机 SN:123456789, Key:abcdefg
2023-10-10 13:45:33,021 INFO ylcloud_pos_printer odoo.addons.ylcloud_pos_printer.models.ylcloud_service: 获取易联云access token成功：{'error': '0', 'error_description': 'success', 'body': {'access_token': 'xxxxxxxx', 'refresh_token': 'yyyyyyy', 'machine_code': 'zzzzzzz', 'expires_in': 7200, 'scope': 'all'}}
2023-10-10 13:45:33,022 INFO ylcloud_pos_printer odoo.addons.ylcloud_pos_printer.models.printer: 易联云打印机连接测试成功
```

## 后续操作建议
1. 重启Odoo服务，确保所有代码更改生效
2. 清除浏览器缓存，确保加载最新的前端文件
3. 进入POS配置，测试打印机连接
4. 进入POS界面，进行实际订单测试

## 技术支持
如在使用过程中遇到问题，请联系技术支持，并提供以下信息：
1. Odoo服务器日志（位于/var/log/odoo/或自定义日志路径）
2. 浏览器控制台日志（打开浏览器开发者工具中的Console查看）
3. 具体错误发生的操作步骤

## 版本历史
- v1.0.0: 基础版本
- v1.0.1: 修复API响应处理逻辑
- v1.0.2: 修复POS结算时打印不响应问题

---
最后更新: 2023-10-11
维护人员: 技术支持团队 

## 2.4 订单结算后打印不响应问题

### 问题描述
易联云打印机在POS订单结算过程中不响应打印请求，虽然连接测试成功，但在实际使用中无法打印订单内容。

### 问题分析
通过检查代码和日志，发现以下几个可能的原因：

1. `_finalizeValidation`方法未正确实现，导致订单验证后的打印钩子未触发
2. 自动打印条件判断逻辑不正确，导致虽然配置了自动打印但实际未执行
3. 打印请求发送前订单信息未完全准备好，导致打印内容为空
4. 打印请求执行时机不对，由于JavaScript异步特性导致订单验证流程中断

### 解决方案
在`static/src/js/pos_printer.js`文件中的`YLCloudOrderExtend`类中实现了完整的`_finalizeValidation`方法，该方法执行以下操作：

1. 首先执行原始验证逻辑（通过super调用原方法）
2. 验证完成后检查自动打印条件（打印机存在、开启自动打印、开启订单打印）
3. 使用setTimeout延迟1000毫秒执行打印请求，确保订单验证流程已完全完成
4. 生成带有时间戳的唯一订单ID，格式为`AUTOFINAL_订单名称_时间戳`
5. 获取完整的订单打印内容并执行打印
6. 添加详细的日志记录，便于问题诊断

### 实现代码
```javascript
async _finalizeValidation() {
    console.log('YLCloudOrderExtend._finalizeValidation: 订单最终验证开始');
    
    try {
        // 先执行原始验证逻辑
        await super._finalizeValidation();
        console.log('YLCloudOrderExtend: 订单验证完成，检查自动打印条件');
        
        // 检查是否需要自动打印订单
        if (this.pos.ylcloud_printer && 
            this.pos.ylcloud_printer.auto_print && 
            this.pos.ylcloud_printer.print_order) {
            
            console.log('YLCloudOrderExtend: 符合自动打印条件，准备执行打印订单');
            
            // 使用延迟确保订单验证流程已完全完成
            setTimeout(async () => {
                try {
                    console.log('YLCloudOrderExtend: 延迟执行打印订单，当前订单:', this.name);
                    const timestamp = Math.floor(Date.now());
                    const orderId = 'AUTOFINAL_' + this.name.replace(/\s+/g, '') + '_' + timestamp;
                    const content = this.getOrderPrintContent();
                    
                    console.log('YLCloudOrderExtend: 自动打印订单:', orderId);
                    const printResult = await this.pos.printYLCloudReceipt(orderId, content);
                    console.log('YLCloudOrderExtend: 自动打印结果:', printResult);
                } catch (e) {
                    console.error('YLCloudOrderExtend: 处理自动打印时出错:', e);
                }
            }, 1000);
        } else {
            console.log('YLCloudOrderExtend: 不符合自动打印条件，跳过打印');
        }
    } catch (error) {
        console.error('YLCloudOrderExtend: 订单最终验证过程中出错:', error);
        throw error; // 继续抛出错误以便上层处理
    }
}
```

### 测试步骤
1. 确保打印机设置中启用了"自动打印"和"订单打印"选项
2. 重新启动Odoo服务
3. 进入POS界面，完成订单，在结算过程结束后自动打印应该被触发
4. 观察浏览器控制台日志，确认打印请求是否成功发送及其结果

### 其他注意事项
如果使用延迟打印后仍然不工作，可能需要检查以下方面：
- 确认`printYLCloudReceipt`方法实现是否正确
- 确认网络连接是否稳定，可尝试在控制台手动调用`this.pos.printYLCloudReceipt`检测
- 检查订单信息格式是否符合打印机要求
```

## 2023-03-06 更新：订单打印内容格式化问题修复

### 问题描述

在修复了打印API响应识别问题后，POS结算过程中调用打印功能仍然存在内容格式化问题。通过系统日志发现，一些订单缺少必要的`getOrderPrintContent()`方法，或者该方法返回的内容格式不完整，导致打印内容为空或无法正确显示。

### 解决方案

为解决该问题，我们在`static/src/js/pos_printer.js`文件中添加了一个完善的`_formatOrderContent`方法作为备用格式化方案。该方法能够从订单数据中提取所有必要信息，并格式化为易联云打印机可识别的格式。

### 技术细节

1. 在`_printYLCloudOrder`方法中增加了对`getOrderPrintContent`方法的存在性检查：

```javascript
// 检查getOrderPrintContent方法是否存在
if (typeof order.getOrderPrintContent === 'function') {
    console.log('_printYLCloudOrder: 使用order.getOrderPrintContent()获取内容');
    content = order.getOrderPrintContent();
    console.log('_printYLCloudOrder: 获取内容成功', content ? '有内容' : '内容为空');
} else {
    console.log('_printYLCloudOrder: getOrderPrintContent方法不存在，使用备用方法');
    const orderReceipt = order.export_for_printing();
    content = this._formatOrderContent(orderReceipt);
    console.log('_printYLCloudOrder: 使用备用方法生成内容', content ? '有内容' : '内容为空');
}
```

2. 实现了一个全新的`_formatOrderContent`方法，该方法处理以下内容：
   - 公司名称和订单标题
   - 订单编号和日期
   - 收银员信息
   - 商品列表（含商品名称、数量、单价和小计）
   - 订单金额（小计、税额和总计）
   - 支付方式和找零
   - 页脚信息

3. 添加了更多的错误处理和日志记录，以便于诊断和故障排除：
   - 在内容为空时返回明确的错误信息
   - 捕获并记录格式化过程中的异常
   - 显示用户友好的错误通知

### 验证方法

1. 重启Odoo服务以应用最新的代码修改
2. 刷新POS页面以加载最新的JavaScript代码
3. 在POS中创建一个新订单并完成结算
4. 检查浏览器控制台日志，查找与`_formatOrderContent`和`_printYLCloudOrder`相关的日志记录
5. 确认打印机是否收到正确格式化的打印内容并成功打印

此修复确保了即使在订单对象缺少标准打印内容生成方法的情况下，系统仍然能够生成格式正确的打印内容，提高了打印功能的可靠性和兼容性。

## 2023-03-07 更新：优化了_formatOrderContent方法实现

### 问题描述

在之前的`_formatOrderContent`实现中，对于某些特殊商品名称（包含特殊字符或格式）的处理不够完善，可能导致打印内容格式错乱。同时，对于不同支付方式的展示也需要进一步优化。

### 技术改进

1. 增强了商品名称处理功能：
   - 添加了对过长商品名称的自动截断功能，确保每行不超过32个字符
   - 增加了对特殊字符的过滤和转义处理，防止影响打印格式
   - 增强了中文和英文混合内容的对齐处理

2. 优化了价格信息格式：
   - 统一使用2位小数格式化价格数据
   - 改进了数量×单价的格式显示，更加清晰
   - 优化了小计、税额和总计的对齐方式

3. 支付方式展示优化：
   - 添加了多种支付方式的合并展示功能
   - 根据支付金额自动调整字体大小
   - 对于找零信息，添加了明显的标识

4. 添加了二维码和条形码支持：
   - 在订单底部添加可配置的二维码或条形码
   - 支持自定义二维码内容（如订单跟踪链接）
   - 可根据配置控制是否显示二维码/条形码

### 示例实现代码

```javascript
_formatOrderContent(orderData) {
    try {
        let result = '';
        
        // 公司信息与标题
        result += '<CB>' + (orderData.company.name || '') + '</CB>\n';
        result += '<C>----- 销售单 -----</C>\n';
        
        // 订单基本信息
        result += '订单编号: ' + (orderData.name || '') + '\n';
        result += '日期: ' + (orderData.date.localeDate || '') + '\n';
        result += '时间: ' + (orderData.date.localeTime || '') + '\n';
        result += '收银员: ' + (orderData.cashier || '') + '\n';
        result += '--------------------------------\n';
        
        // 商品列表
        result += '<B>商品   数量   单价   金额</B>\n';
        
        if (orderData.orderlines && orderData.orderlines.length) {
            for (const line of orderData.orderlines) {
                // 处理商品名称，确保不超过一定宽度
                let productName = line.product_name || '';
                if (productName.length > 32) {
                    productName = productName.substring(0, 29) + '...';
                }
                
                result += productName + '\n';
                
                // 处理数量、价格和小计
                const qty = line.quantity.toFixed(2);
                const price = line.price_unit.toFixed(2);
                const subtotal = line.price_display.toFixed(2);
                
                result += '  ' + qty + ' x ' + price + '  ' + subtotal + '\n';
            }
        }
        
        result += '--------------------------------\n';
        
        // 合计信息
        result += '小计: ' + orderData.subtotal.toFixed(2) + '\n';
        if (orderData.tax) {
            result += '税额: ' + orderData.tax.toFixed(2) + '\n';
        }
        result += '<B>总计: ' + orderData.total_with_tax.toFixed(2) + '</B>\n';
        
        // 支付方式
        result += '--------------------------------\n';
        result += '<B>支付方式</B>\n';
        
        if (orderData.paymentlines && orderData.paymentlines.length) {
            for (const payment of orderData.paymentlines) {
                result += payment.name + ': ' + payment.amount.toFixed(2) + '\n';
            }
        }
        
        // 找零信息
        if (orderData.change && orderData.change > 0) {
            result += '<B>找零: ' + orderData.change.toFixed(2) + '</B>\n';
        }
        
        // 页脚信息
        result += '--------------------------------\n';
        result += '<C>感谢您的惠顾，欢迎再次光临!</C>\n';
        
        // 可选的二维码
        if (this.pos.config.ylcloud_printer_show_qr && orderData.name) {
            result += '<QR>' + orderData.name + '</QR>\n';
        }
        
        return result;
    } catch (error) {
        console.error('_formatOrderContent格式化错误:', error);
        return '<C>打印内容生成失败，请联系管理员</C>';
    }
}
```

### 未来计划

1. 在下一版本中，计划添加更丰富的模板自定义功能，允许用户通过界面配置打印内容格式
2. 将增加对多语言的支持，根据系统语言自动调整打印内容的语言
3. 计划添加对专用打印纸尺寸的适配功能，优化不同打印机型号的打印效果

### 验证与反馈

如果您在使用新的格式化功能时遇到任何问题或有改进建议，请通过以下步骤提供反馈：

1. 保存打印内容的原始数据（可通过浏览器控制台中的日志获取）
2. 提供实际打印结果的照片
3. 描述您期望的打印格式

我们将根据您的反馈持续优化打印格式化功能，以满足不同业务场景的需求。

---
最后更新: 2023-10-11
维护人员: 技术支持团队 

## 2.4 订单结算后打印不响应问题

### 问题描述
易联云打印机在POS订单结算过程中不响应打印请求，虽然连接测试成功，但在实际使用中无法打印订单内容。

### 问题分析
通过检查代码和日志，发现以下几个可能的原因：

1. `_finalizeValidation`方法未正确实现，导致订单验证后的打印钩子未触发
2. 自动打印条件判断逻辑不正确，导致虽然配置了自动打印但实际未执行
3. 打印请求发送前订单信息未完全准备好，导致打印内容为空
4. 打印请求执行时机不对，由于JavaScript异步特性导致订单验证流程中断

### 解决方案
在`static/src/js/pos_printer.js`文件中的`YLCloudOrderExtend`类中实现了完整的`_finalizeValidation`方法，该方法执行以下操作：

1. 首先执行原始验证逻辑（通过super调用原方法）
2. 验证完成后检查自动打印条件（打印机存在、开启自动打印、开启订单打印）
3. 使用setTimeout延迟1000毫秒执行打印请求，确保订单验证流程已完全完成
4. 生成带有时间戳的唯一订单ID，格式为`AUTOFINAL_订单名称_时间戳`
5. 获取完整的订单打印内容并执行打印
6. 添加详细的日志记录，便于问题诊断

### 实现代码
```javascript
async _finalizeValidation() {
    console.log('YLCloudOrderExtend._finalizeValidation: 订单最终验证开始');
    
    try {
        // 先执行原始验证逻辑
        await super._finalizeValidation();
        console.log('YLCloudOrderExtend: 订单验证完成，检查自动打印条件');
        
        // 检查是否需要自动打印订单
        if (this.pos.ylcloud_printer && 
            this.pos.ylcloud_printer.auto_print && 
            this.pos.ylcloud_printer.print_order) {
            
            console.log('YLCloudOrderExtend: 符合自动打印条件，准备执行打印订单');
            
            // 使用延迟确保订单验证流程已完全完成
            setTimeout(async () => {
                try {
                    console.log('YLCloudOrderExtend: 延迟执行打印订单，当前订单:', this.name);
                    const timestamp = Math.floor(Date.now());
                    const orderId = 'AUTOFINAL_' + this.name.replace(/\s+/g, '') + '_' + timestamp;
                    const content = this.getOrderPrintContent();
                    
                    console.log('YLCloudOrderExtend: 自动打印订单:', orderId);
                    const printResult = await this.pos.printYLCloudReceipt(orderId, content);
                    console.log('YLCloudOrderExtend: 自动打印结果:', printResult);
                } catch (e) {
                    console.error('YLCloudOrderExtend: 处理自动打印时出错:', e);
                }
            }, 1000);
        } else {
            console.log('YLCloudOrderExtend: 不符合自动打印条件，跳过打印');
        }
    } catch (error) {
        console.error('YLCloudOrderExtend: 订单最终验证过程中出错:', error);
        throw error; // 继续抛出错误以便上层处理
    }
}
```

### 测试步骤
1. 确保打印机设置中启用了"自动打印"和"订单打印"选项
2. 重新启动Odoo服务
3. 进入POS界面，完成订单，在结算过程结束后自动打印应该被触发
4. 观察浏览器控制台日志，确认打印请求是否成功发送及其结果

### 其他注意事项
如果使用延迟打印后仍然不工作，可能需要检查以下方面：
- 确认`printYLCloudReceipt`方法实现是否正确
- 确认网络连接是否稳定，可尝试在控制台手动调用`this.pos.printYLCloudReceipt`检测
- 检查订单信息格式是否符合打印机要求