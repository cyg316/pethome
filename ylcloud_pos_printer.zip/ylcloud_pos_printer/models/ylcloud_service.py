# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import json
import base64
import logging
import traceback
import requests
import importlib.util
import sys
import os
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from odoo.tools import html2plaintext

_logger = logging.getLogger(__name__)

# 全局变量，用于跟踪SDK导入状态
_ylcloud_sdk_imported = False
_ylcloud_sdk_import_error = None

# 尝试不同的导入方式
try:
    # 方式1: 直接导入
    from Lib.Config.config import Config
    from Lib.Oauth.oauth import Oauth
    from Lib.Protocol.rpc_client import RpcClient
    from Lib.Api.yly_print import YlyPrint
    _ylcloud_sdk_imported = True
    _logger.info('易联云SDK导入成功 (直接导入)')
except ImportError as e1:
    _logger.warning('直接导入易联云SDK失败: %s', str(e1))
    try:
        # 方式2: 尝试从当前模块目录导入
        module_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        sdk_path = os.path.join(module_path, 'yly-python-sdk-master')
        
        if os.path.exists(sdk_path):
            _logger.info('发现SDK路径: %s', sdk_path)
            sys.path.append(sdk_path)
            
            from Lib.Config.config import Config
            from Lib.Oauth.oauth import Oauth
            from Lib.Protocol.rpc_client import RpcClient
            from Lib.Api.yly_print import YlyPrint
            _ylcloud_sdk_imported = True
            _logger.info('易联云SDK从模块目录导入成功')
        else:
            _logger.warning('未在模块目录找到SDK: %s', sdk_path)
            _ylcloud_sdk_import_error = f"未找到SDK路径: {sdk_path}"
    except ImportError as e2:
        _logger.error('从模块目录导入易联云SDK失败: %s', str(e2))
        _ylcloud_sdk_import_error = f"从模块目录导入失败: {str(e2)}"
except Exception as e:
    _logger.error('导入易联云SDK时发生未知错误: %s', str(e))
    _logger.error(traceback.format_exc())
    _ylcloud_sdk_import_error = f"导入发生未知错误: {str(e)}"

if not _ylcloud_sdk_imported:
    _logger.error('未能导入易联云SDK，请确保已正确安装SDK')
    _logger.error('导入错误: %s', _ylcloud_sdk_import_error)
    _logger.error('请运行安装脚本: sh install_sdk.sh 或手动安装: pip install yly-python-sdk')

class YLCloudService(models.AbstractModel):
    _name = 'ylcloud.service'
    _description = '易联云服务接口'

    @api.model
    def _get_access_token(self, printer):
        """获取易联云API访问令牌"""
        if not _ylcloud_sdk_imported:
            error_msg = '未能导入易联云SDK，请确保已安装: pip install yly-python-sdk'
            if _ylcloud_sdk_import_error:
                error_msg += f"\n导入错误: {_ylcloud_sdk_import_error}"
            _logger.error(error_msg)
            raise UserError(_(error_msg))
        
        try:
            _logger.info('正在获取易联云访问令牌，应用ID: %s', printer.app_id)
            config = Config(printer.app_id, printer.api_key)
            oauth_client = Oauth(config)
            token_data = oauth_client.get_token()
            _logger.info('获取访问令牌结果: %s', json.dumps(token_data))
            
            if 'error' in token_data and token_data['error'] != '0':
                error_msg = '获取易联云访问令牌失败: %s' % token_data.get('error_description', '未知错误')
                _logger.error(error_msg)
                raise UserError(_(error_msg))
            
            if not token_data.get('body') or not token_data['body'].get('access_token'):
                error_msg = '获取易联云访问令牌失败: 返回数据格式错误'
                _logger.error('%s, 返回数据: %s', error_msg, json.dumps(token_data))
                raise UserError(_(error_msg))
            
            _logger.info('成功获取易联云访问令牌: %s', token_data['body']['access_token'][:10] + '...')
            return token_data['body']['access_token']
        except Exception as e:
            error_msg = '获取易联云访问令牌失败: %s' % str(e)
            _logger.error(error_msg)
            _logger.error(traceback.format_exc())
            raise UserError(_(error_msg))

    @api.model
    def _get_print_client(self, printer):
        """获取打印客户端"""
        try:
            _logger.info('获取打印客户端，打印机: %s (SN: %s)', printer.name, printer.printer_sn)
            access_token = self._get_access_token(printer)
            config = Config(printer.app_id, printer.api_key)
            rpc_client = RpcClient(config, access_token)
            print_client = YlyPrint(rpc_client)
            _logger.info('成功创建打印客户端对象')
            return print_client
        except Exception as e:
            _logger.error('获取打印客户端失败: %s', str(e))
            _logger.error(traceback.format_exc())
            raise

    @api.model
    def print_receipt(self, printer_id, content, order_id=None):
        """打印小票
        :param printer_id: 打印机ID
        :param content: 打印内容
        :param order_id: 订单ID，用于跟踪打印任务
        :return: 打印结果
        """
        _logger.info('收到打印请求: 打印机ID=%s, 订单ID=%s', printer_id, order_id)
        
        # 记录历史的回滚标志
        history_created = False
        history_id = False
        
        printer = self.env['ylcloud.printer'].browse(printer_id)
        if not printer:
            error_msg = '打印机不存在: ID=%s' % printer_id
            _logger.error(error_msg)
            raise UserError(_(error_msg))
        
        try:
            # 处理打印内容
            if not content:
                error_msg = '打印内容不能为空'
                _logger.error(error_msg)
                raise UserError(_(error_msg))
            
            # 如果是HTML内容，转换为纯文本
            if content.startswith('<'):
                _logger.info('转换HTML内容为纯文本')
                content = html2plaintext(content)
            
            # 记录打印请求内容
            _logger.info('打印内容: %s', content[:200] + '...' if len(content) > 200 else content)
            
            # 生成订单号
            if not order_id:
                order_id = self.env['ir.sequence'].next_by_code('ylcloud.print.order') or 'PO%s' % fields.Datetime.now().strftime('%Y%m%d%H%M%S')
                _logger.info('生成订单号: %s', order_id)
            
            # 先创建一条打印历史记录，状态为等待打印
            history = self.env['ylcloud.print.history'].create({
                'printer_id': printer.id,
                'content': content,
                'order_id': order_id,
                'status': 'waiting',
                'message': '正在发送打印请求...',
            })
            history_created = True
            history_id = history.id
            _logger.info('创建打印历史记录: ID=%s', history.id)
            
            # 获取打印服务
            _logger.info('获取打印服务客户端')
            print_service = self._get_print_client(printer)
            
            # 调用打印接口
            _logger.info('调用易联云打印接口: printer_sn=%s, order_id=%s', printer.printer_sn, order_id)
            result = print_service.index(printer.printer_sn, content, order_id)
            _logger.info('打印接口返回结果: %s', json.dumps(result))
            
            # 更新打印结果
            if result:
                status = 'success' if result.get('error') == 0 or result.get('error') == '0' else 'failed'
                message = result.get('error_description', '打印成功') if status == 'success' else result.get('error_description', '未知错误')
                
                if history_created:
                    history.write({
                        'status': status,
                        'message': message,
                    })
                    _logger.info('更新打印历史状态: %s, 消息: %s', status, message)
            
            return result
        except Exception as e:
            error_msg = '打印失败: %s' % str(e)
            _logger.error(error_msg)
            _logger.error(traceback.format_exc())
            
            # 更新或创建打印历史记录
            if history_created and history_id:
                self.env['ylcloud.print.history'].browse(history_id).write({
                    'status': 'failed',
                    'message': str(e),
                })
                _logger.info('更新打印历史为失败状态')
            else:
                try:
                    self.env['ylcloud.print.history'].create({
                        'printer_id': printer.id,
                        'content': content,
                        'order_id': order_id or '',
                        'status': 'failed',
                        'message': str(e),
                    })
                    _logger.info('创建失败的打印历史记录')
                except Exception as e2:
                    _logger.error('创建打印历史记录失败: %s', str(e2))
            
            raise UserError(_(error_msg))

    @api.model
    def get_print_status(self, printer_id, order_id):
        """查询打印状态
        :param printer_id: 打印机ID
        :param order_id: 订单ID
        :return: 打印状态
        """
        _logger.info('查询打印状态: 打印机ID=%s, 订单ID=%s', printer_id, order_id)
        
        printer = self.env['ylcloud.printer'].browse(printer_id)
        if not printer:
            error_msg = '打印机不存在: ID=%s' % printer_id
            _logger.error(error_msg)
            raise UserError(_(error_msg))
        
        try:
            # 获取打印服务
            print_service = self._get_print_client(printer)
            
            # 调用查询接口
            _logger.info('调用状态查询接口: printer_sn=%s, order_id=%s', printer.printer_sn, order_id)
            result = print_service.status(printer.printer_sn, order_id)
            _logger.info('状态查询返回结果: %s', json.dumps(result))
            
            return result
        except Exception as e:
            error_msg = '查询打印状态失败: %s' % str(e)
            _logger.error(error_msg)
            _logger.error(traceback.format_exc())
            raise UserError(_(error_msg)) 