# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)

class YLCloudPrinter(models.Model):
    _name = 'ylcloud.printer'
    _description = '易联云打印机'

    name = fields.Char(string='打印机名称', required=True)
    printer_sn = fields.Char(string='打印机SN', required=True, help='打印机机器码，从易联云后台获取')
    printer_key = fields.Char(string='打印机密钥', required=True, help='打印机秘钥，从易联云后台获取')
    app_id = fields.Char(string='应用ID', required=True, help='易联云开发者中心后台应用中心获取')
    api_key = fields.Char(string='API密钥', required=True, help='易联云开发者中心后台应用中心获取')
    active = fields.Boolean(string='激活', default=True)
    company_id = fields.Many2one('res.company', string='公司', default=lambda self: self.env.company)
    template = fields.Text(string='打印模板', help='打印内容模板，可使用HTML格式')
    
    _sql_constraints = [
        ('printer_sn_uniq', 'unique(printer_sn, company_id)', '打印机SN在同一公司内必须唯一!')
    ]
    
    @api.constrains('printer_sn', 'printer_key', 'app_id', 'api_key')
    def _check_ylcloud_credentials(self):
        for printer in self:
            if not printer.printer_sn or not printer.printer_key or not printer.app_id or not printer.api_key:
                raise UserError(_('打印机SN、密钥、应用ID和API密钥不能为空!'))
    
    def test_connection(self):
        """测试与易联云打印机的连接"""
        self.ensure_one()
        try:
            # 实际测试与易联云的连接
            service = self.env['ylcloud.service']
            test_content = "\n测试打印\n\n易联云打印机连接测试\n\n打印时间：%s\n\n" % fields.Datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            # 尝试获取访问令牌和打印客户端
            print_client = service._get_print_client(self)
            
            # 打印测试消息
            test_order_id = 'TEST_%s' % fields.Datetime.now().strftime('%Y%m%d%H%M%S')
            result = print_client.index(self.printer_sn, test_content, test_order_id)
            
            _logger.info('打印机连接测试结果: %s', result)
            
            if result and (result.get('error') == 0 or result.get('error') == '0'):
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('连接测试'),
                        'message': _('成功连接到易联云打印机: %s，已发送测试打印内容') % self.name,
                        'sticky': False,
                        'type': 'success',
                    }
                }
            else:
                error_msg = result.get('error_description', '未知错误')
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('连接测试'),
                        'message': _('连接失败: %s') % error_msg,
                        'sticky': False,
                        'type': 'danger',
                    }
                }
        except Exception as e:
            _logger.error('易联云打印机连接测试失败: %s', str(e))
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('连接测试'),
                    'message': _('连接失败: %s') % str(e),
                    'sticky': False,
                    'type': 'danger',
                }
            }