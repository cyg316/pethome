# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import printer
from . import pos_config
from . import ylcloud_service
from . import print_history