# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _

class PosConfig(models.Model):
    _inherit = 'pos.config'

    ylcloud_printer_id = fields.Many2one('ylcloud.printer', string='易联云打印机')
    ylcloud_auto_print = fields.Boolean(string='自动打印', default=True, help='下单后自动打印小票')
    ylcloud_print_order = fields.Boolean(string='打印订单', default=True, help='打印订单详情')
    ylcloud_print_receipt = fields.Boolean(string='打印收据', default=True, help='打印收据')
    ylcloud_receipt_template = fields.Text(string='收据模板', help='自定义收据模板内容')
    
    def _get_ylcloud_printer_data(self):
        """获取易联云打印机数据，供POS前端使用"""
        self.ensure_one()
        if not self.ylcloud_printer_id:
            return False
            
        return {
            'id': self.ylcloud_printer_id.id,
            'name': self.ylcloud_printer_id.name,
            'auto_print': self.ylcloud_auto_print,
            'print_order': self.ylcloud_print_order,
            'print_receipt': self.ylcloud_print_receipt,
        }

class PosOrder(models.Model):
    _inherit = 'pos.order'
    
    ylcloud_print_count = fields.Integer(string='打印次数', default=0, readonly=True, copy=False)
    ylcloud_print_ids = fields.One2many('ylcloud.print.history', 'pos_order_id', string='打印记录', readonly=True)
    
    def action_print_receipt(self):
        """打印小票"""
        self.ensure_one()
        if not self.config_id.ylcloud_printer_id:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('打印错误'),
                    'message': _('未配置易联云打印机'),
                    'sticky': False,
                    'type': 'warning',
                }
            }
            
        # 生成打印内容
        content = self._generate_receipt_content()
        
        # 发送打印请求
        try:
            result = self.env['ylcloud.service'].print_receipt(
                self.config_id.ylcloud_printer_id.id,
                content,
                'POS%s' % self.name
            )
            
            # 更新打印次数
            self.ylcloud_print_count += 1
            
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('打印请求已发送'),
                    'message': _('小票打印请求已发送'),
                    'sticky': False,
                    'type': 'success',
                }
            }
        except Exception as e:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('打印错误'),
                    'message': str(e),
                    'sticky': False,
                    'type': 'danger',
                }
            }
    
    def _generate_receipt_content(self):
        """生成小票内容"""
        self.ensure_one()
        
        # 如果配置了自定义模板，使用自定义模板
        if self.config_id.ylcloud_receipt_template:
            template = self.config_id.ylcloud_receipt_template
            # TODO: 使用模板引擎渲染内容
            return template
        
        # 默认模板
        company = self.company_id
        content = []
        
        # 标题
        content.append('\n{}\n'.format(company.name))
        content.append('--------------------------------')
        
        # 订单信息
        content.append('订单号: {}'.format(self.name))
        content.append('日期: {}'.format(self.date_order.strftime('%Y-%m-%d %H:%M')))
        if self.user_id:
            content.append('收银员: {}'.format(self.user_id.name))
        content.append('--------------------------------')
        
        # 商品明细
        content.append('商品明细:')
        for line in self.lines:
            price = line.price_subtotal_incl
            content.append('{} x {} = {}'.format(
                line.product_id.name[:20],
                line.qty,
                self.currency_id.symbol + ' ' + str(price)
            ))
        content.append('--------------------------------')
        
        # 合计
        content.append('小计: {}'.format(self.currency_id.symbol + ' ' + str(self.amount_total)))
        if hasattr(self, 'amount_tax'):
            content.append('税额: {}'.format(self.currency_id.symbol + ' ' + str(self.amount_tax)))
        
        # 支付信息
        content.append('支付方式:')
        for payment in self.payment_ids:
            content.append('{}: {}'.format(
                payment.payment_method_id.name,
                self.currency_id.symbol + ' ' + str(payment.amount)
            ))
        
        # 页脚
        content.append('--------------------------------')
        content.append('谢谢惠顾!')
        
        return '\n'.join(content)