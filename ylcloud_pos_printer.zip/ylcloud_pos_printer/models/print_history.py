# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _

class YLCloudPrintHistory(models.Model):
    _name = 'ylcloud.print.history'
    _description = '易联云打印历史记录'
    _order = 'create_date desc'

    printer_id = fields.Many2one('ylcloud.printer', string='打印机', required=True, ondelete='cascade')
    content = fields.Text(string='打印内容', required=True)
    order_id = fields.Char(string='订单号', required=True, help='易联云系统中的订单号，用于查询打印状态')
    pos_order_id = fields.Many2one('pos.order', string='POS订单', ondelete='set null')
    status = fields.Selection([
        ('waiting', '等待打印'),
        ('printing', '打印中'),
        ('success', '打印成功'),
        ('failed', '打印失败')
    ], string='状态', default='waiting', required=True)
    message = fields.Char(string='消息', help='打印状态消息或错误信息')
    create_date = fields.Datetime(string='创建时间', readonly=True)
    company_id = fields.Many2one('res.company', string='公司', related='printer_id.company_id', store=True)
    
    def name_get(self):
        result = []
        for record in self:
            name = "%s (%s)" % (record.order_id, record.create_date.strftime('%Y-%m-%d %H:%M:%S') if record.create_date else '')
            result.append((record.id, name))
        return result
    
    def action_refresh_status(self):
        """刷新打印状态"""
        for record in self:
            try:
                result = self.env['ylcloud.service'].get_print_status(record.printer_id.id, record.order_id)
                if result and 'body' in result and 'state' in result['body']:
                    state = result['body']['state']
                    # 状态码: 1:打印完成 2:等待打印 3:打印异常 4:队列已满
                    if state == 1:
                        record.status = 'success'
                        record.message = '打印完成'
                    elif state == 2:
                        record.status = 'waiting'
                        record.message = '等待打印'
                    elif state == 3:
                        record.status = 'failed'
                        record.message = '打印异常'
                    elif state == 4:
                        record.status = 'waiting'
                        record.message = '队列已满'
            except Exception as e:
                record.message = str(e) 