odoo.define('ylcloud_pos_printer.payment_hooks', function (require) {
    'use strict';

    const { Gui } = require('point_of_sale.Gui');
    const PaymentScreen = require('point_of_sale.PaymentScreen');
    const Registries = require('point_of_sale.Registries');
    
    // Odoo 18中标准的支付钩子
    const YLCloudPaymentHooks = (PaymentScreen) =>
        class YLCloudPaymentHooksExt extends PaymentScreen {
            /**
             * Odoo 18中的关键钩子方法，在付款完成时触发
             * 这是标准入口点，会在订单支付完成后立即执行
             */
            async _finalizeOrder() {
                console.log('YLCloudPaymentHooks: _finalizeOrder钩子触发，准备调用父类方法');
                
                // 保存当前订单的引用
                const order = this.currentOrder;
                
                try {
                    // 先执行原始支付流程
                    await super._finalizeOrder(...arguments);
                    console.log('YLCloudPaymentHooks: 父类_finalizeOrder完成，订单支付已确认');
                    
                    // 支付完成后，检查打印条件
                    await this._triggerOrderPrint(order);
                } catch (error) {
                    console.error('YLCloudPaymentHooks: _finalizeOrder执行异常', error);
                    // 继续抛出异常以便上层处理
                    throw error;
                }
            }
            
            /**
             * 触发订单打印
             * @param {Object} order 需要打印的订单
             */
            async _triggerOrderPrint(order) {
                if (!order) {
                    console.log('YLCloudPaymentHooks: 没有可打印的订单');
                    return;
                }
                
                // 获取POS配置
                const pos = this.env.pos;
                
                // 检查是否配置了易联云打印机并启用了自动打印
                if (!pos.ylcloud_printer || 
                    !pos.ylcloud_printer.auto_print || 
                    !pos.ylcloud_printer.print_order) {
                    
                    const reason = !pos.ylcloud_printer ? '未配置打印机' :
                                  !pos.ylcloud_printer.auto_print ? '未启用自动打印' :
                                  !pos.ylcloud_printer.print_order ? '未启用订单打印' : '未知原因';
                    
                    console.log(`YLCloudPaymentHooks: 不满足自动打印条件，跳过打印。原因: ${reason}`);
                    return;
                }
                
                console.log('YLCloudPaymentHooks: 符合自动打印条件，准备打印订单:', order.name);
                
                try {
                    // 优先通过PrinterService服务进行打印
                    const printerService = this.env.services.printer;
                    
                    if (printerService) {
                        console.log('YLCloudPaymentHooks: 通过PrinterService打印订单');
                        
                        // 直接调用PrinterService的打印方法
                        setTimeout(async () => {
                            try {
                                const result = await printerService.printOrder(order);
                                console.log('YLCloudPaymentHooks: 打印结果', result);
                            } catch (printError) {
                                console.error('YLCloudPaymentHooks: PrinterService打印异常', printError);
                            }
                        }, 500);
                    } else {
                        // 降级方案：通过订单的打印方法
                        console.log('YLCloudPaymentHooks: PrinterService未找到，尝试通过订单对象打印');
                        
                        // 检查订单对象是否支持打印
                        if (typeof order.printOrder === 'function') {
                            setTimeout(async () => {
                                try {
                                    const result = await order.printOrder();
                                    console.log('YLCloudPaymentHooks: 通过订单打印结果', result);
                                } catch (printError) {
                                    console.error('YLCloudPaymentHooks: 订单打印异常', printError);
                                }
                            }, 500);
                        } else {
                            // 备用方案：通过POS对象的打印方法
                            console.log('YLCloudPaymentHooks: 订单对象不支持打印，尝试通过POS对象打印');
                            
                            if (typeof pos._printYLCloudOrder === 'function') {
                                setTimeout(async () => {
                                    try {
                                        const result = await pos._printYLCloudOrder(order);
                                        console.log('YLCloudPaymentHooks: 通过POS对象打印结果', result);
                                    } catch (printError) {
                                        console.error('YLCloudPaymentHooks: POS打印异常', printError);
                                    }
                                }, 500);
                            } else {
                                console.error('YLCloudPaymentHooks: 没有可用的打印方法，无法打印订单');
                                
                                // 显示错误消息
                                Gui.showPopup('ErrorPopup', {
                                    title: '打印失败',
                                    body: '系统错误：没有找到可用的打印方法',
                                });
                            }
                        }
                    }
                } catch (error) {
                    console.error('YLCloudPaymentHooks: 触发打印时发生异常', error);
                    console.error('错误详情:', error.message, error.stack);
                    
                    // 显示错误消息
                    Gui.showPopup('ErrorPopup', {
                        title: '打印错误',
                        body: `打印订单时发生错误: ${error.message || '未知错误'}`,
                    });
                }
            }
        };

    // 注册支付钩子扩展
    Registries.Component.extend(PaymentScreen, YLCloudPaymentHooks);
    
    return YLCloudPaymentHooks;
}); 