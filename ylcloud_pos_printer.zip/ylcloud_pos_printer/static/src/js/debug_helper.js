odoo.define('ylcloud_pos_printer.debug_helper', function (require) {
    'use strict';

    const { Component } = owl;
    const PosComponent = require('point_of_sale.PosComponent');
    const Registries = require('point_of_sale.Registries');
    const { useListener } = require("@web/core/utils/hooks");
    const { Gui } = require('point_of_sale.Gui');
    
    /**
     * 易联云打印调试按钮
     * 方便用户手动测试打印功能
     */
    class YLCloudDebugButton extends PosComponent {
        setup() {
            super.setup();
            useListener('click', this._onClick);
        }
        
        async _onClick() {
            console.log('YLCloudDebugButton: 点击调试按钮');
            
            const printerService = this.env.services.printer;
            const pos = this.env.pos;
            
            if (!pos.ylcloud_printer || !pos.ylcloud_printer.id) {
                return this._showError('未配置打印机', '请先在POS设置中配置易联云打印机');
            }
            
            // 显示调试菜单
            await this._showDebugMenu();
        }
        
        async _showDebugMenu() {
            const { confirmed, payload } = await this.showPopup('SelectionPopup', {
                title: '易联云打印调试',
                list: [
                    { id: 'status', label: '检查打印机状态' },
                    { id: 'test', label: '打印测试页' },
                    { id: 'order', label: '打印当前订单' },
                    { id: 'config', label: '查看打印机配置' },
                    { id: 'logs', label: '查看最近打印记录' }
                ]
            });
            
            if (confirmed) {
                await this._handleDebugAction(payload);
            }
        }
        
        async _handleDebugAction(action) {
            const printerService = this.env.services.printer;
            const pos = this.env.pos;
            
            switch(action) {
                case 'status':
                    await this._checkPrinterStatus();
                    break;
                case 'test':
                    await this._printTestPage();
                    break;
                case 'order':
                    await this._printCurrentOrder();
                    break;
                case 'config':
                    await this._showPrinterConfig();
                    break;
                case 'logs':
                    await this._showPrintLogs();
                    break;
            }
        }
        
        async _checkPrinterStatus() {
            try {
                console.log('YLCloudDebugButton: 检查打印机状态');
                
                const printerService = this.env.services.printer;
                let statusResult;
                
                if (printerService && typeof printerService.checkPrinterConnection === 'function') {
                    statusResult = await printerService.checkPrinterConnection();
                } else {
                    statusResult = await this.env.pos.checkPrinterConnection();
                }
                
                console.log('YLCloudDebugButton: 打印机状态检查结果', statusResult);
                
                const statusText = statusResult.status === 'connected' ? '已连接' :
                                  statusResult.status === 'disconnected' ? '未连接' :
                                  statusResult.status === 'error' ? '连接错误' : '未知状态';
                
                await this.showPopup('InfoPopup', {
                    title: '打印机状态',
                    body: `状态: ${statusText}
                          
                          详情信息:
                          ${JSON.stringify(statusResult.details || {}, null, 2)}
                          
                          打印机名称: ${this.env.pos.ylcloud_printer?.name || '未知'}
                          设备编码: ${this.env.pos.ylcloud_printer?.machine_code || '未知'}
                          `
                });
            } catch (error) {
                console.error('YLCloudDebugButton: 检查打印机状态失败', error);
                this._showError('检查打印机状态失败', error.message);
            }
        }
        
        async _printTestPage() {
            try {
                console.log('YLCloudDebugButton: 打印测试页');
                
                const printerService = this.env.services.printer;
                let printResult;
                
                if (printerService && typeof printerService.debugPrint === 'function') {
                    printResult = await printerService.debugPrint();
                } else if (this.env.pos.debugPrintYLCloud) {
                    printResult = await this.env.pos.debugPrintYLCloud();
                } else {
                    return this._showError('打印测试页失败', '找不到可用的打印方法');
                }
                
                console.log('YLCloudDebugButton: 测试页打印结果', printResult);
                
                if (printResult && (printResult.error === 0 || printResult.error === '0')) {
                    await this.showPopup('ConfirmPopup', {
                        title: '打印成功',
                        body: '测试页已发送到打印机',
                        confirmText: '确定'
                    });
                } else {
                    const errorMsg = printResult && printResult.error_description 
                        ? printResult.error_description : '未知错误';
                    
                    this._showError('打印测试页失败', errorMsg);
                }
            } catch (error) {
                console.error('YLCloudDebugButton: 打印测试页失败', error);
                this._showError('打印测试页失败', error.message);
            }
        }
        
        async _printCurrentOrder() {
            try {
                console.log('YLCloudDebugButton: 打印当前订单');
                
                const order = this.env.pos.get_order();
                if (!order) {
                    return this._showError('打印订单失败', '没有选中的订单');
                }
                
                console.log('YLCloudDebugButton: 当前订单信息', {
                    name: order.name,
                    uid: order.uid,
                    isPrinted: order.isPrinted
                });
                
                const printerService = this.env.services.printer;
                let printResult;
                
                if (printerService && typeof printerService.printOrder === 'function') {
                    printResult = await printerService.printOrder(order);
                } else if (typeof order.printOrder === 'function') {
                    printResult = await order.printOrder();
                } else if (this.env.pos._printYLCloudOrder) {
                    printResult = await this.env.pos._printYLCloudOrder(order);
                } else {
                    return this._showError('打印订单失败', '找不到可用的打印方法');
                }
                
                console.log('YLCloudDebugButton: 订单打印结果', printResult);
                
                if (printResult && (printResult.error === 0 || printResult.error === '0')) {
                    await this.showPopup('ConfirmPopup', {
                        title: '打印成功',
                        body: '订单已发送到打印机',
                        confirmText: '确定'
                    });
                } else {
                    const errorMsg = printResult && printResult.error_description 
                        ? printResult.error_description : '未知错误';
                    
                    this._showError('打印订单失败', errorMsg);
                }
            } catch (error) {
                console.error('YLCloudDebugButton: 打印当前订单失败', error);
                this._showError('打印订单失败', error.message);
            }
        }
        
        async _showPrinterConfig() {
            try {
                console.log('YLCloudDebugButton: 显示打印机配置');
                
                const printer = this.env.pos.ylcloud_printer;
                if (!printer) {
                    return this._showError('查看打印机配置', '未配置打印机');
                }
                
                const configInfo = `
                打印机名称: ${printer.name || '未设置'}
                设备编码: ${printer.machine_code || '未设置'}
                合作伙伴ID: ${printer.partner_id || '未设置'}
                自动打印: ${printer.auto_print ? '启用' : '禁用'}
                打印订单: ${printer.print_order ? '启用' : '禁用'}
                打印收据: ${printer.print_receipt ? '启用' : '禁用'}
                纸张宽度: ${printer.paper_width || '58'}mm
                `;
                
                await this.showPopup('InfoPopup', {
                    title: '打印机配置信息',
                    body: configInfo
                });
            } catch (error) {
                console.error('YLCloudDebugButton: 显示打印机配置失败', error);
                this._showError('查看打印机配置', error.message);
            }
        }
        
        async _showPrintLogs() {
            try {
                console.log('YLCloudDebugButton: 显示打印记录');
                
                const printerService = this.env.services.printer;
                let printHistory = [];
                
                if (printerService && typeof printerService.getPrintHistory === 'function') {
                    printHistory = printerService.getPrintHistory();
                }
                
                if (printHistory.length === 0) {
                    return this.showPopup('InfoPopup', {
                        title: '打印记录',
                        body: '暂无打印记录'
                    });
                }
                
                let logInfo = '最近打印记录:\n\n';
                printHistory.slice(0, 5).forEach((record, index) => {
                    const result = record.result && (record.result.error === 0 || record.result.error === '0')
                        ? '成功'
                        : '失败';
                    
                    logInfo += `${index + 1}. [${record.time}] ${record.orderName} - ${result}\n`;
                    
                    if (record.result && record.result.error !== 0 && record.result.error !== '0') {
                        logInfo += `   错误: ${record.result.error_description || '未知错误'}\n`;
                    }
                    
                    logInfo += '\n';
                });
                
                await this.showPopup('InfoPopup', {
                    title: '打印记录',
                    body: logInfo
                });
            } catch (error) {
                console.error('YLCloudDebugButton: 显示打印记录失败', error);
                this._showError('查看打印记录', error.message);
            }
        }
        
        _showError(title, message) {
            return this.showPopup('ErrorPopup', {
                title: title,
                body: message
            });
        }
        
        get isYLCloudConfigured() {
            const pos = this.env.pos;
            return pos && pos.ylcloud_printer && pos.ylcloud_printer.id;
        }
    }
    
    // 注册调试按钮组件
    Registries.Component.add(YLCloudDebugButton);
    
    // 打印机状态指示器组件
    class YLCloudPrinterStatus extends PosComponent {
        setup() {
            super.setup();
        }
        
        get status() {
            const printerService = this.env.services.printer;
            if (printerService) {
                return printerService.printerConnectionStatus || 'unknown';
            }
            return 'unknown';
        }
        
        get printerName() {
            return this.env.pos.ylcloud_printer?.name || '';
        }
    }
    
    // 注册打印机状态组件
    Registries.Component.add(YLCloudPrinterStatus);
    
    // 将组件添加到按钮区域
    const PosControlButtonsExtension = (PosControlButtons) => {
        class PosControlButtonsExt extends PosControlButtons {
            setup() {
                super.setup();
            }
        }
        
        PosControlButtonsExt.template = owl.tags.xml`
            <div class="pos-control-buttons">
                <t t-foreach="controlButtons" t-as="cb" t-key="cb.name">
                    <t t-component="cb.component" t-props="cb.props"/>
                </t>
                <t t-if="env.pos.ylcloud_printer">
                    <YLCloudDebugButton />
                </t>
            </div>
        `;
        
        return PosControlButtonsExt;
    };
    
    // 注册扩展
    Registries.Component.extend('PosControlButtons', PosControlButtonsExtension);
    
    return {
        YLCloudDebugButton,
        YLCloudPrinterStatus,
        PosControlButtonsExtension
    };
}); 