'use strict';

// 添加更详细的模块加载日志
console.log('易联云打印模块加载开始...版本: 2.0.3');

// 添加函数来封装日志记录，便于跟踪和调试
function ylcloudLog(message, data = null) {
    const prefix = '[易联云打印]';
    if (data) {
        console.log(prefix, message, data);
    } else {
        console.log(prefix, message);
    }
}

/**
 * 打印队列管理器
 * 用于管理打印任务的队列，处理重试逻辑和状态跟踪
 */
class PrintQueueManager {
    constructor(pos) {
        this.pos = pos;
        this.queue = [];
        this.isProcessing = false;
        this.maxRetries = 3;
        this.retryDelay = 3000; // 3秒后重试
        this.history = []; // 打印历史
        this.maxHistoryLength = 50; // 最多保存50条历史记录
        this.isPaused = false; // 队列是否暂停处理
        
        // 指数退避设置
        this.baseRetryDelay = 2000; // 基础重试延迟时间(ms)
        this.maxRetryDelay = 15000; // 最大重试延迟时间(ms)
        
        // 网络状态监控
        this.networkErrors = 0;
        this.maxNetworkErrors = 5; // 连续网络错误阈值，超过后暂停队列
        
        ylcloudLog('初始化打印队列管理器');
        
        // 每60秒检查一次暂停的队列，尝试恢复处理
        setInterval(() => this._checkPausedQueue(), 60000);
    }
    
    /**
     * 添加打印任务到队列
     * @param {string} orderId 订单ID
     * @param {string} content 打印内容
     * @param {function} callback 可选的回调函数
     * @param {number} priority 优先级(1最高,5最低,默认3)
     */
    addPrintJob(orderId, content, callback = null, priority = 3) {
        ylcloudLog('添加打印任务到队列', { orderId, priority });
        
        // 检查是否已存在相同orderId的任务
        const existingJob = this.queue.find(job => job.orderId === orderId);
        if (existingJob) {
            ylcloudLog('打印任务已在队列中，更新内容', { orderId });
            existingJob.content = content;
            existingJob.callback = callback;
            existingJob.priority = Math.min(existingJob.priority, priority); // 取最高优先级
            return;
        }
        
        // 格式化打印内容，确保易联云指令正确
        const formattedContent = this._formatYLCloudCommands(content);
        
        // 添加新任务
        const newJob = {
            orderId,
            content: formattedContent,
            callback,
            attempts: 0,
            status: 'waiting',
            addedTime: new Date(),
            priority: priority,
            lastErrorMessage: null,
            lastErrorCode: null,
            retryDelay: this.baseRetryDelay
        };
        
        // 根据优先级插入队列
        if (this.queue.length === 0 || priority > this.queue[this.queue.length - 1].priority) {
            this.queue.push(newJob);
        } else {
            // 找到合适的位置插入，保持优先级顺序
            let insertIndex = 0;
            for (let i = 0; i < this.queue.length; i++) {
                if (this.queue[i].priority <= priority) {
                    insertIndex = i + 1;
                } else {
                    break;
                }
            }
            this.queue.splice(insertIndex, 0, newJob);
        }
        
        // 如果队列未在处理中，启动处理
        if (!this.isProcessing && !this.isPaused) {
            this._processQueue();
        }
    }
    
    /**
     * 格式化易联云打印指令，确保兼容性
     * @param {string} content 原始打印内容
     * @returns {string} 格式化后的内容
     * @private
     */
    _formatYLCloudCommands(content) {
        // 确保易联云控制命令格式正确
        let formatted = content;
        
        // 添加纸张类型声明（如果没有）
        if (!formatted.includes('<paper') && this.pos.ylcloud_printer) {
            const paperWidth = this.pos.ylcloud_printer.paper_width || '58';
            formatted = `<paper type="${paperWidth}mm">\n${formatted}`;
        }
        
        // 确保结尾有切纸命令
        if (!formatted.includes('<cut>')) {
            formatted = `${formatted}\n<cut>\n`;
        }
        
        // 替换HTML实体为实际控制符（如果有）
        formatted = formatted
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>');
            
        return formatted;
    }
    
    /**
     * 内部方法：处理打印队列
     * @private
     */
    async _processQueue() {
        if (this.queue.length === 0) {
            this.isProcessing = false;
            ylcloudLog('打印队列处理完成，当前队列为空');
            return;
        }
        
        if (this.isPaused) {
            ylcloudLog('打印队列当前已暂停，不再处理任务');
            this.isProcessing = false;
            return;
        }
        
        this.isProcessing = true;
        const job = this.queue[0]; // 获取队首任务
        job.status = 'processing';
        
        ylcloudLog('开始处理打印任务', { 
            orderId: job.orderId, 
            attempts: job.attempts + 1,
            priority: job.priority
        });
        
        try {
            // 执行打印请求，注意这里要调用_directPrintYLCloudReceipt避免循环调用
            const result = await this.pos._directPrintYLCloudReceipt(job.orderId, job.content);
            
            // 处理打印结果
            if (result && (result.error === 0 || result.error === '0')) {
                // 打印成功，重置网络错误计数
                this.networkErrors = 0;
                
                // 打印成功
                ylcloudLog('打印任务成功', { orderId: job.orderId });
                job.status = 'completed';
                
                // 添加到历史记录
                this._addToHistory({
                    orderId: job.orderId,
                    status: 'success',
                    timestamp: new Date(),
                    result: result
                });
                
                // 执行回调
                if (typeof job.callback === 'function') {
                    job.callback(null, result);
                }
                
                // 从队列中移除
                this.queue.shift();
            } else {
                // 打印失败，判断是否需要重试
                const errorCode = result ? result.error : 'unknown';
                const errorMsg = result && result.error_description 
                    ? result.error_description : '未知错误';
                
                // 检查是否是网络错误
                const isNetworkError = this._isNetworkError(errorCode, errorMsg);
                if (isNetworkError) {
                    this.networkErrors++;
                    
                    // 如果连续网络错误超过阈值，暂停队列
                    if (this.networkErrors >= this.maxNetworkErrors) {
                        this._pauseQueue();
                        ylcloudLog('连续网络错误过多，暂停打印队列', { count: this.networkErrors });
                    }
                } else {
                    // 非网络错误，重置计数
                    this.networkErrors = 0;
                }
                
                // 记录错误信息
                job.lastErrorMessage = errorMsg;
                job.lastErrorCode = errorCode;
                
                if (job.attempts < this.maxRetries) {
                    // 增加重试次数
                    job.attempts++;
                    job.status = 'retry';
                    
                    // 使用指数退避算法计算下次重试时间
                    job.retryDelay = Math.min(
                        job.retryDelay * (1 + Math.random()), // 增加随机因子
                        this.maxRetryDelay
                    );
                    
                    ylcloudLog('打印任务失败，将重试', { 
                        orderId: job.orderId, 
                        error: errorMsg,
                        nextAttempt: job.attempts,
                        retryDelay: job.retryDelay
                    });
                    
                    // 移至队列末尾，延迟重试
                    this.queue.shift();
                    this.queue.push(job);
                    
                    // 记录失败历史
                    this._addToHistory({
                        orderId: job.orderId,
                        status: 'retry',
                        timestamp: new Date(),
                        result: result,
                        error: errorMsg,
                        attempt: job.attempts
                    });
                } else {
                    // 超过最大重试次数，标记为失败
                    ylcloudLog('打印任务失败，超过最大重试次数', { 
                        orderId: job.orderId,
                        error: errorMsg
                    });
                    
                    job.status = 'failed';
                    
                    // 添加到历史记录
                    this._addToHistory({
                        orderId: job.orderId,
                        status: 'failed',
                        timestamp: new Date(),
                        result: result,
                        error: errorMsg
                    });
                    
                    // 尝试调用后端记录打印失败
                    try {
                        this.pos.rpc({
                            model: 'pos.print.queue',
                            method: 'record_print_failure',
                            args: [job.orderId, errorCode, errorMsg],
                        }, { shadow: true }).catch(() => {});
                    } catch (e) {
                        // 忽略后端记录错误
                    }
                    
                    // 执行回调
                    if (typeof job.callback === 'function') {
                        job.callback(new Error(errorMsg), null);
                    }
                    
                    // 从队列中移除
                    this.queue.shift();
                }
            }
        } catch (error) {
            // 发生异常，判断是否需要重试
            ylcloudLog('打印任务执行异常', { 
                orderId: job.orderId,
                error: error.message
            });
            
            // 可能是网络错误，增加计数
            this.networkErrors++;
            
            if (job.attempts < this.maxRetries) {
                // 增加重试次数
                job.attempts++;
                job.status = 'retry';
                job.lastErrorMessage = error.message;
                
                // 使用指数退避算法
                job.retryDelay = Math.min(
                    this.baseRetryDelay * Math.pow(2, job.attempts - 1), 
                    this.maxRetryDelay
                );
                
                ylcloudLog('打印任务异常，将重试', {
                    orderId: job.orderId,
                    nextAttempt: job.attempts,
                    retryDelay: job.retryDelay
                });
                
                // 移至队列末尾，延迟重试
                this.queue.shift();
                this.queue.push(job);
                
                // 记录异常历史
                this._addToHistory({
                    orderId: job.orderId,
                    status: 'error',
                    timestamp: new Date(),
                    error: error.message,
                    attempt: job.attempts
                });
            } else {
                // 超过最大重试次数，标记为失败
                ylcloudLog('打印任务异常，超过最大重试次数', {
                    orderId: job.orderId,
                    error: error.message
                });
                
                job.status = 'failed';
                
                // 添加到历史记录
                this._addToHistory({
                    orderId: job.orderId,
                    status: 'error',
                    timestamp: new Date(),
                    error: error.message
                });
                
                // 执行回调
                if (typeof job.callback === 'function') {
                    job.callback(error, null);
                }
                
                // 从队列中移除
                this.queue.shift();
            }
        }
        
        // 继续处理下一个任务
        const delay = (job.status === 'retry') ? job.retryDelay : 500;
        setTimeout(() => this._processQueue(), delay);
    }
    
    /**
     * 检查错误是否为网络相关错误
     * @param {string|number} errorCode 错误码
     * @param {string} errorMsg 错误消息
     * @returns {boolean} 是否为网络错误
     * @private
     */
    _isNetworkError(errorCode, errorMsg) {
        // 基于错误码判断
        const networkErrorCodes = ['4001', 4001, 'timeout', 'network_error'];
        if (networkErrorCodes.includes(errorCode)) {
            return true;
        }
        
        // 基于错误消息判断
        const networkKeywords = [
            'timeout', '超时', 'network', '网络', 
            'connection', '连接', 'offline', '离线',
            '不在线', '缺纸'
        ];
        
        return networkKeywords.some(keyword => 
            errorMsg && errorMsg.toLowerCase().includes(keyword.toLowerCase())
        );
    }
    
    /**
     * 暂停队列处理
     * @private
     */
    _pauseQueue() {
        this.isPaused = true;
        ylcloudLog('打印队列已暂停，将在60秒后尝试恢复');
        
        // 可以在这里添加通知用户的逻辑
        try {
            if (this.pos && this.pos.showNotification) {
                this.pos.showNotification(
                    '打印服务暂时不可用，系统将自动尝试恢复', 
                    5000
                );
            }
        } catch (e) {
            // 忽略通知错误
        }
    }
    
    /**
     * 检查并尝试恢复暂停的队列
     * @private
     */
    async _checkPausedQueue() {
        if (!this.isPaused) {
            return;
        }
        
        ylcloudLog('尝试恢复暂停的打印队列');
        
        try {
            // 测试打印机连接
            const result = await this.pos.checkPrinterConnection();
            if (result && result.status === 'connected') {
                ylcloudLog('打印机已重新连接，恢复队列处理');
                this.isPaused = false;
                this.networkErrors = 0;
                
                if (this.queue.length > 0 && !this.isProcessing) {
                    this._processQueue();
                }
                
                // 通知用户
                try {
                    if (this.pos && this.pos.showNotification) {
                        this.pos.showNotification('打印服务已恢复', 3000);
                    }
                } catch (e) {
                    // 忽略通知错误
                }
            }
        } catch (e) {
            ylcloudLog('恢复队列检查失败', e.message);
        }
    }
    
    /**
     * 添加记录到历史
     * @param {Object} record
     * @private
     */
    _addToHistory(record) {
        this.history.unshift(record);
        
        // 限制历史记录数量
        if (this.history.length > this.maxHistoryLength) {
            this.history = this.history.slice(0, this.maxHistoryLength);
        }
    }
    
    /**
     * 获取打印历史
     * @returns {Array}
     */
    getPrintHistory() {
        return [...this.history];
    }
    
    /**
     * 获取队列状态
     * @returns {Object}
     */
    getQueueStatus() {
        return {
            queueLength: this.queue.length,
            isProcessing: this.isProcessing,
            isPaused: this.isPaused,
            networkErrors: this.networkErrors,
            currentJobs: this.queue.map(job => ({
                orderId: job.orderId,
                status: job.status,
                attempts: job.attempts,
                addedTime: job.addedTime,
                priority: job.priority,
                lastError: job.lastErrorMessage
            }))
        };
    }
    
    /**
     * 清空队列
     */
    clearQueue() {
        ylcloudLog('清空打印队列');
        
        // 通知回调函数任务被取消
        this.queue.forEach(job => {
            if (typeof job.callback === 'function') {
                job.callback(new Error('任务被取消'), null);
            }
        });
        
        this.queue = [];
        this.isProcessing = false;
    }
    
    /**
     * 手动恢复队列处理
     */
    resumeQueue() {
        if (this.isPaused) {
            ylcloudLog('手动恢复打印队列');
            this.isPaused = false;
            this.networkErrors = 0;
            
            if (this.queue.length > 0 && !this.isProcessing) {
                this._processQueue();
            }
            
            return true;
        }
        return false;
    }
    
    /**
     * 重试特定的打印任务
     * @param {string} orderId
     * @returns {boolean} 是否找到并重试
     */
    retryPrintJob(orderId) {
        // 查找历史记录中失败的任务
        const lastFailedJob = this.history.find(
            record => record.orderId === orderId && 
            (record.status === 'failed' || record.status === 'error')
        );
        
        if (!lastFailedJob) {
            ylcloudLog('未找到可重试的打印任务', { orderId });
            return false;
        }
        
        // 查询订单内容，重新加入队列
        ylcloudLog('重试打印任务', { orderId });
        
        // 这里需要获取订单内容，可能需要调用pos方法
        this.pos.getOrder(orderId).then(order => {
            if (order) {
                // 生成打印内容并添加到队列
                this.pos.getOrderPrintContent(order).then(content => {
                    if (content) {
                        // 使用高优先级添加到队列
                        this.addPrintJob(orderId, content, null, 1);
                        return true;
                    }
                });
            }
        }).catch(error => {
            ylcloudLog('重试打印任务时出错', { orderId, error: error.message });
        });
        
        return false;
    }
}

/**
 * 显示通知的方法 
 * @param {string} message 通知内容
 * @param {number} duration 显示时长（毫秒）
 */
function showNotification(message, duration = 2000) {
    try {
        // 检查是否有通知系统
        if (this.chrome && this.chrome.showNotification) {
            this.chrome.showNotification(message, duration);
        } else if (this.env && this.env.services && this.env.services.notification) {
            this.env.services.notification.add(message, {
                type: 'info',
                sticky: false,
                timeout: duration,
            });
        } else {
            // 使用Gui通用方法
            Gui.showPopup('AlertPopup', {
                title: _t('通知'),
                body: message,
            });
        }
    } catch (error) {
        console.error('显示通知失败:', error);
    }
}

odoo.define('ylcloud_pos_printer.printer', function (require) {
    'use strict';
    
    ylcloudLog('开始初始化模块依赖...');
    
    const { Gui } = require('point_of_sale.Gui');
    const PosComponent = require('point_of_sale.PosComponent');
    const Registries = require('point_of_sale.Registries');
    const ProductScreen = require('point_of_sale.ProductScreen');
    const PaymentScreen = require('point_of_sale.PaymentScreen');
    const ReceiptScreen = require('point_of_sale.ReceiptScreen');
    const { useListener } = require("@web/core/utils/hooks");
    const { _t } = require('web.core');
    const OrderReceipt = require('point_of_sale.OrderReceipt');
    const Order = require('point_of_sale.models').Order;
    const PosGlobalState = require('point_of_sale.models').PosGlobalState;
    const moment = require('moment');

    ylcloudLog('模块依赖加载完成');

    // 首先定义打印按钮组件 - 这样后面可以正确引用这些组件
    class YLCloudPrintButton extends PosComponent {
        setup() {
            super.setup();
            useListener('click', this.onClick);
            console.log('YLCloudPrintButton初始化完成');
        }
        
        async onClick() {
            console.log('YLCloudPrintButton: 点击打印按钮');
            try {
                const order = this.env.pos.get_order();
                if (!order) {
                    console.error('YLCloudPrintButton: 当前没有选中订单');
                    Gui.showPopup('ErrorPopup', {
                        title: _t('打印错误'),
                        body: _t('当前没有选中的订单'),
                    });
                    return;
                }
                
                // 先尝试使用订单的打印方法
                if (typeof order.printOrder === 'function') {
                    console.log('YLCloudPrintButton: 使用order.printOrder()打印');
                    const result = await order.printOrder();
                    console.log('YLCloudPrintButton: 打印结果:', result);
                    return;
                }
                
                // 备用方法：获取订单打印内容并发送打印请求
                console.log('YLCloudPrintButton: 使用备用方法打印');
                
                // 生成唯一订单ID
                const timestamp = Math.floor(Date.now());
                const orderId = 'BUTTON_' + order.name.replace(/\s+/g, '') + '_' + timestamp;
                
                // 获取打印内容
                let content;
                try {
                    if (typeof order.getOrderPrintContent === 'function') {
                        content = order.getOrderPrintContent();
                    } else {
                        const receipt = order.export_for_printing();
                        content = this.env.pos._formatOrderContent(receipt);
                    }
                } catch (e) {
                    console.error('YLCloudPrintButton: 生成打印内容失败', e);
                    Gui.showPopup('ErrorPopup', {
                        title: _t('打印错误'),
                        body: _t('生成打印内容失败: ') + e.message,
                    });
                    return;
                }
                
                if (!content) {
                    console.error('YLCloudPrintButton: 生成的打印内容为空');
                    Gui.showPopup('ErrorPopup', {
                        title: _t('打印错误'),
                        body: _t('生成的打印内容为空'),
                    });
                    return;
                }
                
                console.log('YLCloudPrintButton: 发送打印请求, ID:', orderId);
                const result = await this.env.pos.printYLCloudReceipt(orderId, content);
                console.log('YLCloudPrintButton: 打印结果:', result);
            } catch (error) {
                console.error('YLCloudPrintButton: 打印失败', error);
                Gui.showPopup('ErrorPopup', {
                    title: _t('打印错误'),
                    body: _t('打印请求失败: ') + (error.message || '未知错误'),
                });
            }
        }
        
        get isYLCloudConfigured() {
            const pos = this.env.pos;
            return pos && pos.ylcloud_printer && pos.ylcloud_printer.id;
        }
    }
    
    class YLCloudReceiptPrintButton extends PosComponent {
        setup() {
            super.setup();
            useListener('click', this.onClick);
            console.log('YLCloudReceiptPrintButton初始化完成');
        }
        
        async onClick() {
            console.log('YLCloudReceiptPrintButton: 点击打印收据按钮');
            try {
                // 触发ReceiptScreen中定义的打印方法
                this.trigger('print-ylcloud-receipt');
            } catch (error) {
                console.error('YLCloudReceiptPrintButton: 触发打印事件失败', error);
                Gui.showPopup('ErrorPopup', {
                    title: _t('打印错误'),
                    body: _t('触发打印事件失败: ') + (error.message || '未知错误'),
                });
            }
        }
        
        get isYLCloudConfigured() {
            const pos = this.env.pos;
            return pos && 
                   pos.ylcloud_printer && 
                   pos.ylcloud_printer.id && 
                   pos.ylcloud_printer.print_receipt;
        }
    }
    
    // 注册按钮组件
    Registries.Component.add(YLCloudPrintButton);
    Registries.Component.add(YLCloudReceiptPrintButton);
    
    // 设置组件模板
    YLCloudPrintButton.template = 'YLCloudPrintButton';
    YLCloudReceiptPrintButton.template = 'YLCloudReceiptPrintButton';

    // 在YLCloudPrintButton和YLCloudReceiptPrintButton注册之后添加PaymentScreen扩展
    const YLCloudPaymentScreenButtonExt = (PaymentScreen) =>
        class YLCloudPaymentScreenButtonExt extends PaymentScreen {
            setup() {
                super.setup();
                useListener('print-ylcloud-order', this._printYLCloudOrder);
                console.log('易联云打印支付屏幕扩展初始化完成');
            }
            
            async _printYLCloudOrder() {
                console.log('PaymentScreen: 触发易联云订单打印');
                if (!this.env.pos.ylcloud_printer) {
                    console.log('PaymentScreen: 未配置打印机');
                    return false;
                }

                try {
                    const order = this.env.pos.get_order();
                    if (!order) {
                        console.error('PaymentScreen: 没有选中订单');
                        return false;
                    }
                    
                    const receipt = order.export_for_printing();
                    console.log('PaymentScreen: 订单数据:', receipt);
                    let receiptString = this._generateOrderReceiptText(receipt);
                    
                    const timestamp = Math.floor(Date.now());
                    const orderId = 'POS_' + receipt.name.replace(/\s+/g, '') + '_' + timestamp;
                    console.log('PaymentScreen: 打印订单:', orderId);
                    return await this.env.pos.printYLCloudReceipt(orderId, receiptString);
                } catch (error) {
                    console.error('PaymentScreen: 订单打印过程中出错:', error);
                    return false;
                }
            }
            
            _generateOrderReceiptText(receipt) {
                let receiptLines = [];
                
                // 标题
                receiptLines.push('\n' + this.env.pos.company.name + '\n');
                receiptLines.push('--------------------------------');
                
                // 订单信息
                receiptLines.push('订单号: ' + receipt.name);
                receiptLines.push('日期: ' + receipt.date.localestring);
                if (receipt.cashier) {
                    receiptLines.push('收银员: ' + receipt.cashier);
                }
                if (receipt.client) {
                    receiptLines.push('客户: ' + receipt.client.name);
                }
                receiptLines.push('--------------------------------');
                
                // 商品明细
                receiptLines.push('商品明细:');
                for (let line of receipt.orderlines) {
                    let productName = line.product_name;
                    if (productName.length > 20) {
                        productName = productName.substring(0, 17) + '...';
                    }
                    let qty = line.quantity;
                    let price = this.env.pos.format_currency_no_symbol(line.price_with_tax);
                    receiptLines.push(productName + ' x ' + qty + ' = ' + price);
                }
                
                receiptLines.push('--------------------------------');
                
                // 合计
                receiptLines.push('小计: ' + this.env.pos.format_currency(receipt.subtotal));
                if (receipt.total_discount) {
                    receiptLines.push('折扣: ' + this.env.pos.format_currency(receipt.total_discount));
                }
                if (receipt.total_tax) {
                    receiptLines.push('税额: ' + this.env.pos.format_currency(receipt.total_tax));
                }
                receiptLines.push('总计: ' + this.env.pos.format_currency(receipt.total_with_tax));
                
                // 页脚
                receiptLines.push('--------------------------------');
                receiptLines.push('谢谢惠顾! 欢迎再次光临!');
                
                return receiptLines.join('\n');
            }

            async validateOrder(isForceValidate) {
                console.log('PaymentScreen: 验证订单开始，检查是否需要自动打印, 当前订单:', this.env.pos.get_order().name);
                
                // 保存打印配置信息，避免因为异步导致配置失效
                const printerConfig = this.env.pos.ylcloud_printer ? {
                    id: this.env.pos.ylcloud_printer.id,
                    auto_print: this.env.pos.ylcloud_printer.auto_print,
                    print_order: this.env.pos.ylcloud_printer.print_order
                } : null;
                
                if (printerConfig) {
                    console.log('PaymentScreen: 自动打印配置:', {
                        打印机ID: printerConfig.id,
                        自动打印: printerConfig.auto_print,
                        打印订单: printerConfig.print_order
                    });
                } else {
                    console.log('PaymentScreen: 自动打印配置: 未配置打印机');
                }
                
                try {
                    // 获取当前订单名称，以便在打印时能找到对应订单
                    const currentOrderName = this.env.pos.get_order().name;
                    const currentOrderUID = this.env.pos.get_order().uid;
                    
                    // 先调用原始验证方法
                    const result = await super.validateOrder(...arguments);
                    console.log('PaymentScreen: 订单验证结果:', result);
                    
                    // 检查是否应该自动打印
                    if (printerConfig && printerConfig.auto_print && printerConfig.print_order) {
                        console.log('PaymentScreen: 符合自动打印条件，准备执行打印订单:', currentOrderName);
                        
                        // 使用延迟确保订单验证流程已完成
                        setTimeout(() => {
                            try {
                                console.log('PaymentScreen: 开始执行延迟打印, 订单名称:', currentOrderName);
                                
                                // 生成唯一订单ID
                                const timestamp = new Date().getTime();
                                const orderId = `AUTO_${currentOrderName.replace(/\s+/g, '')}_${timestamp}`;
                                
                                // 获取打印内容
                                const receipt = {
                                    name: currentOrderName,
                                    timestamp: timestamp,
                                    orderUID: currentOrderUID,
                                    date: { localestring: new Date().toLocaleString() },
                                    company: this.env.pos.company,
                                    cashier: this.env.pos.get_cashier().name,
                                };
                                
                                // 使用订单数据生成打印内容
                                const receiptString = this._generateOrderReceiptText(receipt);
                                
                                console.log('PaymentScreen: 自动打印订单:', orderId);
                                this.env.pos.printYLCloudReceipt(orderId, receiptString)
                                    .then(printResult => {
                                        console.log('PaymentScreen: 自动打印结果:', printResult);
                                        
                                        // 显示打印结果通知
                                        if (printResult && (printResult.error === 0 || printResult.error === '0')) {
                                            this.showNotification('打印成功', 2000);
                                        } else {
                                            const errMsg = printResult && printResult.error_description 
                                                ? printResult.error_description : '未知错误';
                                            this.showNotification(`打印失败: ${errMsg}`, 2000);
                                        }
                                    })
                                    .catch(printError => {
                                        console.error('PaymentScreen: 自动打印错误:', printError);
                                        this.showNotification('打印请求发送失败', 2000);
                                    });
                            } catch (e) {
                                console.error('PaymentScreen: 处理自动打印时出错:', e);
                            }
                        }, 2000); // 增加延迟以确保订单验证完成
                    } else {
                        console.log('PaymentScreen: 不符合自动打印条件，跳过打印');
                    }
                    
                    return result;
                } catch (error) {
                    console.error('PaymentScreen: 验证订单过程中出错:', error);
                    throw error;
                }
            }
            
            showNotification(message, duration = 2000) {
                if (this.env && this.env.pos) {
                    this.env.pos.showNotification(message, duration);
                } else {
                    // 备用显示方法
                    Gui.showPopup('AlertPopup', {
                        title: _t('通知'),
                        body: message,
                    });
                }
            }

            async _finalizeValidation() {
                console.log('PaymentScreen._finalizeValidation: 订单最终验证开始');
                
                try {
                    // 先执行原始验证逻辑
                    await super._finalizeValidation();
                    console.log('PaymentScreen: 订单验证完成');
                    
                    // 不在这里处理自动打印，避免重复打印
                    // 只记录日志用于调试
                    if (this.env.pos.ylcloud_printer) {
                        console.log('PaymentScreen._finalizeValidation: 打印机配置:', {
                            打印机: this.env.pos.ylcloud_printer.name,
                            自动打印: this.env.pos.ylcloud_printer.auto_print,
                            打印订单: this.env.pos.ylcloud_printer.print_order,
                            打印收据: this.env.pos.ylcloud_printer.print_receipt
                        });
                    } else {
                        console.log('PaymentScreen._finalizeValidation: 未配置打印机');
                    }
                } catch (error) {
                    console.error('PaymentScreen._finalizeValidation: 订单最终验证过程中出错:', error);
                    console.error('错误详情:', error.message, error.stack);
                    throw error; // 继续抛出错误以便上层处理
                }
            }
        };

    Registries.Component.extend(PaymentScreen, YLCloudPaymentScreenButtonExt);

    // 扩展收据屏幕，添加打印功能
    const YLCloudReceiptScreenExt = (ReceiptScreen) =>
        class YLCloudReceiptScreenExt extends ReceiptScreen {
            setup() {
                super.setup();
                useListener('print-ylcloud-receipt', this._printYLCloudReceipt);
                console.log('易联云打印收据屏幕扩展初始化完成');
                
                // 组件挂载后检查是否需要自动打印收据
                this.env.posbus.on('order-receipt-rendered', this, () => {
                    console.log('ReceiptScreen: 收据渲染完成，检查是否需要自动打印');
                    this._checkAndPrintReceipt();
                });
            }
            
            _checkAndPrintReceipt() {
                // 检查是否需要自动打印收据
                if (this.env.pos.ylcloud_printer && 
                    this.env.pos.ylcloud_printer.auto_print && 
                    this.env.pos.ylcloud_printer.print_receipt) {
                    console.log('ReceiptScreen: 检测到自动打印条件满足，准备打印收据');
                    
                    // 延迟执行确保界面已完全渲染
                    setTimeout(async () => {
                        try {
                            console.log('ReceiptScreen: 执行延迟自动打印收据');
                            const result = await this._printYLCloudReceipt();
                            console.log('ReceiptScreen: 自动打印收据结果:', result);
                        } catch (error) {
                            console.error('ReceiptScreen: 自动打印收据时出错:', error);
                            console.error('错误详情:', error.message, error.stack);
                            
                            // 向用户显示友好的错误消息
                            Gui.showPopup('ErrorPopup', {
                                title: _t('打印错误'),
                                body: _t('自动打印收据失败: ') + (error.message || '未知错误'),
                            });
                        }
                    }, 2000); // 增加延迟时间
                } else {
                    console.log('ReceiptScreen: 不满足自动打印收据条件，跳过，配置:', {
                        打印机配置: !!this.env.pos.ylcloud_printer,
                        自动打印: this.env.pos.ylcloud_printer ? this.env.pos.ylcloud_printer.auto_print : false,
                        打印收据: this.env.pos.ylcloud_printer ? this.env.pos.ylcloud_printer.print_receipt : false
                    });
                }
            }

            async _printYLCloudReceipt() {
                console.log('ReceiptScreen: 触发易联云收据打印');
                if (!this.env.pos.ylcloud_printer || !this.env.pos.ylcloud_printer.print_receipt) {
                    console.log('ReceiptScreen: 收据打印已配置为禁用或未配置打印机');
                    return false;
                }

                try {
                    const order = this.env.pos.get_order();
                    if (!order) {
                        console.error('ReceiptScreen: 没有选中订单');
                        Gui.showPopup('ErrorPopup', {
                            title: _t('打印错误'),
                            body: _t('当前没有选中的订单'),
                        });
                        return false;
                    }
                    
                    console.log('ReceiptScreen: 获取订单数据，订单ID:', order.name);
                    let receipt, receiptString;
                    
                    try {
                        receipt = order.export_for_printing();
                        console.log('ReceiptScreen: 收据数据获取成功');
                        receiptString = this._generateReceiptText(receipt);
                        console.log('ReceiptScreen: 收据文本生成成功');
                    } catch (formatError) {
                        console.error('ReceiptScreen: 生成收据文本失败:', formatError);
                        console.error('错误详情:', formatError.message, formatError.stack);
                        
                        // 尝试使用备用方法生成收据
                        receiptString = '<CB>' + this.env.pos.company.name + '</CB><BR>';
                        receiptString += '<C>收据打印错误</C><BR>';
                        receiptString += '<C>请联系管理员</C><BR>';
                        receiptString += '<C>错误: ' + formatError.message + '</C>';
                    }
                    
                    // 添加时间戳确保订单ID唯一
                    const timestamp = Math.floor(Date.now());
                    const orderId = 'POSR_' + receipt.name.replace(/\s+/g, '') + '_' + timestamp;
                    console.log('ReceiptScreen: 开始打印收据，ID:', orderId);
                    
                    // 发送打印请求
                    const result = await this.env.pos.printYLCloudReceipt(orderId, receiptString);
                    console.log('ReceiptScreen: 收据打印请求结果:', result);
                    return result;
                } catch (error) {
                    console.error('ReceiptScreen: 收据打印过程中出错:', error);
                    console.error('错误详情:', error.message, error.stack);
                    
                    Gui.showPopup('ErrorPopup', {
                        title: _t('打印错误'),
                        body: _t('收据打印失败: ') + (error.message || '未知错误'),
                    });
                    return false;
                }
            }

            _generateReceiptText(receipt) {
                let receiptLines = [];
                
                // 标题
                receiptLines.push('\n' + this.env.pos.company.name + '\n');
                receiptLines.push('--------------------------------');
                
                // 收据信息
                receiptLines.push('收据号: ' + receipt.name);
                
                // 处理日期格式
                let dateString = '';
                try {
                    if (receipt.date && receipt.date.localestring) {
                        dateString = receipt.date.localestring;
                    } else if (receipt.creation_date) {
                        // Odoo 18中可能使用creation_date
                        dateString = receipt.creation_date;
                    } else {
                        // 备用方案
                        dateString = new Date().toLocaleString();
                    }
                } catch (dateError) {
                    console.error('日期格式化错误:', dateError);
                    dateString = new Date().toLocaleString();
                }
                
                receiptLines.push('日期: ' + dateString);
                
                if (receipt.cashier) {
                    receiptLines.push('收银员: ' + receipt.cashier);
                }
                if (receipt.client) {
                    receiptLines.push('客户: ' + receipt.client.name);
                }
                receiptLines.push('--------------------------------');
                
                // 商品明细
                receiptLines.push('商品明细:');
                for (let line of receipt.orderlines) {
                    let productName = line.product_name;
                    if (productName.length > 20) {
                        productName = productName.substring(0, 17) + '...';
                    }
                    
                    // 处理数量和价格格式
                    let qty = typeof line.quantity === 'number' ? line.quantity : line.qty || 0;
                    let price = '';
                    
                    try {
                        price = this.env.pos.format_currency_no_symbol(line.price_with_tax);
                    } catch (e) {
                        console.error('格式化价格错误:', e);
                        price = line.price_with_tax || 0;
                    }
                    
                    receiptLines.push(productName + ' x ' + qty + ' = ' + price);
                }
                
                receiptLines.push('--------------------------------');
                
                // 合计
                try {
                    receiptLines.push('小计: ' + this.env.pos.format_currency(receipt.subtotal));
                    if (receipt.total_discount) {
                        receiptLines.push('折扣: ' + this.env.pos.format_currency(receipt.total_discount));
                    }
                    if (receipt.total_tax) {
                        receiptLines.push('税额: ' + this.env.pos.format_currency(receipt.total_tax));
                    }
                    receiptLines.push('总计: ' + this.env.pos.format_currency(receipt.total_with_tax));
                } catch (e) {
                    console.error('格式化合计金额错误:', e);
                    receiptLines.push('总计: ' + (receipt.total_with_tax || '0.00'));
                }
                
                // 支付信息
                receiptLines.push('支付方式:');
                if (receipt.paymentlines && receipt.paymentlines.length) {
                    for (let line of receipt.paymentlines) {
                        try {
                            receiptLines.push(line.name + ': ' + this.env.pos.format_currency(line.amount));
                        } catch (e) {
                            console.error('格式化支付方式错误:', e);
                            receiptLines.push(line.name + ': ' + (line.amount || '0.00'));
                        }
                    }
                }
                
                // 找零
                if (receipt.change) {
                    try {
                        receiptLines.push('找零: ' + this.env.pos.format_currency(receipt.change));
                    } catch (e) {
                        console.error('格式化找零错误:', e);
                        receiptLines.push('找零: ' + (receipt.change || '0.00'));
                    }
                }
                
                // 页脚
                receiptLines.push('--------------------------------');
                if (receipt.footer) {
                    receiptLines.push(receipt.footer);
                } else {
                    receiptLines.push('谢谢惠顾! 欢迎再次光临!');
                }
                
                return receiptLines.join('\n');
            }

            async printReceipt() {
                console.log('ReceiptScreen: 正常打印收据，检查是否需要易联云打印');
                console.log('ReceiptScreen: 自动打印配置:', this.env.pos.ylcloud_printer ? {
                    打印机: this.env.pos.ylcloud_printer.name,
                    自动打印: this.env.pos.ylcloud_printer.auto_print,
                    打印收据: this.env.pos.ylcloud_printer.print_receipt
                } : '未配置');
                
                try {
                    const result = await super.printReceipt(...arguments);
                    
                    if (this.env.pos.ylcloud_printer && 
                        this.env.pos.ylcloud_printer.auto_print && 
                        this.env.pos.ylcloud_printer.print_receipt) {
                        console.log('ReceiptScreen: 符合自动打印条件，开始易联云打印收据');
                        // 确保异步执行完成再返回
                        setTimeout(async () => {
                            try {
                                const printResult = await this._printYLCloudReceipt();
                                console.log('ReceiptScreen: 收据打印结果:', printResult);
                            } catch (error) {
                                console.error('ReceiptScreen: 自动打印收据时出错:', error);
                            }
                        }, 1000);
                    } else {
                        console.log('ReceiptScreen: 不符合自动打印收据条件，跳过');
                    }
                    
                    return result;
                } catch (error) {
                    console.error('ReceiptScreen: 打印收据过程中出错:', error);
                    throw error;
                }
            }
        };

    Registries.Component.extend(ReceiptScreen, YLCloudReceiptScreenExt);

    // 扩展订单Model
    const YLCloudOrderExtend = (Order) => class YLCloudOrderExtend extends Order {
        constructor(obj, options) {
            super(...arguments);
            this.isPrinted = false; // 标记订单是否已打印
            
            // 在构造函数中注册状态变化监听器，用于监听订单支付完成事件
            this.on('change:state', this._onOrderStateChange, this);
            
            ylcloudLog('YLCloudOrderExtend构造函数: 订单对象初始化', this.name);
        }
        
        /**
         * 监听订单状态变化，在支付完成时自动打印
         * @private
         * @param {Order} order - 订单对象
         * @param {string} newState - 新状态
         */
        _onOrderStateChange(order, newState) {
            ylcloudLog(`YLCloudOrderExtend._onOrderStateChange: 订单状态变化为 ${newState}`, { 
                orderName: this.name,
                isPrinted: this.isPrinted
            });
            
            // 当订单状态变为 'paid' 时，触发打印
            if (newState === 'paid' && !this.isPrinted) {
                ylcloudLog('YLCloudOrderExtend: 订单已支付，准备自动打印');
                
                // 使用setTimeout避免阻塞主线程，并确保订单完全处理
                setTimeout(() => {
                    this.printOrder().then(result => {
                        ylcloudLog('YLCloudOrderExtend: 自动打印结果', result);
                    }).catch(error => {
                        ylcloudLog('YLCloudOrderExtend: 自动打印失败', error);
                    });
                }, 500);
            }
        }
        
        export_for_printing() {
            console.log('YLCloudOrderExtend.export_for_printing: 准备收据数据');
            try {
                // 调用原始方法获取基本数据
                const receipt = super.export_for_printing();
                
                // 在这里可以扩展收据数据
                console.log('YLCloudOrderExtend: 收据数据准备完成');
                return receipt;
            } catch (error) {
                console.error('YLCloudOrderExtend.export_for_printing: 处理收据数据失败', error);
                throw error;
            }
        }
        
        /**
         * 生成订单打印内容，适用于易联云打印机
         * @returns {string} 格式化后可打印的字符串
         */
        async getOrderPrintContent(order) {
            if (!order) {
                console.error('getOrderPrintContent: 订单为空');
                return null;
            }
            
            console.log('getOrderPrintContent: 开始生成订单打印内容', order);
            
            try {
                // 首先尝试使用order自带的方法获取打印内容
                if (typeof order.getOrderPrintContent === 'function') {
                    console.log('getOrderPrintContent: 使用order.getOrderPrintContent()获取内容');
                    const content = order.getOrderPrintContent();
                    if (content) {
                        console.log('getOrderPrintContent: 使用order方法获取内容成功');
                        return content;
                    }
                }
                
                // 备用方法：使用export_for_printing和格式化
                console.log('getOrderPrintContent: 使用备用方法生成打印内容');
                const orderReceipt = order.export_for_printing();
                if (!orderReceipt) {
                    console.error('getOrderPrintContent: export_for_printing返回为空');
                    return null;
                }
                
                // 使用格式化方法处理打印内容
                const formattedContent = this._formatOrderContent(orderReceipt);
                console.log('getOrderPrintContent: 备用方法生成内容成功');
                
                return formattedContent;
            } catch (error) {
                console.error('getOrderPrintContent: 生成打印内容时发生错误', error);
                return null;
            }
        }
        
        _formatOrderContent(orderReceipt) {
            console.log('_formatOrderContent: 格式化订单内容', orderReceipt);
            let receiptString = '';
            
            // 确定纸张宽度，默认58mm (32字符)
            const paperWidth = this.ylcloud_printer && this.ylcloud_printer.paper_width || '58';
            // 是否为宽纸张 (72mm可打印48个字符)
            const isWidePaper = paperWidth === '72';
            // 根据纸张宽度设置最大字符数
            const maxChars = isWidePaper ? 48 : 32;

            try {
                // 添加公司名称和标题 (使用FS2表示大字体)
                receiptString += '<FS2><center>' + (orderReceipt.company.name || '订单') + '</center></FS2>\n';
                receiptString += '<FS><center>订单小票</center></FS>\n';
                receiptString += '<line>\n';

                // 添加订单基本信息
                receiptString += '订单号: ' + (orderReceipt.name || '') + '\n';
                
                // 处理日期格式
                let dateString = '';
                try {
                    if (orderReceipt.date && orderReceipt.date.localestring) {
                        dateString = orderReceipt.date.localestring;
                    } else if (orderReceipt.creation_date) {
                        // Odoo 18中可能使用creation_date
                        dateString = orderReceipt.creation_date;
                    } else {
                        // 备用方案
                        dateString = new Date().toLocaleString();
                    }
                } catch (dateError) {
                    console.error('日期格式化错误:', dateError);
                    dateString = new Date().toLocaleString();
                }
                
                receiptString += '日期: ' + dateString + '\n';
                
                if (orderReceipt.cashier) {
                    receiptString += '收银员: ' + orderReceipt.cashier + '\n';
                }
                
                if (orderReceipt.client) {
                    receiptString += '客户: ' + orderReceipt.client.name + '\n';
                }
                
                receiptString += '<line>\n';
                
                // 添加商品列表 - 使用表格方式更友好地展示
                // 根据纸张宽度调整表格列宽
                if (isWidePaper) {
                    // 72mm宽纸张，有更多空间
                    receiptString += '<table>\n';
                    receiptString += '<tr><td width="50%">商品</td><td width="15%">数量</td><td width="15%">单价</td><td width="20%">小计</td></tr>\n';
                } else {
                    // 58mm窄纸张，需要紧凑布局
                    receiptString += '<table>\n';
                    receiptString += '<tr><td width="40%">商品</td><td width="20%">数量</td><td width="40%">金额</td></tr>\n';
                }
                
                if (orderReceipt.orderlines && orderReceipt.orderlines.length) {
                    for (const line of orderReceipt.orderlines) {
                        // 计算商品名称最大长度，避免过长
                        const nameMaxLength = isWidePaper ? 20 : 12;
                        // 截断过长的商品名称
                        let productName = line.product_name || '未知商品';
                        if (productName.length > nameMaxLength) {
                            productName = productName.substring(0, nameMaxLength - 2) + '..';
                        }
                        
                        // 格式化数值
                        const quantity = typeof line.quantity === 'number' 
                            ? line.quantity.toFixed(2) 
                            : (line.qty || 0).toFixed(2);
                            
                        const unitPrice = typeof line.price_unit === 'number' 
                            ? line.price_unit.toFixed(2) 
                            : (line.price_display || 0).toFixed(2);
                            
                        const subtotal = typeof line.price_with_tax === 'number' 
                            ? line.price_with_tax.toFixed(2) 
                            : (line.price_with_tax_display || 0).toFixed(2);
                        
                        if (isWidePaper) {
                            // 宽纸张可以展示更多信息
                            receiptString += '<tr>';
                            receiptString += '<td>' + productName + '</td>';
                            receiptString += '<td>' + quantity + '</td>';
                            receiptString += '<td>' + unitPrice + '</td>';
                            receiptString += '<td>' + subtotal + '</td>';
                            receiptString += '</tr>\n';
                        } else {
                            // 窄纸张只展示必要信息
                            receiptString += '<tr>';
                            receiptString += '<td>' + productName + '</td>';
                            receiptString += '<td>' + quantity + '</td>';
                            receiptString += '<td>' + subtotal + '</td>';
                            receiptString += '</tr>\n';
                        }
                    }
                } else {
                    receiptString += '<tr><td colspan="' + (isWidePaper ? '4' : '3') + '">无商品明细</td></tr>\n';
                }
                
                receiptString += '</table>\n';
                receiptString += '<line>\n';
                
                // 添加总计信息 - 确保所有字段存在或提供默认值
                const subtotal = orderReceipt.subtotal 
                    ? (typeof orderReceipt.subtotal === 'number' ? orderReceipt.subtotal.toFixed(2) : orderReceipt.subtotal)
                    : '0.00';
                    
                const tax = orderReceipt.tax 
                    ? (typeof orderReceipt.tax === 'number' ? orderReceipt.tax.toFixed(2) : orderReceipt.tax)
                    : '0.00';
                    
                const total = orderReceipt.total_with_tax 
                    ? (typeof orderReceipt.total_with_tax === 'number' ? orderReceipt.total_with_tax.toFixed(2) : orderReceipt.total_with_tax)
                    : '0.00';
                
                receiptString += '小计: ' + subtotal + '\n';
                
                if (orderReceipt.tax) {
                    receiptString += '税额: ' + tax + '\n';
                }
                
                // 使用FS2放大字体显示总计金额
                receiptString += '<FS2>总计: ' + total + '</FS2>\n';
                receiptString += '<line>\n';
                
                // 添加支付方式
                if (orderReceipt.paymentlines && orderReceipt.paymentlines.length) {
                    receiptString += '<FS>支付方式:</FS>\n';
                    for (const payment of orderReceipt.paymentlines) {
                        // 支持多种格式的支付方式名称
                        const methodName = payment.name || 
                                          (payment.payment_method && payment.payment_method.name) || 
                                          '未知支付方式';
                                          
                        // 支持多种格式的金额字段
                        const amount = typeof payment.amount === 'number' 
                            ? payment.amount.toFixed(2) 
                            : (payment.amount || '0.00');
                            
                        receiptString += methodName + ': ' + amount + '\n';
                    }
                }
                
                // 添加找零
                if (orderReceipt.change) {
                    const change = typeof orderReceipt.change === 'number' 
                        ? orderReceipt.change.toFixed(2) 
                        : orderReceipt.change;
                        
                    receiptString += '<FS>找零: ' + change + '</FS>\n';
                }
                
                // 添加页脚
                receiptString += '<line>\n';
                if (orderReceipt.footer) {
                    receiptString += orderReceipt.footer + '\n';
                } else {
                    receiptString += '<center>谢谢惠顾，欢迎再次光临!</center>\n';
                }
                
                // 添加时间和订单号作为小票底部
                receiptString += '<center>' + new Date().toLocaleString() + '</center>\n';
                receiptString += '<center>单号:' + (orderReceipt.name || '') + '</center>\n';
                
                // 添加切纸指令
                receiptString += '<cut>\n';
                
                console.log('_formatOrderContent: 格式化完成，内容前30个字符:', 
                            receiptString.substring(0, 30) + '...');
                return receiptString;
            } catch (error) {
                console.error('_formatOrderContent: 格式化订单内容失败:', error);
                console.error('错误详情:', error.message, error.stack);
                
                // 返回简单的错误信息作为打印内容
                return '<FS2><center>' + (orderReceipt.company ? orderReceipt.company.name : '订单打印') + '</center></FS2>\n' +
                       '<line>\n' +
                       '订单号: ' + (orderReceipt.name || 'N/A') + '\n' +
                       '<center>格式化订单内容时出错</center>\n' +
                       '<center>' + error.message + '</center>\n' +
                       '<line>\n' +
                       '<center>请联系系统管理员</center>';
            }
        }
        
        // 提供订单打印方法，便于直接调用
        async printOrder() {
            ylcloudLog('调用printOrder方法，准备打印订单');
            
            try {
                if (!this.pos.ylcloud_printer || !this.pos.ylcloud_printer.id) {
                    ylcloudLog('未配置易联云打印机，跳过打印');
                    return false;
                }
                
                if (this.isPrinted) {
                    ylcloudLog('订单已打印过，避免重复打印');
                    return false;
                }

                // 标记订单为已打印
                this.isPrinted = true;
                
                // 获取格式化后的订单内容
                const orderContent = await this.getOrderPrintContent(this);
                ylcloudLog('订单内容已生成', {订单ID: this.uid, 内容长度: orderContent.length});
                
                // 调用POS全局状态打印方法
                const result = await this.pos.printYLCloudReceipt(this.uid, orderContent);
                ylcloudLog('打印结果', result);
                
                return result;
            } catch (error) {
                ylcloudLog('打印订单时发生错误', error);
                if (error.message) {
                    Gui.showPopup('ErrorPopup', {
                        title: '打印错误',
                        body: `打印订单时出错: ${error.message}`,
                    });
                }
                return false;
            }
        }

        async _finalizeValidation() {
            ylcloudLog('YLCloudOrderExtend._finalizeValidation: 订单最终验证开始');
            
            try {
                // 调用父类方法完成基本的验证
                await super._finalizeValidation(...arguments);
                
                // 保存当前订单的引用和名称，避免在延迟函数中丢失
                const currentOrder = this;
                const orderName = this.name;
                const orderUID = this.uid;
                
                // 检查是否配置了易联云打印机并启用了自动打印
                if (this.pos.ylcloud_printer && 
                    this.pos.ylcloud_printer.auto_print && 
                    this.pos.ylcloud_printer.print_order) {
                    
                    ylcloudLog('YLCloudOrderExtend: 满足自动打印条件，延迟1000ms后打印订单', {
                        订单名称: orderName,
                        订单ID: orderUID
                    });
                    
                    // 使用延迟确保订单验证完全完成后再打印
                    setTimeout(async () => {
                        try {
                            ylcloudLog('YLCloudOrderExtend: 开始执行延迟打印，订单:', orderName);
                            
                            // 直接调用订单对象的打印方法
                            const result = await currentOrder.printOrder();
                            ylcloudLog('YLCloudOrderExtend: 延迟打印结果:', result);
                            
                            // 显示打印结果通知
                            if (result && (result.error === 0 || result.error === '0')) {
                                Gui.showPopup('ConfirmPopup', {
                                    title: _t('打印成功'),
                                    body: _t('订单已发送到易联云打印机'),
                                    confirmText: _t('确定'),
                                });
                            }
                        } catch (printError) {
                            ylcloudLog('YLCloudOrderExtend: 延迟打印发生错误', printError);
                            console.error('打印错误详情:', printError.message, printError.stack);
                            
                            // 显示错误通知
                            Gui.showPopup('ErrorPopup', {
                                title: _t('打印错误'),
                                body: printError.message || _t('打印订单时发生未知错误'),
                            });
                        }
                    }, 1000); // 将延迟减少到1000ms，避免等待太久
                } else {
                    const reason = !this.pos.ylcloud_printer ? '未配置打印机' :
                                 !this.pos.ylcloud_printer.auto_print ? '未启用自动打印' :
                                 !this.pos.ylcloud_printer.print_order ? '未启用订单打印' : '未知原因';
                    
                    ylcloudLog(`YLCloudOrderExtend: 不满足自动打印条件，跳过打印。原因: ${reason}`);
                }
            } catch (error) {
                ylcloudLog('YLCloudOrderExtend: 订单验证或打印时发生错误', error);
                console.error('订单验证错误详情:', error.message, error.stack);
                // 错误不应阻止基本功能
                await super._finalizeValidation(...arguments);
            }
        }
    };

    // 扩展POS配置
    const PosYLCloudPrinterConfigExtend = (PosGlobalState) => class PosYLCloudPrinterConfigExtend extends PosGlobalState {
        async _processData(loadedData) {
            ylcloudLog('PosYLCloudPrinterConfigExtend._processData 开始处理数据');
            try {
                const result = await super._processData(...arguments);
                
                // 记录POS配置数据加载情况
                ylcloudLog('POS配置数据', loadedData.pos_session);
                
                if (loadedData.ylcloud_printer) {
                    ylcloudLog('检测到易联云打印机配置', loadedData.ylcloud_printer);
                    
                    // 保存易联云打印机配置
                    this.ylcloud_printer = loadedData.ylcloud_printer;
                    
                    // 设置默认纸张宽度，如果后端没有提供
                    if (!this.ylcloud_printer.paper_width) {
                        this.ylcloud_printer.paper_width = '58'; // 默认58mm纸张宽度
                    }
                    
                    // 记录更多打印机配置信息
                    if (this.ylcloud_printer && this.ylcloud_printer.id) {
                        ylcloudLog('易联云打印机配置完成', {
                            '打印机ID': this.ylcloud_printer.id,
                            '打印机名称': this.ylcloud_printer.name,
                            '纸张宽度': this.ylcloud_printer.paper_width + 'mm',
                            '自动打印': this.ylcloud_printer.auto_print,
                            '打印订单': this.ylcloud_printer.print_order,
                            '打印收据': this.ylcloud_printer.print_receipt
                        });
                        
                        // 初始化打印队列管理器
                        this.printQueueManager = new PrintQueueManager(this);
                        ylcloudLog('打印队列管理器初始化完成');
                        
                        // 测试打印机连接状态
                        this.checkPrinterConnection();
                        
                        // 注册全局订单事件监听
                        this._registerOrderEventHandlers();
                    } else {
                        ylcloudLog('易联云打印机配置不完整或无效', this.ylcloud_printer);
                    }
                } else {
                    ylcloudLog('未检测到易联云打印机配置');
                    this.ylcloud_printer = null;
                }
                
                return result;
            } catch (error) {
                ylcloudLog('_processData处理数据时出错', error);
                console.error('PosYLCloudPrinterConfigExtend._processData错误详情:', error.message, error.stack);
                
                // 出错时也要确保基本功能正常
                return await super._processData(...arguments);
            }
        }
        
        /**
         * 注册全局订单事件监听器
         * @private
         */
        _registerOrderEventHandlers() {
            ylcloudLog('注册全局订单事件监听器');
            
            // 监听已同步订单事件
            this.pos_session.on('order_sync', this._onOrderSync, this);
            
            // 在Odoo 18里，监听结账事件
            this.on('order_paid', this._onOrderPaid, this);
            
            // 订单提交事件
            this.on('order_submitted', this._onOrderSubmitted, this);
            
            ylcloudLog('全局订单事件监听器注册完成');
        }
        
        /**
         * 处理订单同步事件
         * @private
         * @param {Object} order - 同步的订单
         */
        _onOrderSync(order) {
            ylcloudLog('订单同步事件', order?.name);
            // 这里可以添加额外的处理逻辑
        }
        
        /**
         * 处理订单支付完成事件
         * @private
         * @param {Object} order - 支付完成的订单
         */
        _onOrderPaid(order) {
            ylcloudLog('订单支付完成事件', order?.name);
            
            // 确保订单存在并且打印机配置正确
            if (!order || !this.ylcloud_printer || !this.ylcloud_printer.auto_print || !this.ylcloud_printer.print_order) {
                const reason = !order ? '订单为空' :
                            !this.ylcloud_printer ? '未配置打印机' :
                            !this.ylcloud_printer.auto_print ? '未启用自动打印' :
                            !this.ylcloud_printer.print_order ? '未启用订单打印' : '未知原因';
                ylcloudLog(`订单支付后不触发打印，原因: ${reason}`);
                return;
            }
            
            // 标记订单状态为已支付，触发变更事件
            if (typeof order.set_state === 'function') {
                ylcloudLog('设置订单状态为paid', order.name);
                order.set_state('paid');
            }
            
            // 后备方案：如果订单没有自动打印，尝试手动触发
            if (!order.isPrinted && typeof order.printOrder === 'function') {
                ylcloudLog('手动触发订单打印', order.name);
                setTimeout(() => {
                    order.printOrder().then(result => {
                        ylcloudLog('手动触发打印结果', result);
                    }).catch(error => {
                        ylcloudLog('手动触发打印失败', error);
                    });
                }, 500);
            }
        }
        
        /**
         * 处理订单提交事件
         * @private
         * @param {Object} order - 提交的订单
         */
        _onOrderSubmitted(order) {
            ylcloudLog('订单提交事件', order?.name);
            // 可以在这里添加额外的处理逻辑
        }
        
        /**
         * 检查打印机连接状态
         */
        async checkPrinterConnection() {
            if (!this.ylcloud_printer || !this.ylcloud_printer.id) {
                ylcloudLog('无法检查打印机连接: 未配置打印机');
                return { status: 'not_configured' };
            }
            
            try {
                ylcloudLog('开始检查打印机连接状态');
                
                const result = await this.rpc({
                    model: 'ylcloud.printer',
                    method: 'test_connection',
                    args: [this.ylcloud_printer.id],
                }, {
                    timeout: 10000,
                    shadow: true,
                });
                
                ylcloudLog('打印机连接检查结果', result);
                
                // 更新打印机状态
                this.printerConnectionStatus = result && (result.error === 0 || result.error === '0') 
                    ? 'connected' 
                    : 'disconnected';
                
                // 如果连接成功，可以发送一条简短的测试打印
                if (this.printerConnectionStatus === 'connected' && this.ylcloud_printer.debug_mode) {
                    setTimeout(() => {
                        const testContent = '<FS><center>打印机连接测试</center></FS>\n' +
                                          '<line>\n' +
                                          '时间: ' + new Date().toLocaleString() + '\n' +
                                          '打印机: ' + this.ylcloud_printer.name + '\n' +
                                          '<line>\n' +
                                          '<center>易联云POS打印插件</center>\n<cut>\n';
                        
                        this.debugPrintYLCloud(testContent);
                    }, 1000);
                }
                
                return {
                    status: this.printerConnectionStatus,
                    details: result
                };
            } catch (error) {
                ylcloudLog('检查打印机连接时出错', error);
                this.printerConnectionStatus = 'error';
                return {
                    status: 'error',
                    error: error.message
                };
            }
        }

        // 发送打印请求 - 使用打印队列管理
        async printYLCloudReceipt(receiptId, content, originId) {
            console.log('printYLCloudReceipt: 开始打印易联云订单', {receiptId, contentLength: content?.length, originId});
            
            if (!receiptId || !content) {
                console.error('printYLCloudReceipt: 参数错误, receiptId或content为空');
                return {
                    error: 'invalid_params',
                    error_description: '参数错误: 订单ID或打印内容为空'
                };
            }
            
            if (!this.ylcloud_printer || !this.ylcloud_printer.id) {
                console.error('printYLCloudReceipt: 未配置易联云打印机');
                return {
                    error: 'printer_not_configured',
                    error_description: '未配置易联云打印机'
                };
            }

            const params = {
                partner: this.ylcloud_printer.partner_id,
                machine_code: this.ylcloud_printer.machine_code,
                receipt_id: receiptId,
                content: content,
            };
            
            if (originId) {
                params.origin_id = originId;
            }
            
            return await this._makeYLCloudRequest('print', params);
        }
        
        // 直接发送打印请求 - 不使用队列管理
        async _directPrintYLCloudReceipt(orderId, content) {
            try {
                console.log('_directPrintYLCloudReceipt: 开始直接打印, 订单ID:', orderId);
                
                // 获取打印机配置
                const printer = this.ylcloud_printer;
                if (!printer || !printer.id) {
                    console.error('_directPrintYLCloudReceipt: 未配置易联云打印机');
                    return { error: 'no_printer', error_description: '未配置易联云打印机' };
                }
                
                // 构建打印参数
                const params = {
                    machine_code: printer.machine_code,
                    content: content,
                    origin_id: orderId
                };
                
                // 验证签名数据
                if (!params.machine_code || !params.content) {
                    console.error('_directPrintYLCloudReceipt: 参数验证失败', params);
                    return { error: 'invalid_params', error_description: '打印参数无效' };
                }
                
                console.log('_directPrintYLCloudReceipt: 发送打印请求中...');
                
                // 发送打印请求到服务器
                const rawResult = await this._makeYLCloudRequest('printMsg', params);
                
                // 处理响应结果
                if (!rawResult) {
                    console.error('_directPrintYLCloudReceipt: 服务器无响应');
                    return { error: 'no_response', error_description: '服务器无响应' };
                }
                
                // 解析服务器响应
                let result;
                try {
                    result = typeof rawResult === 'string' ? JSON.parse(rawResult) : rawResult;
                } catch (parseError) {
                    console.error('_directPrintYLCloudReceipt: 响应解析失败', rawResult);
                    return { error: 'parse_error', error_description: '响应解析失败', raw: rawResult };
                }
                
                // 记录服务器响应
                console.log('_directPrintYLCloudReceipt: 服务器响应:', result);
                
                // 根据API状态码判断结果
                if (result.error === 0) {
                    // 打印成功
                    console.log('_directPrintYLCloudReceipt: 打印请求成功');
                    this.showNotification('打印请求发送成功', 2000);
                    return { success: true, data: result.data || {} };
                } else {
                    // 打印失败，处理错误信息
                    const errorCode = result.error;
                    const errorMsg = result.error_description || '未知错误';
                    
                    console.error(`_directPrintYLCloudReceipt: 打印请求失败 [${errorCode}]: ${errorMsg}`);
                    
                    // 通知用户
                    this.showNotification(`打印失败: ${errorMsg}`, 3000);
                    
                    // 记录详细错误信息
                    const errorDetails = {
                        time: new Date().toISOString(),
                        orderId: orderId,
                        errorCode: errorCode,
                        errorMsg: errorMsg
                    };
                    
                    // 存储错误日志 - 可选实现本地存储
                    this._logPrintError && this._logPrintError(errorDetails);
                    
                    return { error: errorCode, error_description: errorMsg };
                }
            } catch (error) {
                // 处理异常
                console.error('_directPrintYLCloudReceipt: 执行异常', error);
                
                // 通知用户
                this.showNotification('打印请求异常: ' + (error.message || '未知错误'), 3000);
                
                // 返回错误信息
                return {
                    error: 'exception',
                    error_description: error.message || '未知异常',
                    stack: error.stack
                };
            }
        }
        
        // 公开全局打印方法，便于调试和手动调用
        async debugPrintYLCloud(content) {
            const testId = 'TEST_' + Date.now();
            return await this.printYLCloudReceipt(testId, content || '测试内容');
        }

        /**
         * 测试易联云打印机的各种指令标签
         * 开发者可以通过浏览器控制台调用此方法测试打印效果
         * 示例: this.env.pos.debugPrintText()
         * @returns {Promise<Object>} 打印结果
         */
        async debugPrintText() {
            const timestamp = Date.now();
            const testId = 'DEBUG_' + timestamp;
            let content = '';
            
            // 标题示例
            content += '<FS2><center>易联云打印测试</center></FS2>\n';
            content += '<FS><center>标签指令演示</center></FS>\n';
            content += '<line>\n';
            
            // 各种字体大小示例
            content += '普通字体效果\n';
            content += '<FS>放大字体效果</FS>\n';
            content += '<FS2>更大字体效果</FS2>\n';
            content += '<line>\n';
            
            // 对齐方式示例
            content += '<left>左对齐文本</left>\n';
            content += '<center>居中对齐文本</center>\n';
            content += '<right>右对齐文本</right>\n';
            content += '<line>\n';
            
            // 表格示例
            content += '<B>表格示例:</B>\n';
            content += '<table>\n';
            content += '<tr><td width="25%">列1</td><td width="25%">列2</td><td width="25%">列3</td><td width="25%">列4</td></tr>\n';
            content += '<tr><td>数据1</td><td>数据2</td><td>数据3</td><td>数据4</td></tr>\n';
            content += '</table>\n';
            content += '<line>\n';
            
            // 各种格式化组合示例
            content += '<B>加粗文本</B>\n';
            content += '<C>居中文本</C>\n';
            content += '<CB>加粗居中</CB>\n';
            content += '<BOLD>另一种加粗</BOLD>\n';
            content += '<line>\n';
            
            // 测试条码/二维码
            content += '<center>条码测试</center>\n';
            content += '<BR>123456789012</BR>\n';
            content += '<center>二维码测试</center>\n';
            content += '<QR>https://www.example.com</QR>\n';
            content += '<line>\n';
            
            // 文本处理示例
            content += '中英文混合: Hello 你好\n';
            content += '特殊字符: !@#$%^&*()\n';
            content += '数字: 1234567890\n';
            content += '<line>\n';
            
            // 页脚和测试信息
            content += '<center>测试完成</center>\n';
            content += '<center>' + new Date().toLocaleString() + '</center>\n';
            content += '<center>ID: ' + testId + '</center>\n';
            content += '<cut>\n';
            
            console.log('开始发送测试打印内容...');
            const result = await this.printYLCloudReceipt(testId, content);
            
            // 显示结果
            if (result && (result.error === 0 || result.error === '0')) {
                Gui.showPopup('InfoPopup', {
                    title: _t('测试打印成功'),
                    body: _t('易联云打印机测试内容已发送，请检查打印结果'),
                });
            } else {
                const errorMsg = result && result.error_description 
                    ? result.error_description 
                    : '未知错误';
                    
                Gui.showPopup('ErrorPopup', {
                    title: _t('测试打印失败'),
                    body: _t('错误信息: ' + errorMsg),
                });
            }
            
            return result;
        }

        /**
         * 打印易联云订单
         * @param {Order} order 订单对象
         * @returns {Promise<Object>} 打印结果
         * @private
         */
        async _printYLCloudOrder(order) {
            console.log('_printYLCloudOrder: 开始处理易联云打印订单', order?.name);
            
            // 生成订单的唯一ID - 使用POS_前缀 + order.uid + 时间戳，确保唯一性
            const orderId = `POS_${order.uid}_${new Date().getTime()}`;
            
            // 检查订单内容生成方法是否存在
            if (!this.getOrderPrintContent) {
                console.error('_printYLCloudOrder: 无法获取订单打印内容，缺少getOrderPrintContent方法');
                this.pos.showTempScreen('error-popup', {error: '打印失败', message: '系统错误: 无法获取订单打印内容'});
                return false;
            }
            
            // 获取订单打印内容
            const receiptContent = await this.getOrderPrintContent(order);
            if (!receiptContent) {
                console.error('_printYLCloudOrder: 获取订单打印内容失败');
                this.pos.showTempScreen('error-popup', {error: '打印失败', message: '无法生成订单打印内容'});
                return false;
            }
            
            try {
                // 发送打印请求并等待结果
                const printResult = await this.printYLCloudReceipt(orderId, receiptContent, orderId);
                console.log('_printYLCloudOrder: 打印结果', printResult);
                
                // 检查打印结果
                if (printResult.error) {
                    console.error('_printYLCloudOrder: 打印请求失败', printResult.error, printResult.error_description);
                    this.pos.showTempScreen('error-popup', {
                        error: '打印失败', 
                        message: printResult.error_description || '连接打印服务失败，请检查网络和打印机状态'
                    });
                    return false;
                } else {
                    console.log('_printYLCloudOrder: 打印请求成功', printResult);
                    this.pos.showTempScreen('confirm', {
                        title: '打印成功',
                        body: '订单已成功发送到易联云打印机',
                        confirmText: '确定'
                    });
                    return true;
                }
            } catch (error) {
                console.error('_printYLCloudOrder: 打印过程出现异常', error);
                this.pos.showTempScreen('error-popup', {
                    error: '打印异常', 
                    message: '打印服务异常，请重试或联系管理员'
                });
                return false;
            }
        }
        
        /**
         * 格式化订单内容为易联云打印机可识别的格式
         * @private
         * @param {Object} orderReceipt - 订单接收数据
         * @returns {string} 格式化后的订单内容
         */
        _formatOrderContent(orderReceipt) {
            console.log('_formatOrderContent: 格式化订单内容', orderReceipt);
            let receiptString = '';
            
            // 确定纸张宽度，默认58mm (32字符)
            const paperWidth = this.ylcloud_printer && this.ylcloud_printer.paper_width || '58';
            // 是否为宽纸张 (72mm可打印48个字符)
            const isWidePaper = paperWidth === '72';
            // 根据纸张宽度设置最大字符数
            const maxChars = isWidePaper ? 48 : 32;

            try {
                // 添加公司名称和标题 (使用FS2表示大字体)
                receiptString += '<FS2><center>' + (orderReceipt.company.name || '订单') + '</center></FS2>\n';
                receiptString += '<FS><center>订单小票</center></FS>\n';
                receiptString += '<line>\n';

                // 添加订单基本信息
                receiptString += '订单号: ' + (orderReceipt.name || '') + '\n';
                
                // 处理日期格式
                let dateString = '';
                try {
                    if (orderReceipt.date && orderReceipt.date.localestring) {
                        dateString = orderReceipt.date.localestring;
                    } else if (orderReceipt.creation_date) {
                        // Odoo 18中可能使用creation_date
                        dateString = orderReceipt.creation_date;
                    } else {
                        // 备用方案
                        dateString = new Date().toLocaleString();
                    }
                } catch (dateError) {
                    console.error('日期格式化错误:', dateError);
                    dateString = new Date().toLocaleString();
                }
                
                receiptString += '日期: ' + dateString + '\n';
                
                if (orderReceipt.cashier) {
                    receiptString += '收银员: ' + orderReceipt.cashier + '\n';
                }
                
                if (orderReceipt.client) {
                    receiptString += '客户: ' + orderReceipt.client.name + '\n';
                }
                
                receiptString += '<line>\n';
                
                // 添加商品列表 - 使用表格方式更友好地展示
                // 根据纸张宽度调整表格列宽
                if (isWidePaper) {
                    // 72mm宽纸张，有更多空间
                    receiptString += '<table>\n';
                    receiptString += '<tr><td width="50%">商品</td><td width="15%">数量</td><td width="15%">单价</td><td width="20%">小计</td></tr>\n';
                } else {
                    // 58mm窄纸张，需要紧凑布局
                    receiptString += '<table>\n';
                    receiptString += '<tr><td width="40%">商品</td><td width="20%">数量</td><td width="40%">金额</td></tr>\n';
                }
                
                if (orderReceipt.orderlines && orderReceipt.orderlines.length) {
                    for (const line of orderReceipt.orderlines) {
                        // 计算商品名称最大长度，避免过长
                        const nameMaxLength = isWidePaper ? 20 : 12;
                        // 截断过长的商品名称
                        let productName = line.product_name || '未知商品';
                        if (productName.length > nameMaxLength) {
                            productName = productName.substring(0, nameMaxLength - 2) + '..';
                        }
                        
                        // 格式化数值
                        const quantity = typeof line.quantity === 'number' 
                            ? line.quantity.toFixed(2) 
                            : (line.qty || 0).toFixed(2);
                            
                        const unitPrice = typeof line.price_unit === 'number' 
                            ? line.price_unit.toFixed(2) 
                            : (line.price_display || 0).toFixed(2);
                            
                        const subtotal = typeof line.price_with_tax === 'number' 
                            ? line.price_with_tax.toFixed(2) 
                            : (line.price_with_tax_display || 0).toFixed(2);
                        
                        if (isWidePaper) {
                            // 宽纸张可以展示更多信息
                            receiptString += '<tr>';
                            receiptString += '<td>' + productName + '</td>';
                            receiptString += '<td>' + quantity + '</td>';
                            receiptString += '<td>' + unitPrice + '</td>';
                            receiptString += '<td>' + subtotal + '</td>';
                            receiptString += '</tr>\n';
                        } else {
                            // 窄纸张只展示必要信息
                            receiptString += '<tr>';
                            receiptString += '<td>' + productName + '</td>';
                            receiptString += '<td>' + quantity + '</td>';
                            receiptString += '<td>' + subtotal + '</td>';
                            receiptString += '</tr>\n';
                        }
                    }
                } else {
                    receiptString += '<tr><td colspan="' + (isWidePaper ? '4' : '3') + '">无商品明细</td></tr>\n';
                }
                
                receiptString += '</table>\n';
                receiptString += '<line>\n';
                
                // 添加总计信息 - 确保所有字段存在或提供默认值
                const subtotal = orderReceipt.subtotal 
                    ? (typeof orderReceipt.subtotal === 'number' ? orderReceipt.subtotal.toFixed(2) : orderReceipt.subtotal)
                    : '0.00';
                    
                const tax = orderReceipt.tax 
                    ? (typeof orderReceipt.tax === 'number' ? orderReceipt.tax.toFixed(2) : orderReceipt.tax)
                    : '0.00';
                    
                const total = orderReceipt.total_with_tax 
                    ? (typeof orderReceipt.total_with_tax === 'number' ? orderReceipt.total_with_tax.toFixed(2) : orderReceipt.total_with_tax)
                    : '0.00';
                
                receiptString += '小计: ' + subtotal + '\n';
                
                if (orderReceipt.tax) {
                    receiptString += '税额: ' + tax + '\n';
                }
                
                // 使用FS2放大字体显示总计金额
                receiptString += '<FS2>总计: ' + total + '</FS2>\n';
                receiptString += '<line>\n';
                
                // 添加支付方式
                if (orderReceipt.paymentlines && orderReceipt.paymentlines.length) {
                    receiptString += '<FS>支付方式:</FS>\n';
                    for (const payment of orderReceipt.paymentlines) {
                        // 支持多种格式的支付方式名称
                        const methodName = payment.name || 
                                          (payment.payment_method && payment.payment_method.name) || 
                                          '未知支付方式';
                                          
                        // 支持多种格式的金额字段
                        const amount = typeof payment.amount === 'number' 
                            ? payment.amount.toFixed(2) 
                            : (payment.amount || '0.00');
                            
                        receiptString += methodName + ': ' + amount + '\n';
                    }
                }
                
                // 添加找零
                if (orderReceipt.change) {
                    const change = typeof orderReceipt.change === 'number' 
                        ? orderReceipt.change.toFixed(2) 
                        : orderReceipt.change;
                        
                    receiptString += '<FS>找零: ' + change + '</FS>\n';
                }
                
                // 添加页脚
                receiptString += '<line>\n';
                if (orderReceipt.footer) {
                    receiptString += orderReceipt.footer + '\n';
                } else {
                    receiptString += '<center>谢谢惠顾，欢迎再次光临!</center>\n';
                }
                
                // 添加时间和订单号作为小票底部
                receiptString += '<center>' + new Date().toLocaleString() + '</center>\n';
                receiptString += '<center>单号:' + (orderReceipt.name || '') + '</center>\n';
                
                // 添加切纸指令
                receiptString += '<cut>\n';
                
                console.log('_formatOrderContent: 格式化完成，内容前30个字符:', 
                            receiptString.substring(0, 30) + '...');
                return receiptString;
            } catch (error) {
                console.error('_formatOrderContent: 格式化订单内容失败:', error);
                console.error('错误详情:', error.message, error.stack);
                
                // 返回简单的错误信息作为打印内容
                return '<FS2><center>' + (orderReceipt.company ? orderReceipt.company.name : '订单打印') + '</center></FS2>\n' +
                       '<line>\n' +
                       '订单号: ' + (orderReceipt.name || 'N/A') + '\n' +
                       '<center>格式化订单内容时出错</center>\n' +
                       '<center>' + error.message + '</center>\n' +
                       '<line>\n' +
                       '<center>请联系系统管理员</center>';
            }
        }

        /**
         * 发送请求到易联云API
         * @param {String} apiName - API名称
         * @param {Object} params - 请求参数
         * @returns {Promise} - 返回请求结果
         */
        async _makeYLCloudRequest(apiName, params) {
            try {
                console.log(`_makeYLCloudRequest: 调用易联云API [${apiName}]`, params);
                
                // 调用后端服务转发请求到易联云
                const result = await this.rpc({
                    model: 'ylcloud.printer',
                    method: 'call_ylcloud_api',
                    args: [this.ylcloud_printer.id, apiName, params],
                    kwargs: {},
                }, {
                    timeout: 20000, // 20秒超时
                    shadow: true,   // 静默错误，自行处理
                });
                
                console.log(`_makeYLCloudRequest: API [${apiName}] 返回结果:`, result);
                return result;
            } catch (error) {
                console.error(`_makeYLCloudRequest: API [${apiName}] 请求异常:`, error);
                // 转换为统一的错误格式
                return {
                    error: error.code || 'network_error',
                    error_description: error.message || '网络请求异常'
                };
            }
        }
    };

    // 确保注册订单扩展和POS配置扩展
    Registries.Model.extend(Order, YLCloudOrderExtend);
    Registries.Model.extend(PosGlobalState, PosYLCloudPrinterConfigExtend);

    return {
        YLCloudPrintButton,
        YLCloudReceiptPrintButton,
        YLCloudPaymentScreenButtonExt,
        YLCloudReceiptScreenExt,
        YLCloudOrderExtend,
        PosYLCloudPrinterConfigExtend
    };
}); 