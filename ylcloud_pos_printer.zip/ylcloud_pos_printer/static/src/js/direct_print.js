odoo.define('ylcloud_pos_printer.direct_print', function (require) {
    'use strict';

    const Registries = require('point_of_sale.Registries');
    const { PosGlobalState } = require('point_of_sale.models');
    const { Gui } = require('point_of_sale.Gui');
    
    /**
     * 直接打印处理器 - 监听全局订单事件直接触发打印
     * 这是另一个保障机制，确保即使其他钩子失效也能触发打印
     */
    const YLCloudDirectPrintHandler = (PosGlobalState) =>
        class YLCloudDirectPrintHandlerExt extends PosGlobalState {
            /**
             * 覆盖Odoo 18中的方法，在POS全局状态初始化完成后调用
             */
            async afterLoad() {
                // 先调用父类方法
                await super.afterLoad(...arguments);
                
                console.log('YLCloudDirectPrintHandler: POS初始化完成，注册订单事件监听器');
                
                // 注册订单提交事件监听器 - Odoo 18特有
                this.orderSubmittedUUIDs = new Set();
                this.on('order_submitting', this._onBeforeOrderSubmit, this);
                this.on('order_submitted', this._onOrderSubmitted, this);
                
                // 注册当前界面变更事件
                this.on('change:current_screen_name', this._onScreenChanged, this);
                
                // 加载时检查打印机配置
                this._checkPrinterConfig();
            }
            
            /**
             * 检查打印机配置
             * @private
             */
            _checkPrinterConfig() {
                if (this.ylcloud_printer && this.ylcloud_printer.id) {
                    console.log('YLCloudDirectPrintHandler: 打印机配置已加载', {
                        打印机ID: this.ylcloud_printer.id,
                        自动打印: this.ylcloud_printer.auto_print,
                        打印订单: this.ylcloud_printer.print_order,
                        纸张宽度: this.ylcloud_printer.paper_width
                    });
                } else {
                    console.log('YLCloudDirectPrintHandler: 未检测到打印机配置');
                    
                    // 尝试从POS配置中读取打印机信息
                    const printerID = this.config && this.config.yl_printer_id;
                    if (printerID && printerID.length) {
                        console.log('YLCloudDirectPrintHandler: 从POS配置中找到打印机ID', printerID);
                        
                        // 尝试加载打印机配置
                        this._loadPrinterConfig(printerID[0]);
                    }
                }
            }
            
            /**
             * 从服务器加载打印机配置
             * @private
             * @param {number} printerId 打印机ID
             */
            async _loadPrinterConfig(printerId) {
                try {
                    console.log('YLCloudDirectPrintHandler: 从服务器加载打印机配置', printerId);
                    
                    const printerData = await this.rpc({
                        model: 'ylcloud.printer',
                        method: 'read',
                        args: [[printerId], ['name', 'machine_code', 'partner_id', 'auto_print', 'print_order', 'print_receipt', 'paper_width']],
                    });
                    
                    if (printerData && printerData.length) {
                        console.log('YLCloudDirectPrintHandler: 打印机配置加载成功', printerData[0]);
                        
                        // 设置打印机配置
                        this.ylcloud_printer = printerData[0];
                    }
                } catch (error) {
                    console.error('YLCloudDirectPrintHandler: 加载打印机配置失败', error);
                }
            }
            
            /**
             * 订单提交前处理
             * @private
             * @param {Object} orderData 订单数据
             */
            _onBeforeOrderSubmit(orderData) {
                console.log('YLCloudDirectPrintHandler: 订单即将提交', orderData?.name);
                
                // 记录订单ID，防止重复处理
                if (orderData && orderData.uid) {
                    this.orderSubmittedUUIDs.add(orderData.uid);
                }
            }
            
            /**
             * 处理订单提交事件
             * @private
             * @param {Object} orderData 提交的订单数据
             */
            _onOrderSubmitted(orderData) {
                if (!orderData) {
                    console.log('YLCloudDirectPrintHandler: 提交的订单数据为空');
                    return;
                }
                
                console.log('YLCloudDirectPrintHandler: 订单提交完成', orderData.name);
                
                // 检查是否需要自动打印
                if (!this.ylcloud_printer || !this.ylcloud_printer.auto_print || !this.ylcloud_printer.print_order) {
                    const reason = !this.ylcloud_printer ? '未配置打印机' :
                                  !this.ylcloud_printer.auto_print ? '未启用自动打印' :
                                  !this.ylcloud_printer.print_order ? '未启用订单打印' : '未知原因';
                    
                    console.log(`YLCloudDirectPrintHandler: 不满足自动打印条件，跳过打印。原因: ${reason}`);
                    return;
                }
                
                // 获取当前订单对象
                const order = this.get_order();
                if (!order) {
                    console.log('YLCloudDirectPrintHandler: 无法获取当前订单对象');
                    return;
                }
                
                // 检查订单是否已经处理过
                if (order.uid && this.orderSubmittedUUIDs.has(order.uid)) {
                    console.log('YLCloudDirectPrintHandler: 订单已经触发过打印', order.name);
                    this.orderSubmittedUUIDs.delete(order.uid); // 清理记录
                    return;
                }
                
                // 延迟执行打印，确保订单处理完成
                setTimeout(() => {
                    this._triggerOrderPrint(order);
                }, 1000);
            }
            
            /**
             * 屏幕变更事件处理
             * @private
             * @param {string} screenName 当前屏幕名称
             */
            _onScreenChanged(screenName) {
                console.log('YLCloudDirectPrintHandler: 屏幕切换到', screenName);
                
                // 当进入收据屏幕时，可能是订单提交完成
                if (screenName === 'ReceiptScreen') {
                    const order = this.get_order();
                    if (order && !order.isPrinted) {
                        console.log('YLCloudDirectPrintHandler: 检测到进入收据屏幕，尝试触发打印', order.name);
                        
                        // 延迟执行打印，确保订单处理完成
                        setTimeout(() => {
                            this._triggerOrderPrint(order);
                        }, 500);
                    }
                }
            }
            
            /**
             * 触发订单打印
             * @private
             * @param {Object} order 订单对象
             */
            async _triggerOrderPrint(order) {
                if (!order) {
                    console.log('YLCloudDirectPrintHandler: 没有可打印的订单');
                    return;
                }
                
                console.log('YLCloudDirectPrintHandler: 准备打印订单', order.name);
                
                // 检查是否已经打印过，避免重复打印
                if (order.isPrinted) {
                    console.log('YLCloudDirectPrintHandler: 订单已打印过，跳过', order.name);
                    return;
                }
                
                try {
                    let printResult;
                    
                    // 获取打印服务
                    const env = this.env || {};
                    const printerService = env.services && env.services.printer;
                    
                    if (printerService) {
                        // 使用打印服务
                        console.log('YLCloudDirectPrintHandler: 通过PrinterService打印订单');
                        printResult = await printerService.printOrder(order);
                    } else if (typeof order.printOrder === 'function') {
                        // 使用订单对象的打印方法
                        console.log('YLCloudDirectPrintHandler: 通过订单对象方法打印');
                        printResult = await order.printOrder();
                    } else if (typeof this._printYLCloudOrder === 'function') {
                        // 使用POS对象的打印方法
                        console.log('YLCloudDirectPrintHandler: 通过POS对象方法打印');
                        printResult = await this._printYLCloudOrder(order);
                    } else {
                        console.error('YLCloudDirectPrintHandler: 没有找到可用的打印方法');
                        return;
                    }
                    
                    console.log('YLCloudDirectPrintHandler: 打印结果', printResult);
                    
                    // 标记订单为已打印
                    order.isPrinted = true;
                    
                    // 显示打印结果通知
                    if (printResult && (printResult.error === 0 || printResult.error === '0')) {
                        console.log('YLCloudDirectPrintHandler: 打印成功');
                        this._showPrintSuccessMessage();
                    } else {
                        console.error('YLCloudDirectPrintHandler: 打印失败', printResult);
                        this._showPrintErrorMessage(printResult);
                    }
                } catch (error) {
                    console.error('YLCloudDirectPrintHandler: 打印过程异常', error);
                    this._showPrintErrorMessage({ error: 'exception', error_description: error.message });
                }
            }
            
            /**
             * 显示打印成功消息
             * @private
             */
            _showPrintSuccessMessage() {
                if (typeof Gui.showPopup !== 'function') return;
                
                Gui.showPopup('ConfirmPopup', {
                    title: '打印成功',
                    body: '订单已发送到易联云打印机',
                    confirmText: '确定',
                });
            }
            
            /**
             * 显示打印错误消息
             * @private
             * @param {Object} result 错误结果
             */
            _showPrintErrorMessage(result) {
                if (typeof Gui.showPopup !== 'function') return;
                
                const errorMsg = result && result.error_description 
                    ? result.error_description 
                    : '未知错误';
                
                Gui.showPopup('ErrorPopup', {
                    title: '打印失败',
                    body: `打印请求失败: ${errorMsg}`,
                });
            }
        };

    // 注册POS全局状态扩展
    Registries.Model.extend(PosGlobalState, YLCloudDirectPrintHandler);
    
    return YLCloudDirectPrintHandler;
}); 