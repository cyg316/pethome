odoo.define('ylcloud_pos_printer.PrinterService', function (require) {
    'use strict';

    const { Component } = owl;
    const { Gui } = require('point_of_sale.Gui');
    const PaymentScreen = require('point_of_sale.PaymentScreen');
    const ReceiptScreen = require('point_of_sale.ReceiptScreen');
    const AbstractService = require('point_of_sale.AbstractService');
    const Registries = require('point_of_sale.Registries');

    /**
     * YLCloud打印服务 - 集中管理所有与打印机相关的操作
     */
    class PrinterService extends AbstractService {
        constructor() {
            super(...arguments);
            this.isPrinting = false; // 防止重复打印
            this.printerConnectionStatus = 'unknown'; // 打印机连接状态
            this.printHistory = []; // 打印历史记录
        }

        /**
         * 初始化服务，在POS启动时调用
         * @param {Object} pos - POS全局状态对象
         */
        async start(pos) {
            this.pos = pos;
            console.log('YLCloud打印服务启动', {
                打印机配置: this.pos.ylcloud_printer ? '已配置' : '未配置'
            });

            // 在POS启动完成后检查打印机连接状态
            if (this.pos.ylcloud_printer && this.pos.ylcloud_printer.id) {
                setTimeout(() => {
                    this.checkPrinterConnection();
                }, 2000);
            }
        }

        /**
         * 检查打印机连接状态
         * @returns {Promise<Object>} 连接状态对象
         */
        async checkPrinterConnection() {
            if (!this.pos.ylcloud_printer || !this.pos.ylcloud_printer.id) {
                console.log('PrinterService: 无法检查打印机连接: 未配置打印机');
                this.printerConnectionStatus = 'not_configured';
                return { status: 'not_configured' };
            }
            
            try {
                console.log('PrinterService: 开始检查打印机连接状态');
                
                const result = await this.pos.rpc({
                    model: 'ylcloud.printer',
                    method: 'test_connection',
                    args: [this.pos.ylcloud_printer.id],
                }, {
                    timeout: 10000,
                    shadow: true,
                });
                
                console.log('PrinterService: 打印机连接检查结果', result);
                
                // 更新打印机状态
                this.printerConnectionStatus = result && (result.error === 0 || result.error === '0') 
                    ? 'connected' 
                    : 'disconnected';
                
                return {
                    status: this.printerConnectionStatus,
                    details: result
                };
            } catch (error) {
                console.error('PrinterService: 检查打印机连接时出错', error);
                this.printerConnectionStatus = 'error';
                return {
                    status: 'error',
                    error: error.message
                };
            }
        }

        /**
         * 打印订单 - 主要方法，集中处理所有订单打印逻辑
         * @param {Object} order - 订单对象
         * @returns {Promise<Object>} 打印结果
         */
        async printOrder(order) {
            console.log('PrinterService: 开始打印订单', order?.name);
            
            if (this.isPrinting) {
                console.log('PrinterService: 已有打印任务正在执行，避免重复打印');
                return { error: 'printing_in_progress', error_description: '有打印任务正在执行' };
            }
            
            if (!order) {
                console.error('PrinterService: 打印订单为空');
                return { error: 'invalid_order', error_description: '订单对象无效' };
            }
            
            if (!this.pos.ylcloud_printer || !this.pos.ylcloud_printer.id) {
                console.error('PrinterService: 未配置易联云打印机');
                return { error: 'printer_not_configured', error_description: '未配置易联云打印机' };
            }

            // 标记打印中状态，防止重复打印
            this.isPrinting = true;
            
            try {
                // 生成唯一订单ID，使用前缀+订单ID+时间戳确保唯一性
                const timestamp = new Date().getTime();
                const printOrderId = `POS_${order.uid}_${timestamp}`;
                console.log('PrinterService: 生成打印订单ID:', printOrderId);
                
                // 获取订单内容 - 调用订单的方法生成打印内容
                let orderContent;
                
                // 检查订单是否有自己的内容生成方法
                if (typeof order.getOrderPrintContent === 'function') {
                    orderContent = await order.getOrderPrintContent(order);
                } else {
                    // 备用方案：使用基本格式化
                    orderContent = this._formatBasicOrderContent(order);
                }
                
                if (!orderContent) {
                    console.error('PrinterService: 生成订单内容失败');
                    this.isPrinting = false;
                    return { error: 'content_generation_failed', error_description: '无法生成订单打印内容' };
                }
                
                console.log('PrinterService: 订单内容生成成功，内容长度:', orderContent.length);
                
                // 发送打印请求
                const result = await this._sendPrintRequest(printOrderId, orderContent);
                console.log('PrinterService: 打印请求结果:', result);
                
                // 标记订单为已打印
                if (order.isPrinted !== undefined) {
                    order.isPrinted = true;
                }
                
                // 记录打印历史
                this._addToPrintHistory({
                    id: printOrderId,
                    orderName: order.name,
                    timestamp: timestamp,
                    result: result
                });
                
                // 返回结果前解除打印中状态
                this.isPrinting = false;
                
                // 根据打印结果显示通知
                this._showPrintResultNotification(result);
                
                return result;
            } catch (error) {
                console.error('PrinterService: 打印订单过程中出错:', error);
                
                // 解除打印中状态
                this.isPrinting = false;
                
                // 显示错误通知
                Gui.showPopup('ErrorPopup', {
                    title: '打印错误',
                    body: error.message || '打印订单时发生未知错误',
                });
                
                return {
                    error: 'exception',
                    error_description: error.message || '打印过程异常'
                };
            }
        }

        /**
         * 发送打印请求到易联云API
         * @private
         * @param {string} receiptId - 打印任务ID
         * @param {string} content - 打印内容
         * @returns {Promise<Object>} 打印结果
         */
        async _sendPrintRequest(receiptId, content) {
            console.log('PrinterService: 发送打印请求', { receiptId, contentLength: content?.length });
            
            if (!receiptId || !content) {
                console.error('PrinterService: 参数错误, receiptId或content为空');
                return {
                    error: 'invalid_params',
                    error_description: '参数错误: 订单ID或打印内容为空'
                };
            }
            
            if (!this.pos.ylcloud_printer || !this.pos.ylcloud_printer.id) {
                console.error('PrinterService: 未配置易联云打印机');
                return {
                    error: 'printer_not_configured',
                    error_description: '未配置易联云打印机'
                };
            }

            const params = {
                partner: this.pos.ylcloud_printer.partner_id,
                machine_code: this.pos.ylcloud_printer.machine_code,
                receipt_id: receiptId,
                content: content,
            };
            
            return await this._makeYLCloudRequest('print', params);
        }

        /**
         * 显示打印结果通知
         * @private
         * @param {Object} result - 打印结果
         */
        _showPrintResultNotification(result) {
            if (result && (result.error === 0 || result.error === '0')) {
                Gui.showPopup('ConfirmPopup', {
                    title: '打印成功',
                    body: '订单已发送到易联云打印机',
                    confirmText: '确定',
                });
            } else {
                const errorMsg = result && result.error_description 
                    ? result.error_description : '未知错误';
                Gui.showPopup('ErrorPopup', {
                    title: '打印失败',
                    body: `打印请求失败: ${errorMsg}`,
                });
            }
        }

        /**
         * 添加到打印历史
         * @private
         * @param {Object} record - 历史记录
         */
        _addToPrintHistory(record) {
            this.printHistory.unshift({
                ...record,
                time: new Date().toLocaleString()
            });
            
            // 限制历史记录数量，只保留最近20条
            if (this.printHistory.length > 20) {
                this.printHistory = this.printHistory.slice(0, 20);
            }
        }

        /**
         * 发送请求到易联云API
         * @private
         * @param {String} apiName - API名称
         * @param {Object} params - 请求参数
         * @returns {Promise<Object>} 请求结果
         */
        async _makeYLCloudRequest(apiName, params) {
            try {
                console.log(`PrinterService: 调用易联云API [${apiName}]`, params);
                
                // 调用后端服务转发请求到易联云
                const result = await this.pos.rpc({
                    model: 'ylcloud.printer',
                    method: 'call_ylcloud_api',
                    args: [this.pos.ylcloud_printer.id, apiName, params],
                    kwargs: {},
                }, {
                    timeout: 20000, // 20秒超时
                    shadow: true,   // 静默错误，自行处理
                });
                
                console.log(`PrinterService: API [${apiName}] 返回结果:`, result);
                return result;
            } catch (error) {
                console.error(`PrinterService: API [${apiName}] 请求异常:`, error);
                // 转换为统一的错误格式
                return {
                    error: error.code || 'network_error',
                    error_description: error.message || '网络请求异常'
                };
            }
        }

        /**
         * 基本订单内容格式化 - 当订单对象不提供自己的格式化方法时使用
         * @private
         * @param {Object} order - 订单对象
         * @returns {string} 格式化后的打印内容
         */
        _formatBasicOrderContent(order) {
            try {
                // 获取基本订单数据
                const receipt = order.export_for_printing();
                let receiptString = '';
                
                // 添加公司名称和标题
                receiptString += '<FS2><center>' + (receipt.company.name || '订单') + '</center></FS2>\n';
                receiptString += '<FS><center>订单小票</center></FS>\n';
                receiptString += '<line>\n';
                
                // 添加订单基本信息
                receiptString += '订单号: ' + (receipt.name || '') + '\n';
                receiptString += '日期: ' + new Date().toLocaleString() + '\n';
                
                if (receipt.cashier) {
                    receiptString += '收银员: ' + receipt.cashier + '\n';
                }
                
                if (receipt.client) {
                    receiptString += '客户: ' + receipt.client.name + '\n';
                }
                
                receiptString += '<line>\n';
                
                // 添加商品列表
                receiptString += '<table>\n';
                receiptString += '<tr><td width="40%">商品</td><td width="20%">数量</td><td width="40%">金额</td></tr>\n';
                
                if (receipt.orderlines && receipt.orderlines.length) {
                    for (const line of receipt.orderlines) {
                        // 截断过长的商品名称
                        let productName = line.product_name || '未知商品';
                        if (productName.length > 12) {
                            productName = productName.substring(0, 10) + '..';
                        }
                        
                        const quantity = typeof line.quantity === 'number' 
                            ? line.quantity.toFixed(2) 
                            : (line.qty || 0).toFixed(2);
                        
                        const subtotal = typeof line.price_with_tax === 'number' 
                            ? line.price_with_tax.toFixed(2) 
                            : (line.price_with_tax_display || 0).toFixed(2);
                        
                        receiptString += '<tr>';
                        receiptString += '<td>' + productName + '</td>';
                        receiptString += '<td>' + quantity + '</td>';
                        receiptString += '<td>' + subtotal + '</td>';
                        receiptString += '</tr>\n';
                    }
                } else {
                    receiptString += '<tr><td colspan="3">无商品明细</td></tr>\n';
                }
                
                receiptString += '</table>\n';
                receiptString += '<line>\n';
                
                // 添加总计信息
                const total = receipt.total_with_tax 
                    ? (typeof receipt.total_with_tax === 'number' ? receipt.total_with_tax.toFixed(2) : receipt.total_with_tax)
                    : '0.00';
                
                // 使用FS2放大字体显示总计金额
                receiptString += '<FS2>总计: ' + total + '</FS2>\n';
                receiptString += '<line>\n';
                
                // 添加支付方式
                if (receipt.paymentlines && receipt.paymentlines.length) {
                    receiptString += '<FS>支付方式:</FS>\n';
                    for (const payment of receipt.paymentlines) {
                        const methodName = payment.name || '未知支付方式';
                        const amount = typeof payment.amount === 'number' 
                            ? payment.amount.toFixed(2) 
                            : (payment.amount || '0.00');
                        
                        receiptString += methodName + ': ' + amount + '\n';
                    }
                }
                
                // 添加找零
                if (receipt.change) {
                    const change = typeof receipt.change === 'number' 
                        ? receipt.change.toFixed(2) 
                        : receipt.change;
                    
                    receiptString += '<FS>找零: ' + change + '</FS>\n';
                }
                
                // 添加页脚
                receiptString += '<line>\n';
                receiptString += '<center>谢谢惠顾，欢迎再次光临!</center>\n';
                receiptString += '<center>' + new Date().toLocaleString() + '</center>\n';
                receiptString += '<center>订单号:' + (receipt.name || '') + '</center>\n';
                
                // 添加切纸指令
                receiptString += '<cut>\n';
                
                console.log('PrinterService: 基本格式化完成，内容前30个字符:', 
                            receiptString.substring(0, 30) + '...');
                return receiptString;
            } catch (error) {
                console.error('PrinterService: 格式化订单内容失败:', error);
                
                // 返回简单的错误信息作为打印内容
                return '<FS2><center>订单打印</center></FS2>\n' +
                       '<line>\n' +
                       '订单号: ' + (order.name || 'N/A') + '\n' +
                       '<center>格式化订单内容时出错</center>\n' +
                       '<center>' + error.message + '</center>\n' +
                       '<line>\n' +
                       '<center>请联系系统管理员</center>\n<cut>';
            }
        }

        /**
         * 获取打印历史记录
         * @returns {Array} 打印历史记录
         */
        getPrintHistory() {
            return this.printHistory;
        }

        /**
         * 测试打印特定内容 - 用于调试
         * @param {string} content - 打印内容
         * @returns {Promise<Object>} 打印结果
         */
        async debugPrint(content) {
            const testId = 'TEST_' + Date.now();
            const testContent = content || '<FS><center>打印测试</center></FS>\n' +
                '<line>\n' +
                '时间: ' + new Date().toLocaleString() + '\n' +
                '打印机: ' + (this.pos.ylcloud_printer?.name || '未知') + '\n' +
                '<line>\n' +
                '<center>易联云POS打印测试</center>\n<cut>\n';
                
            return await this._sendPrintRequest(testId, testContent);
        }
    }

    // 注册打印服务
    Registries.Services.add(PrinterService);

    // 扩展PaymentScreen，添加对打印服务的调用
    const PrinterPaymentScreenExt = (PaymentScreen) =>
        class extends PaymentScreen {
            async _finalizeValidation() {
                // 先调用父类方法完成验证
                await super._finalizeValidation(...arguments);
                
                try {
                    // 获取当前订单并保存引用
                    const order = this.env.pos.get_order();
                    if (!order) return;
                    
                    // 检查自动打印条件
                    const printerConfig = this.env.pos.ylcloud_printer;
                    if (!printerConfig || !printerConfig.auto_print || !printerConfig.print_order) {
                        console.log('PrinterPaymentScreenExt: 不满足自动打印条件，跳过打印');
                        return;
                    }
                    
                    console.log('PrinterPaymentScreenExt: 订单验证完成，将触发自动打印', order.name);
                    
                    // 设置订单状态为paid，会触发状态变更事件
                    if (typeof order.set_state === 'function') {
                        order.set_state('paid');
                    } else {
                        // 如果没有状态系统，直接使用打印服务
                        setTimeout(() => {
                            const printerService = this.env.services.printer;
                            if (printerService) {
                                printerService.printOrder(order);
                            }
                        }, 1000);
                    }
                } catch (error) {
                    console.error('PrinterPaymentScreenExt: 订单验证后触发打印失败:', error);
                }
            }
        };

    Registries.Component.extend(PaymentScreen, PrinterPaymentScreenExt);

    return {
        PrinterService,
        PrinterPaymentScreenExt
    };
}); 