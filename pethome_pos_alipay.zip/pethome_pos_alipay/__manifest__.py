
# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': '支付宝 POS 支付终端',
    'version': '18.0.1.0',
    'category': 'Sales/Point of Sale',
    'summary': '接受支付宝支付终端的付款',
    'description': """
接受支付宝支付终端的付款，直接在销售点POS系统中使用支付宝扫码支付。

该模块为 POS 添加了支付宝支付终端支持，让您能够直接在销售点接受支付宝扫码付款。
配置步骤：
1. 安装完成后在销售点支付方式中创建新的支付方式
2. 设置支付终端为"支付宝"
3. 选择对应的支付宝支付提供者
4. 开始使用支付宝扫码支付

注意：使用前请确保已经正确配置了支付宝支付提供者账户信息。
""",
    'depends': ['point_of_sale', 'payment', 'pethome_payment_alipay'],
    'data': [
        'security/ir.model.access.csv',
        'data/pos_alipay_data.xml',
        'views/pos_alipay_views.xml',
    ],
    'demo': [],
    'assets': {
        'point_of_sale.assets': [
            'pethome_pos_alipay/static/src/js/pos_alipay.js',
            'pethome_pos_alipay/static/src/css/pos_alipay.css',
        ],
    },
    'images': ['static/description/icon.png'],
    'author': 'PetHome Technology',
    'website': 'https://www.catlover.cn',
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
