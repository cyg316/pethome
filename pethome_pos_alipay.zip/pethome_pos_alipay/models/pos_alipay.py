# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging
import hashlib
import time
import urllib.parse
import json
import requests
import base64
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError, AccessError
from datetime import datetime
import rsa
from Crypto.Signature import PKCS1_v1_5
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA
import binascii

_logger = logging.getLogger(__name__)



class BarcodeRule(models.Model):
    _inherit = 'barcode.rule'

    type = fields.Selection(selection_add=[
        ('alipay', _('Alipay QR Code'))
    ], ondelete={'alipay': 'set default'})

    def _get_type_selection(self):
        types = super()._get_type_selection()
        types.append(('alipay', 'Alipay QR Code'))
        return types

class AccountBankStatementLine(models.Model):
    _inherit = "account.bank.statement.line"

    alipay_auth_code = fields.Char('Alipay Auth Code', readonly=True, groups='point_of_sale.group_pos_user',
                              help='Alipay payment authorization code')
    alipay_trade_no = fields.Char('Alipay Trade No', readonly=True, groups='point_of_sale.group_pos_user',
                             help='Alipay payment transaction number')
    alipay_buyer_id = fields.Char('Alipay Buyer ID', readonly=True, groups='point_of_sale.group_pos_user',
                             help='Alipay buyer ID')


class AccountJournal(models.Model):
    _inherit = 'account.journal'

    pos_alipay_config_id = fields.Many2one('payment.provider', 
        string='Alipay Payment Provider', 
        domain=[('code', '=', 'alipay')],
        help='The payment provider of Alipay used for this journal',
        groups='point_of_sale.group_pos_manager')


class PosOrder(models.Model):
    _inherit = "pos.order"

    alipay_auth_code = fields.Char('Alipay Auth Code', readonly=True, copy=False)
    alipay_trade_no = fields.Char('Alipay Trade No', readonly=True, copy=False)
    alipay_buyer_id = fields.Char('Alipay Buyer ID', readonly=True, copy=False)
    
    @api.model
    def _payment_fields(self, ui_paymentline):
        fields = super(PosOrder, self)._payment_fields(ui_paymentline)

        fields.update({
            'alipay_auth_code': ui_paymentline.get('alipay_auth_code'),
            'alipay_trade_no': ui_paymentline.get('alipay_trade_no'),
            'alipay_buyer_id': ui_paymentline.get('alipay_buyer_id'),
        })

        return fields

    def _process_payment_lines(self, order, pos_order, pos_session, draft):
        # 调用原始方法处理支付
        super(PosOrder, self)._process_payment_lines(order, pos_order, pos_session, draft)
        
        # 在支付行中添加支付宝交易信息
        payment_lines = order.get('statement_ids', False) or order.get('payment_ids', [])
        for payment_line in payment_lines:
            if payment_line[2].get('alipay_trade_no'):
                statement_id = payment_line[2]['statement_id'] if 'statement_id' in payment_line[2] else False
                line_id = payment_line[2]['statement_line_id'] if 'statement_line_id' in payment_line[2] else statement_id

                if line_id:
                    statement_line = self.env['account.bank.statement.line'].browse(line_id)
                    statement_line.write({
                        'alipay_auth_code': payment_line[2].get('alipay_auth_code'),
                        'alipay_trade_no': payment_line[2].get('alipay_trade_no'),
                        'alipay_buyer_id': payment_line[2].get('alipay_buyer_id')
                    })
        
        return order

    # 兼容pos_online_payment模块
    @api.model
    def get_and_set_online_payments_data(self, *args):
        """
        重写此方法以处理字符串格式的订单ID
        args[0]可能是订单ID或订单引用
        """
        if not args:
            return {}
            
        order_id = args[0]
        if isinstance(order_id, str):
            if 'pos.order' in order_id:
                order_id = order_id.split('_')[-1]
            if order_id.isdigit():
                order = self.env['pos.order'].browse(int(order_id))
                if order.exists():
                    return super(PosOrder, order).get_and_set_online_payments_data()
        
        # 如果没有特殊处理，创建一个空的记录集
        empty_recordset = self.env['pos.order'].browse([])
        return super(PosOrder, empty_recordset).get_and_set_online_payments_data()
    
    def _export_for_ui(self, order):
        result = super(PosOrder, self)._export_for_ui(order)
        result['alipay_trade_no'] = order.alipay_trade_no
        result['alipay_buyer_id'] = order.alipay_buyer_id
        result['alipay_auth_code'] = order.alipay_auth_code
        return result


class AutoVacuum(models.AbstractModel):
    _inherit = 'ir.autovacuum'

    @api.model
    def power_on(self, *args, **kwargs):
        # 移除不再存在的交易模型引用
        return super(AutoVacuum, self).power_on(*args, **kwargs)

class PosPaymentMethod(models.Model):
    _inherit = 'pos.payment.method'

    def _get_payment_terminal_selection(self):
        selection = super()._get_payment_terminal_selection()
        if not any(x[0] == 'alipay' for x in selection):
            selection += [('alipay', '支付宝')]
        return selection

    # Alipay configuration fields
    alipay_payment_provider_id = fields.Many2one('payment.provider', 
                                             string='支付宝支付提供者', 
                                             domain=[('code', '=', 'alipay')],
                                             help='用于此支付方式的支付宝支付提供者')

    @api.model
    def _load_pos_data_fields(self, config_id):
        params = super()._load_pos_data_fields(config_id)
        params += ['alipay_payment_provider_id']
        return params

    @api.model
    def _get_payment_terminal_selection_display(self):
        """获取支付终端选择显示"""
        selection = super()._get_payment_terminal_selection_display()
        if not any(x[0] == 'alipay' for x in selection):
            selection += [('alipay', '支付宝')]
        return selection

    @api.model
    def _get_payment_terminal_selection_domain(self):
        """获取支付终端选择域"""
        domain = super()._get_payment_terminal_selection_domain()
        if 'alipay' not in domain:
            domain += ['alipay']
        return domain

    def _get_alipay_provider_credentials(self, provider):
        """获取支付宝提供者凭证"""
        credentials = {
            'app_id': None,
            'private_key': None,
            'alipay_public_key': None,
            'sandbox': provider.state == 'test'
        }
        
        # 使用商用版本模块的字段
        is_test = provider.state == 'test'
        
        # App ID
        if is_test:
            credentials['app_id'] = provider.alipay_sandbox_appid
        else:
            credentials['app_id'] = provider.alipay_appid
        
        # 私钥
        if is_test:
            if provider.alipay_sandbox_secret:
                credentials['private_key'] = provider.alipay_sandbox_secret
        else:
            if provider.alipay_secret:
                credentials['private_key'] = provider.alipay_secret
        
        # 支付宝公钥
        if is_test:
            if provider.alipay_sandbox_public_key:
                credentials['alipay_public_key'] = provider.alipay_sandbox_public_key
        else:
            if provider.alipay_public_key:
                credentials['alipay_public_key'] = provider.alipay_public_key
        
        return credentials

    def _get_alipay_payment_provider(self):
        """获取支付宝支付提供者"""
        self.ensure_one()
        
        if self.alipay_payment_provider_id:
            return self.alipay_payment_provider_id
            
        # 如果未设置，尝试找到公司级别的配置
        alipay_provider = self.env['payment.provider'].search([
            ('code', '=', 'alipay'),
            ('state', 'in', ['enabled', 'test']),
            ('company_id', '=', self.company_id.id)
        ], limit=1)
        
        if not alipay_provider:
            raise UserError(_("No Alipay payment provider found for company %s", self.company_id.name))
            
        return alipay_provider

    def _get_alipay_api_url(self):
        """获取API URL"""
        provider = self._get_alipay_payment_provider()
        
        # 判断是否是测试模式
        is_test = provider.state == 'test'
        if is_test:
            return "https://openapi.alipaydev.com/gateway.do"
        return "https://openapi.alipay.com/gateway.do"

    def _generate_sign(self, params, private_key_string):
        """
        根据支付宝开发文档生成签名
        https://opendocs.alipay.com/open/01bxlm
        """
        sign_type = "RSA2"
        
        # 1. 参数排序
        sorted_params = sorted(params.items(), key=lambda x: x[0])
        
        # 2. 拼接参数
        data_to_sign = "&".join("{}={}".format(k, v) for k, v in sorted_params if v and k != "sign")
        
        # 3. 计算签名
        try:
            # 处理私钥格式
            if "BEGIN RSA PRIVATE KEY" not in private_key_string:
                # 转换为标准PEM格式
                private_key_string = "-----BEGIN RSA PRIVATE KEY-----\n" + \
                                    "\n".join([private_key_string[i:i+64] for i in range(0, len(private_key_string), 64)]) + \
                                    "\n-----END RSA PRIVATE KEY-----"
            
            # 使用RSA2签名算法
            private_key = RSA.importKey(private_key_string)
            signer = PKCS1_v1_5.new(private_key)
            digest = SHA256.new()
            digest.update(data_to_sign.encode('utf-8'))
            sign = signer.sign(digest)
            return base64.b64encode(sign).decode('utf-8')
        except Exception as e:
            _logger.error(f"Error generating Alipay signature: {str(e)}")
            raise UserError(_("Failed to generate Alipay signature: %s", str(e)))

    def _verify_alipay_signature(self, params, signature, alipay_public_key_string):
        """
        验证支付宝返回结果的签名
        """
        # 移除sign和sign_type参数
        params_to_verify = {k: v for k, v in params.items() if k not in ["sign", "sign_type"]}
        
        # 按字母顺序排序参数
        sorted_params = sorted(params_to_verify.items(), key=lambda x: x[0])
        
        # 构建待验签字符串
        data_to_verify = "&".join("{}={}".format(k, v) for k, v in sorted_params if v)
        
        try:
            # 处理公钥格式
            if "BEGIN PUBLIC KEY" not in alipay_public_key_string:
                alipay_public_key_string = "-----BEGIN PUBLIC KEY-----\n" + \
                                          "\n".join([alipay_public_key_string[i:i+64] for i in range(0, len(alipay_public_key_string), 64)]) + \
                                          "\n-----END PUBLIC KEY-----"
            
            # 验证签名
            pubkey = RSA.importKey(alipay_public_key_string)
            verifier = PKCS1_v1_5.new(pubkey)
            data_hash = SHA256.new(data_to_verify.encode('utf-8'))
            try:
                signature = base64.b64decode(signature)
                is_valid = verifier.verify(data_hash, signature)
                return is_valid
            except (TypeError, binascii.Error) as e:
                _logger.error(f"Invalid signature format: {str(e)}")
                return False
        except Exception as e:
            _logger.error(f"Error verifying Alipay signature: {str(e)}")
            return False

    def _prepare_alipay_request_data(self, method, biz_content):
        """准备支付宝请求数据"""
        provider = self._get_alipay_payment_provider()
        credentials = self._get_alipay_provider_credentials(provider)
        
        if not credentials['app_id'] or not credentials['private_key']:
            raise UserError(_("Missing Alipay credentials. Please configure the Alipay payment provider."))
        
        # 准备请求参数
        params = {
            'app_id': credentials['app_id'],
            'method': method,
            'format': 'JSON',
            'charset': 'utf-8',
            'sign_type': 'RSA2',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'version': '1.0',
            'biz_content': json.dumps(biz_content, ensure_ascii=False)
        }
        
        # 生成签名
        sign = self._generate_sign(params, credentials['private_key'])
        params['sign'] = sign
        
        return params

    def alipay_scan_pay(self, auth_code, total_amount, out_trade_no=None):
        """扫码支付处理"""
        self.ensure_one()
        
        if not self.env.user.has_group('point_of_sale.group_pos_user'):
            raise AccessError(_("Do not have access to process Alipay payments"))
            
        try:
            # 每个POS支付都需要一个唯一的交易号
            if not out_trade_no:
                out_trade_no = f"POS-{fields.Datetime.now().strftime('%Y%m%d%H%M%S')}-{self.id}"
                
            # 准备支付请求参数
            biz_content = {
                'out_trade_no': out_trade_no,
                'scene': 'bar_code',
                'auth_code': auth_code,
                'subject': 'POS Payment',
                'total_amount': str(round(float(total_amount), 2)),
                'timeout_express': '2m'  # 设置支付超时时间
            }
            
            # 准备请求数据
            request_data = self._prepare_alipay_request_data("alipay.trade.pay", biz_content)
            
            # 发送支付请求
            _logger.info(f"Sending Alipay payment request: {request_data}")
            response = requests.post(self._get_alipay_api_url(), data=request_data, timeout=10)
            response_data = response.json()
            
            # 处理支付结果
            response_key = "alipay_trade_pay_response"
            result = response_data.get(response_key, {})
            _logger.info(f"Alipay payment response: {result}")
            
            # 验证签名
            if 'sign' in response_data:
                provider = self._get_alipay_payment_provider()
                credentials = self._get_alipay_provider_credentials(provider)
                is_signature_valid = self._verify_alipay_signature(
                    {response_key: json.dumps(result, ensure_ascii=False)},
                    response_data['sign'], 
                    credentials['alipay_public_key']
                )
                if not is_signature_valid:
                    _logger.warning("Alipay response signature verification failed")
            
            if result.get("code") == "10000":
                return {
                    'status': 'success',
                    'message': 'Payment successful',
                    'trade_no': result.get('trade_no'),
                    'buyer_id': result.get('buyer_user_id'),
                    'out_trade_no': out_trade_no
                }
            else:
                error_msg = result.get('sub_msg') or result.get('msg', 'Unknown error')
                _logger.error(f"Alipay payment error: {error_msg}")
                return {
                    'status': 'error',
                    'message': error_msg,
                    'code': result.get('code')
                }
                
        except requests.exceptions.Timeout:
            _logger.error("Alipay payment timeout")
            return {'status': 'error', 'message': '连接支付宝服务器超时，请重试'}
        except requests.exceptions.ConnectionError:
            _logger.error("Alipay payment connection error")
            return {'status': 'error', 'message': '无法连接到支付宝服务器，请检查网络连接'}
        except Exception as e:
            _logger.error(f"Error in Alipay payment: {str(e)}")
            return {'status': 'error', 'message': str(e)}

    def alipay_validate_payment(self, trade_no, amount, out_trade_no=None):
        """验证支付结果"""
        self.ensure_one()
        
        if not self.env.user.has_group('point_of_sale.group_pos_user'):
            raise AccessError(_("Do not have access to validate Alipay payments"))
            
        try:
            # 准备查询请求参数
            biz_content = {
                'trade_no': trade_no
            }
            
            if out_trade_no:
                biz_content['out_trade_no'] = out_trade_no
            
            # 准备请求数据
            request_data = self._prepare_alipay_request_data("alipay.trade.query", biz_content)
            
            # 发送查询请求
            response = requests.post(self._get_alipay_api_url(), data=request_data, timeout=10)
            response_data = response.json()
            
            # 处理查询结果
            response_key = "alipay_trade_query_response"
            result = response_data.get(response_key, {})
            _logger.info(f"Alipay payment validation response: {result}")
            
            # 验证签名
            if 'sign' in response_data:
                provider = self._get_alipay_payment_provider()
                credentials = self._get_alipay_provider_credentials(provider)
                is_signature_valid = self._verify_alipay_signature(
                    {response_key: json.dumps(result, ensure_ascii=False)},
                    response_data['sign'], 
                    credentials['alipay_public_key']
                )
                if not is_signature_valid:
                    _logger.warning("Alipay validation response signature verification failed")
            
            if result.get("code") == "10000":
                # 检查交易状态和金额
                if result.get('trade_status') in ['TRADE_SUCCESS', 'TRADE_FINISHED'] and \
                   abs(float(result.get('total_amount', 0)) - float(amount)) < 0.01:
                    return {
                        'status': 'success',
                        'message': 'Payment validated successfully'
                    }
                else:
                    error_msg = f"交易状态异常: {result.get('trade_status')}"
                    _logger.error(error_msg)
                    return {
                        'status': 'error',
                        'message': error_msg
                    }
            else:
                error_msg = result.get('sub_msg') or result.get('msg', 'Unknown error')
                _logger.error(f"Alipay validation error: {error_msg}")
                return {
                    'status': 'error',
                    'message': error_msg,
                    'code': result.get('code')
                }
                
        except requests.exceptions.Timeout:
            _logger.error("Alipay validation timeout")
            return {'status': 'error', 'message': '验证支付结果超时，请重试'}
        except requests.exceptions.ConnectionError:
            _logger.error("Alipay validation connection error")
            return {'status': 'error', 'message': '无法连接到支付宝服务器，请检查网络连接'}
        except Exception as e:
            _logger.error(f"Error in Alipay validation: {str(e)}")
            return {'status': 'error', 'message': str(e)}

    def action_alipay_provider(self):
        """跳转到支付宝支付提供者配置"""
        try:
            provider = self._get_alipay_payment_provider()
            return {
                'name': _('Alipay Provider'),
                'res_model': 'payment.provider',
                'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_id': provider.id,
            }
        except UserError as e:
            # 如果没有找到提供者，则创建新的
            return {
                'name': _('Alipay Provider'),
                'res_model': 'payment.provider',
                'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'context': {'default_code': 'alipay', 'default_company_id': self.company_id.id},
            }
            
    # 添加这个方法来检测功能模块的可用性
    @api.model
    def is_write_date_enabled(self):
        # 这个方法在支付方法表单视图中调用，如果模块安装了，会返回True
        return True
