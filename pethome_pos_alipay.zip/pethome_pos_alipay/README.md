# Alipay POS Payment Module for Odoo 18

Este módulo integra pagos de Alipay en el punto de venta (POS) de Odoo 18, permitiendo a los comerciantes aceptar pagos mediante el escaneo de códigos QR de Alipay.

## Características

- Escanear códigos QR de pago de Alipay directamente desde el POS
- Integración completa con la interfaz de POS de Odoo 18
- Soporte para entornos de prueba (sandbox) y producción
- Gestión de pagos, consultas y reembolsos
- Almacenamiento seguro de información de transacciones

## Requisitos

- Odoo 18
- Cuenta de desarrollador de Alipay con credenciales válidas
- Módulos Python: pycryptodome, pyasn1, rsa

## Instalación

1. Instalar el módulo en Odoo
2. Instalar las dependencias Python:
   ```
   pip install -r requirements.txt
   ```
3. Configurar una cuenta de Alipay en Punto de Venta > Configuración > Configuraciones de Alipay
4. Asociar la configuración de Alipay a un método de pago en los ajustes del diario

## Uso

1. Abrir una sesión de POS
2. Al realizar un pago, seleccionar el método de pago configurado con Alipay
3. Escanear el código QR de pago del cliente con un escáner de códigos de barras
4. El pago se procesará automáticamente y se mostrará el resultado

## Soporte

Para soporte técnico, contactar a [su_correo@ejemplo.com]