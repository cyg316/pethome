odoo.define('pethome_pos_alipay.payment', function (require) {
'use strict';

const { Component, xml } = owl;
const { Gui } = require('@point_of_sale/app/utils/gui');
const Registries = require('@point_of_sale/app/core/registries');
const { rpc } = require("@web/core/network/rpc");
const core = require("@web/core/core");
const _t = core._t;
const { _lt } = require('@web/core/l10n/translation');
const { Payment } = require('@point_of_sale/app/payment/payment_screen/payment/payment');
// Revert TextInputPopup import to the POS app path
const { TextInputPopup } = require('@point_of_sale/app/utils/input_popups/text_input_popup');

console.log("Loading pethome_pos_alipay.payment module (v7.0 - Odoo 18 Enhanced B2C Implementation)...");

// Extend Payment Method Model
const AlipayPaymentMethod = (PaymentMethod) => class extends PaymentMethod {
    setup() {
        super.setup(...arguments);
        if (this.use_payment_terminal === 'alipay') {
            console.log(`Alipay PM (${this.name}): 开始设置payment_terminal`);
            
            // 创建完整的payment_terminal对象，确保包含所有Odoo 18中可能调用的方法
            this.payment_terminal = {
                // 核心方法：发送支付请求
                send_payment_request: this._alipay_send_payment_request.bind(this),
                
                // 其他必要的方法，即使返回假值也必须提供
                send_payment_cancel: async () => { 
                    console.log('Alipay PM: Cancel not supported');
                    return true; 
                },
                send_payment_reversal: async () => { 
                    console.log('Alipay PM: Reversal not supported');
                    return false; 
                },
                
                // 标准属性
                supports_reversals: false,
                
                // 为Odoo 18的标准接口添加pay方法，确保兼容性
                pay: async (payment_line) => {
                    console.log(`Alipay PM (${this.name}): payment_terminal.pay方法被调用`, payment_line?.uuid);
                    if (!payment_line || !payment_line.uuid) {
                        console.error('Alipay PM: payment_terminal.pay方法收到无效的payment_line');
                        return false;
                    }
                    // 重定向到send_payment_request方法
                    return await this.payment_terminal.send_payment_request(payment_line.uuid);
                }
            };
            
            console.log(`Alipay PM (${this.name}): payment_terminal设置完成`);
        }
    }

    // Implementation of send_payment_request for Alipay terminal
    // In Odoo 18, this takes a UUID parameter, not the payment line
    async _alipay_send_payment_request(uuid) {
        console.log(`Alipay PM (${this.name}): send_payment_request被调用，UUID: ${uuid}`);
        
        // 1. 验证参数
        if (!uuid || typeof uuid !== 'string') {
            console.error(`Alipay Error: 无效的UUID参数`, uuid);
            return false;
        }
        
        // 2. 获取当前订单
        const order = this.pos.get_order();
        if (!order) {
            console.error(`Alipay Error: 未找到当前订单，无法处理支付`);
            Gui.showPopup('ErrorPopup', { 
                title: _t('系统错误'), 
                body: _t('无法获取当前订单信息，请刷新页面后重试。')
            });
            return false;
        }
        
        // 3. 根据UUID找到支付行
        let payment_line;
        try {
            payment_line = order.payment_ids.find(line => line.uuid === uuid);
        } catch (error) {
            console.error(`Alipay Error: 查找支付行时出错`, error);
            return false;
        }
        
        if (!payment_line) {
            console.error(`Alipay Error: 未找到UUID为 ${uuid} 的支付行`);
            return false;
        }
        
        console.log(`Alipay PM (${this.name}): 找到支付行，UUID: ${uuid}，金额: ${payment_line.amount}`);
        
        // 4. 验证支付行的授权码
        if (!payment_line.alipay_auth_code) {
            console.warn(`Alipay PM (${this.name}): 支付行缺少授权码，UUID: ${uuid}`);
            Gui.showPopup('ErrorPopup', { 
                title: _t('支付错误'), 
                body: _t('缺少支付宝付款码，请重新操作或扫描。')
            });
            return false;
        }
        
        // 5. 准备RPC调用参数
        console.log(`Alipay PM (${this.name}): 准备发送支付请求，授权码已找到`);
        
        // 获取必要参数
        const amount = payment_line.amount;
        const payment_method_id = this.id;
        const auth_code = payment_line.alipay_auth_code;
        
        if (!amount || amount <= 0) {
            console.error(`Alipay PM (${this.name}): 支付金额无效: ${amount}`);
            Gui.showPopup('ErrorPopup', { 
                title: _t('支付错误'), 
                body: _t('支付金额必须大于零')
            });
            return false;
        }
        
        // 6. 执行RPC调用
        try {
            console.log(`Alipay PM (${this.name}): 调用支付宝支付接口 - 方法ID: ${payment_method_id}, 授权码: ${auth_code}, 金额: ${amount}, 订单ID: ${order.uid}`);
            
            const result = await rpc.query({
                model: 'pos.payment.method',
                method: 'alipay_scan_pay',
                args: [payment_method_id, auth_code, amount, order.uid]
            });
            
            // 7. 处理RPC响应
            console.log(`Alipay PM (${this.name}): 收到RPC响应:`, result);
            
            if (result.status === 'success') {
                console.log(`Alipay PM (${this.name}): 支付成功 - 交易号: ${result.trade_no}`);
                
                // 记录支付宝交易信息
                payment_line.alipay_trade_no = result.trade_no;
                payment_line.alipay_buyer_id = result.buyer_id;
                
                // 支付宝支付成功，展示成功信息
                Gui.showPopup('ConfirmPopup', {
                    title: _t('支付成功'),
                    body: _t('支付宝支付已成功处理'),
                    confirmText: _t('确定')
                });
                
                return true;
            } else {
                console.error(`Alipay PM (${this.name}): 支付失败 - 原因:`, result.message || '未知错误');
                
                // 显示错误信息
                Gui.showPopup('ErrorPopup', { 
                    title: _t('支付失败'), 
                    body: result.message || _t('支付宝返回支付失败，请重试。')
                });
                
                return false;
            }
        } catch (error) {
            console.error(`Alipay PM (${this.name}): RPC调用异常:`, error);
            
            // 格式化错误信息
            let errorMessage = _t('与支付宝通信时出错');
            
            if (error instanceof Error) {
                errorMessage = error.message;
            } else if (error.data && error.data.message) {
                errorMessage = error.data.message;
            }
            
            // 显示错误信息
            Gui.showPopup('ErrorPopup', { 
                title: _t('支付错误'), 
                body: errorMessage
            });
            
            return false;
        }
    }
};
Registries.Model.extend('pos.payment.method', AlipayPaymentMethod);


// Extend Payment Line Model
const AlipayPaymentLine = (PaymentLine) => class extends PaymentLine {
    setup() {
        super.setup(...arguments);
        this.alipay_auth_code = this.alipay_auth_code || null;
        this.alipay_trade_no = this.alipay_trade_no || null;
        this.alipay_buyer_id = this.alipay_buyer_id || null;
        
        // 更高级的、持久的payment_method_id同步方法
        this._syncPaymentMethodId();
        
        console.log(`Alipay PL (${this.cid}): setup完成，payment_method_id已设置为:`, 
            this.payment_method_id ? this.payment_method_id.name : 'UNDEFINED');
    }
    
    // 新方法：确保payment_method_id总是正确引用payment_method
    _syncPaymentMethodId() {
        try {
            if (!this.payment_method_id && this.payment_method) {
                console.log(`Alipay PL (${this.cid}): 正在同步payment_method_id...`);
                // 使用defineProperty创建一个受保护的属性链接
                Object.defineProperty(this, 'payment_method_id', {
                    get: function() {
                        // 总是返回最新的payment_method引用
                        return this.payment_method;
                    },
                    configurable: true,
                    enumerable: true
                });
            }
        } catch (error) {
            console.error(`Alipay PL (${this.cid}): 同步payment_method_id时出错:`, error);
            // 回退到简单赋值
            this.payment_method_id = this.payment_method;
        }
    }

    init_from_JSON(json) {
        super.init_from_JSON(json);
        this.alipay_auth_code = json.alipay_auth_code;
        this.alipay_trade_no = json.alipay_trade_no;
        this.alipay_buyer_id = json.alipay_buyer_id;
        
        // 确保在初始化后同步payment_method_id
        this._syncPaymentMethodId();
        
        // 重要的检查：payment_method上是否有payment_terminal
        if (this.payment_method && this.payment_method.use_payment_terminal === 'alipay') {
            console.log(`Alipay PL (${this.cid}): 支付方法检查 - payment_terminal存在: ${!!this.payment_method.payment_terminal}`);
            console.log(`Alipay PL (${this.cid}): 支付方法检查 - send_payment_request存在: ${!!this.payment_method.payment_terminal?.send_payment_request}`);
        }
    }

    // 重写支付方法以添加更多保护性检查
    async pay() {
        console.log(`Alipay PL (${this.cid}): pay()方法被调用 - 开始支付流程`);
        
        // 支付前再次同步payment_method_id
        this._syncPaymentMethodId();
        
        if (!this.payment_method_id) {
            console.error(`Alipay PL (${this.cid}): 严重错误 - payment_method_id仍未定义`);
            this.set_payment_status("retry");
            Gui.showPopup('ErrorPopup', { 
                title: _t('支付错误'), 
                body: _t('支付方法配置错误，请重新添加支付行或联系系统管理员。')
            });
            return false;
        }
        
        if (!this.payment_method_id.payment_terminal) {
            console.error(`Alipay PL (${this.cid}): 严重错误 - payment_terminal未定义`);
            this.set_payment_status("retry");
            Gui.showPopup('ErrorPopup', { 
                title: _t('支付错误'), 
                body: _t('支付终端未配置。请检查支付方法设置。')
            });
            return false;
        }
        
        if (typeof this.payment_method_id.payment_terminal.send_payment_request !== 'function') {
            console.error(`Alipay PL (${this.cid}): 严重错误 - send_payment_request不是函数`);
            this.set_payment_status("retry");
            Gui.showPopup('ErrorPopup', { 
                title: _t('支付错误'), 
                body: _t('支付接口方法未定义。请联系系统管理员。')
            });
            return false;
        }
        
        // 验证授权码是否已设置
        if (!this.alipay_auth_code) {
            console.warn(`Alipay PL (${this.cid}): 支付前检查 - 缺少授权码`);
            this.set_payment_status("retry");
            Gui.showPopup('ErrorPopup', { 
                title: _t('支付错误'), 
                body: _t('缺少支付宝付款码，请重新扫描或输入。')
            });
            return false;
        }
        
        console.log(`Alipay PL (${this.cid}): 支付前检查通过，开始处理支付`);
        
        try {
            this.set_payment_status("waiting");
            console.log(`Alipay PL (${this.cid}): 调用支付终端send_payment_request，UUID: ${this.uuid}`);
            
            // 先将状态设置为处理中
            Gui.showPopup('LoadingPopup', { 
                title: _t('处理支付中'), 
                body: _t('正在处理支付宝付款，请稍候...')
            });
            
            const response = await this.payment_method_id.payment_terminal.send_payment_request(this.uuid);
            console.log(`Alipay PL (${this.cid}): 支付响应:`, response);
            
            Gui.closePopup();
            return this.handle_payment_response(response);
        } catch (error) {
            Gui.closePopup();
            console.error(`Alipay PL (${this.cid}): pay()方法处理过程中出错:`, error);
            this.set_payment_status("retry");
            Gui.showPopup('ErrorPopup', {
                title: _t('支付处理错误'),
                body: _t('支付处理过程中发生错误:') + "\n" + (error.message || _t('未知错误'))
            });
            return false;
        }
    }

    export_as_JSON() {
        const json = super.export_as_JSON();
        json.alipay_auth_code = this.alipay_auth_code;
        json.alipay_trade_no = this.alipay_trade_no;
        json.alipay_buyer_id = this.alipay_buyer_id;
        return json;
    }

    get is_alipay() {
        return this.payment_method?.use_payment_terminal === 'alipay';
    }
};
// 修改注册到正确的模型名称
Registries.Model.extend('pos.payment', AlipayPaymentLine);


// Extend Order Model
const AlipayOrder = (Order) => class extends Order {
    get_paymentline_by_pending_alipay() {
        return this.get_paymentlines().find(line =>
            line.is_alipay &&
            line.get_payment_status() !== 'done'
        );
    }

    assign_alipay_code(code) {
        const paymentline = this.get_paymentline_by_pending_alipay();
        if (paymentline) {
            paymentline.alipay_auth_code = code;
            console.log(`Order: Assigned code to pending line ${paymentline.cid}`);
            paymentline.trigger('change', paymentline);
            return paymentline;
        }
        return null;
    }
};
Registries.Model.extend('pos.order', AlipayOrder);


// Extend POS Model
const AlipayPosModel = (PosModel) => class extends PosModel {
    setup() {
        super.setup(...arguments);
        this._registerAlipayBarcodeScanner();
        console.log("AlipayPosModel setup complete.");
    }

    _registerAlipayBarcodeScanner() {
        const barcodeReader = this.barcode_reader;
        if (barcodeReader) {
            console.log("AlipayPosModel: 注册支付宝条码扫描处理程序");
            
            // 支付宝付款码规则：25-30开头的数字串
            const barcodeRule = { 
                'type': 'alipay', 
                'sequence': 85, 
                'pattern': /^(25|26|27|28|29|30)\d{10,30}$/  // 更精确的支付宝付款码格式
            };
            
            // 添加到条码规则中（如果不存在）
            if (this.barcode_rules && Array.isArray(this.barcode_rules)) {
                const existingRule = this.barcode_rules.some(rule => rule.type === 'alipay');
                if (!existingRule && typeof barcodeReader.add_barcode_rules === 'function') {
                    barcodeReader.add_barcode_rules(barcodeRule);
                    console.log("AlipayPosModel: 支付宝条码规则已添加");
                }
            }
            
            // 注册处理函数
            if (typeof barcodeReader.add_barcode_action === 'function') {
                barcodeReader.add_barcode_action({ 'alipay': this._handle_alipay_barcode.bind(this) });
                console.log("AlipayPosModel: 支付宝条码处理函数已注册");
            }
        } else {
            console.warn("AlipayPosModel: 警告 - 条码读取器不可用，无法注册支付宝条码处理");
        }
    }

    async _handle_alipay_barcode(code) {
        // 验证条码格式
        if (!code || !/^(25|26|27|28|29|30)\d{10,30}$/.test(code)) {
            console.warn(`Barcode Handler: 无效的支付宝条码格式: ${code}`);
            Gui.showPopup('ErrorPopup', { 
                title: _t('无效条码'), 
                body: _t('扫描的条码不符合支付宝付款码格式。')
            });
            return;
        }
    
        console.log(`Barcode Handler: 扫描到支付宝付款码 ${code}`);
        
        // 1. 检查当前订单
        const order = this.get_order();
        if (!order) {
            Gui.showPopup('WarningPopup', { 
                title: _t('扫码提示'), 
                body: _t('请先创建订单。')
            });
            return;
        }

        // 2. 检查当前界面
        const currentScreen = this.chrome.mainScreen.component;
        if (!(currentScreen && currentScreen.name === 'PaymentScreen')) {
            Gui.showPopup('WarningPopup', { 
                title: _t('扫码提示'), 
                body: _t('请在付款界面扫描。')
            });
            return;
        }

        console.log("Barcode Handler: 正在处理支付宝付款码");

        // 3. 尝试更新现有支付行
        const existingPendingLine = order.assign_alipay_code(code);
        if (existingPendingLine) {
            console.log(`Barcode Handler: 已将付款码分配给现有支付行 (UUID: ${existingPendingLine.uuid})`);
            // 选中该支付行
            currentScreen.selectPaymentLine(existingPendingLine.uuid);
            
            // 使用标准的sendPaymentRequest方法处理支付
            try {
                console.log(`Barcode Handler: 正在调用sendPaymentRequest处理已有支付行`);
                await currentScreen.sendPaymentRequest(existingPendingLine);
            } catch (error) {
                console.error(`Barcode Handler: 处理支付时出错`, error);
                Gui.showPopup('ErrorPopup', {
                    title: _t('支付处理错误'),
                    body: error.message || _t('处理支付时出现异常，请重试。')
                });
            }
            return;
        }

        // 4. 创建新的支付行
        console.log("Barcode Handler: 未找到待处理的支付行，将创建新支付行");
        
        // 获取所有支付宝支付方式
        const alipayMethods = this.payment_methods.filter(m => m.use_payment_terminal === 'alipay');

        // 4.1 单一支付宝方式的情况
        if (alipayMethods.length === 1) {
            const paymentMethod = alipayMethods[0];
            console.log(`Barcode Handler: 使用【${paymentMethod.name}】自动创建支付行`);
            
            try {
                // 创建支付行并设置金额和授权码
                const newLine = order.add_paymentline(paymentMethod);
                newLine.set_amount(order.get_due());
                newLine.alipay_auth_code = code;
                
                console.log(`Barcode Handler: 已创建支付行 (UUID: ${newLine.uuid})，并分配付款码`);

                // 更新界面并选中支付行
                await currentScreen.render(true);
                currentScreen.selectPaymentLine(newLine.uuid);
                await currentScreen.render(true);
                
                // 如果此支付行付清全部金额，显示确认信息
                if (Math.abs(order.get_due()) < 0.000001) {
                    console.log('Barcode Handler: 此支付已付清全部金额');
                }
                
                // 使用标准的sendPaymentRequest方法处理支付
                try {
                    console.log(`Barcode Handler: 正在调用sendPaymentRequest处理新支付行`);
                    await currentScreen.sendPaymentRequest(newLine);
                } catch (error) {
                    console.error(`Barcode Handler: 处理支付时出错`, error);
                    Gui.showPopup('ErrorPopup', {
                        title: _t('支付处理错误'),
                        body: error.message || _t('处理支付时出现异常，请重试。')
                    });
                }
            } catch (error) {
                console.error("Barcode Handler: 创建支付行失败", error);
                Gui.showPopup('ErrorPopup', { 
                    title: _t('创建支付失败'), 
                    body: _t('无法创建支付行，请手动选择支付方式。')
                });
            }
        } 
        // 4.2 多个支付宝方式的情况
        else if (alipayMethods.length > 1) {
            console.log(`Barcode Handler: 检测到${alipayMethods.length}个支付宝支付方式`);
            
            // 提示用户选择一种支付方式
            Gui.showPopup('ErrorPopup', { 
                title: _t('请选择支付方式'), 
                body: _t('检测到多个支付宝方式，请先点击所需方式再扫码。')
            });
        } 
        // 4.3 没有支付宝方式的情况
        else {
            console.error('Barcode Handler: 未找到支付宝支付方式');
            
            Gui.showPopup('ErrorPopup', { 
                title: _t('配置错误'), 
                body: _t('系统中未配置支付宝支付方式，请联系管理员。')
            });
        }
    }
};
Registries.Model.extend('pos.pos', AlipayPosModel);


// Extend PaymentScreen
const AlipayPaymentScreen = (PaymentScreen) => class extends PaymentScreen {
    async addNewPaymentLine({ detail: paymentMethod }) {
        if (paymentMethod.use_payment_terminal === 'alipay') {
            console.log(`PaymentScreen: 点击支付宝支付方式 ${paymentMethod.name}`);
            const order = this.currentOrder;
            if (!order) return;

            const paymentline = order.add_paymentline(paymentMethod);
            paymentline.set_amount(order.get_due());
            console.log(`PaymentScreen: 已添加支付宝支付行，UUID: ${paymentline.uuid}, cid: ${paymentline.cid}`);

            this.selectPaymentLine(paymentline.uuid);
            await this.render(true);

            const { confirmed, payload: code } = await this.popup.add(TextInputPopup, {
                title: _t('支付宝支付'),
                body: _t('请扫描或输入顾客付款码'),
                confirmText: _t('确认支付'),
                cancelText: _t('取消'),
                startingValue: '',
            });

            if (confirmed && code && code.trim()) {
                console.log(`PaymentScreen: 收到授权码 ${code}，分配给支付行 UUID: ${paymentline.uuid}`);
                paymentline.alipay_auth_code = code.trim();
                
                // 在请求支付前进行关键检查
                console.log(`PaymentScreen: 支付前检查 - payment_method_id存在: ${!!paymentline.payment_method_id}`);
                console.log(`PaymentScreen: 支付前检查 - payment_terminal存在: ${!!paymentline.payment_method_id?.payment_terminal}`);
                console.log(`PaymentScreen: 支付前检查 - send_payment_request存在: ${!!paymentline.payment_method_id?.payment_terminal?.send_payment_request}`);
                
                // 在Odoo 18中，应该调用 sendPaymentRequest 而不是 _sendPaymentRequest
                console.log(`PaymentScreen: 调用sendPaymentRequest处理支付行 ${paymentline.uuid}`);
                try {
                    await this.sendPaymentRequest(paymentline);
                } catch (error) {
                    console.error(`PaymentScreen: 调用sendPaymentRequest出错`, error);
                    Gui.showPopup('ErrorPopup', {
                        title: _t('支付处理错误'),
                        body: error.message || _t('处理支付时发生错误，请重试。')
                    });
                }
            } else {
                console.log(`PaymentScreen: 用户取消输入授权码，移除支付行 ${paymentline.uuid}`);
                order.remove_paymentline(paymentline);
                await this.render(true);
            }
        } else {
            return super.addNewPaymentLine({ detail: paymentMethod });
        }
    }
};
Registries.Component.extend('PaymentScreen', AlipayPaymentScreen);

console.log("pethome_pos_alipay.payment module loaded successfully (v7.0 - Odoo 18 B2C Mode Complete).");

return {};

}); 