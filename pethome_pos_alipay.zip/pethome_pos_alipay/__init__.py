# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

# from . import controllers
from . import models 

def post_init_hook(cr, registry):
    """安装后注册支付宝作为POS支付终端选项"""
    from odoo import api, SUPERUSER_ID
    env = api.Environment(cr, SUPERUSER_ID, {})
    
    # 调用更新方法
    env['pethome_pos_alipay.configuration'].update_pos_alipay_config() 