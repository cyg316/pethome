#!/bin/bash

# 设置颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=========================${NC}"
echo -e "${GREEN}PetHome WeChat Pay 依赖安装${NC}"
echo -e "${GREEN}=========================${NC}"

# 确认安装
echo -e "${YELLOW}此脚本将安装WeChat Pay模块所需的依赖库。${NC}"
read -p "是否继续? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]
then
    echo -e "${RED}安装已取消${NC}"
    exit 1
fi

# 查找Odoo的Python环境
ODOO_PY=$(which odoo || which odoo-bin || which python3)

if [ -z "$ODOO_PY" ]; then
    echo -e "${RED}无法找到Odoo或Python环境。${NC}"
    echo -e "${YELLOW}请手动安装以下依赖:${NC}"
    cat requirements.txt
    exit 1
fi

# 如果找到的是odoo或odoo-bin，获取其Python路径
if [[ $ODOO_PY == *"odoo"* ]]; then
    PYTHON_PATH=$(head -n 1 $ODOO_PY | sed 's/#\!//g')
    if [ -z "$PYTHON_PATH" ]; then
        PYTHON_PATH="python3"
    fi
else
    PYTHON_PATH=$ODOO_PY
fi

echo -e "${GREEN}使用Python: $PYTHON_PATH${NC}"

# 安装依赖
echo -e "${GREEN}开始安装依赖...${NC}"
$PYTHON_PATH -m pip install -r requirements.txt

# 检查安装结果
if [ $? -eq 0 ]; then
    echo -e "${GREEN}依赖安装成功！${NC}"
    echo -e "${GREEN}安装的依赖:${NC}"
    $PYTHON_PATH -m pip freeze | grep -E "pycryptodome|requests|cryptography|qrcode|Pillow"
else
    echo -e "${RED}依赖安装失败。${NC}"
    echo -e "${YELLOW}请尝试手动安装以下依赖:${NC}"
    cat requirements.txt
    exit 1
fi

echo -e "${GREEN}=========================${NC}"
echo -e "${GREEN}安装完成!${NC}"
echo -e "${GREEN}=========================${NC}"

# 显示使用提示
echo -e "${YELLOW}提示: 微信支付模块需要配置证书和密钥才能正常工作。${NC}"
echo -e "${YELLOW}请在Odoo界面中完成相关配置。${NC}"

exit 0 