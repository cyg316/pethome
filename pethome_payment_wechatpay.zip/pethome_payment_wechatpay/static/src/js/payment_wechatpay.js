odoo.define('pethome_payment_wechatpay.payment_form', function (require) {
    'use strict';

    const core = require('web.core');
    const publicWidget = require('web.public.widget');
    const ajax = require('web.ajax');
    const checkoutForm = require('payment.checkout_form');
    const manageForm = require('payment.manage_form');
    const _t = core._t;

    // 扩展通用支付表单，添加微信支付处理
    const PaymentForm = checkoutForm.include({
        /**
         * 处理提交表单后，根据不同支付提供商重定向
         * 
         * @override
         * @private
         * @param {Object} providerData - 提供商返回的数据
         * @param {string} providerCode - 提供商代码
         */
        _processRedirectFlow: function (providerData, providerCode) {
            if (providerCode === 'wechatpay') {
                // 处理微信支付特殊情况 - 打开二维码页面
                const redirectUrl = providerData.redirect_url;
                if (redirectUrl) {
                    window.location = redirectUrl;
                } else {
                    this._displayErrorDialog(_t("未能获取到有效的微信支付二维码页面"));
                }
            } else {
                // 调用原始实现处理其他提供商
                this._super.apply(this, arguments);
            }
        },
    });

    // 确保管理表单也兼容
    manageForm.include({
        _processRedirectFlow: PaymentForm.prototype._processRedirectFlow,
    });

    publicWidget.registry.WeChatPayForm = publicWidget.Widget.extend({
        selector: '.wechatpay-container',
        events: {
            'click .wechatpay-refresh-btn': '_onRefreshQRCode',
            'click .wechatpay-cancel-btn': '_onCancelPayment',
            'click .wechatpay-simulate-btn': '_onSimulatePayment'
        },

        /**
         * @override
         */
        start: function () {
            const result = this._super.apply(this, arguments);
            this.txReference = this.$el.data('reference');
            this.txId = this.$el.data('tx-id');
            
            // 开始倒计时
            this._startCountdown();
            
            // 开始轮询支付状态
            this._startStatusPolling();
            
            return result;
        },
        
        /**
         * 销毁时清理定时器
         * 
         * @override
         */
        destroy: function () {
            this._super.apply(this, arguments);
            if (this.countdownInterval) {
                clearInterval(this.countdownInterval);
            }
            if (this.statusInterval) {
                clearInterval(this.statusInterval);
            }
        },

        /**
         * 开始倒计时
         * 
         * @private
         */
        _startCountdown: function () {
            const $countdown = this.$('.wechatpay-countdown');
            if (!$countdown.length) return;
            
            // 设置5分钟倒计时
            let totalSeconds = 5 * 60;
            
            this.countdownInterval = setInterval(() => {
                if (totalSeconds <= 0) {
                    clearInterval(this.countdownInterval);
                    // 显示二维码过期信息
                    this._showQRCodeExpired();
                    return;
                }
                
                const minutes = Math.floor(totalSeconds / 60);
                const seconds = totalSeconds % 60;
                $countdown.text(`${minutes}:${seconds < 10 ? '0' : ''}${seconds}`);
                totalSeconds--;
            }, 1000);
        },
        
        /**
         * 显示二维码过期信息
         * 
         * @private
         */
        _showQRCodeExpired: function () {
            // 隐藏处理中状态
            this.$('.wechatpay-processing').hide();
            
            // 显示错误状态
            this.$('.wechatpay-error')
                .text(_t('二维码已过期，请点击刷新按钮获取新的二维码'))
                .show();
                
            // 添加过期样式到二维码
            this.$('.wechatpay-qrcode-display').addClass('expired');
        },

        /**
         * 开始轮询支付状态
         * 
         * @private
         */
        _startStatusPolling: function () {
            if (!this.txReference) return;
            
            // 每3秒检查一次支付状态
            this.statusInterval = setInterval(() => {
                this._checkPaymentStatus();
            }, 3000);
        },

        /**
         * 检查支付状态
         * 
         * @private
         */
        _checkPaymentStatus: function () {
            ajax.jsonRpc('/payment/wechatpay/check_status', 'call', {
                reference: this.txReference
            })
            .then(result => {
                if (result.state === 'done') {
                    // 支付成功，停止轮询
                    clearInterval(this.statusInterval);
                    clearInterval(this.countdownInterval);
                    
                    // 更新UI显示支付成功
                    this._updateStatusUI('success', _t('支付成功！正在处理您的订单...'));
                    
                    // 延迟后重定向到成功页面
                    setTimeout(() => {
                        window.location.href = result.redirect_url || '/payment/status';
                    }, 2000);
                }
                else if (result.state === 'error' || result.state === 'cancel') {
                    // 支付失败，停止轮询
                    clearInterval(this.statusInterval);
                    
                    // 更新UI显示支付失败
                    this._updateStatusUI('error', result.message || _t('支付失败或已取消'));
                }
                else if (result.state === 'expired') {
                    // 支付超时，停止轮询
                    clearInterval(this.statusInterval);
                    clearInterval(this.countdownInterval);
                    
                    // 显示二维码过期
                    this._showQRCodeExpired();
                }
            })
            .catch(error => {
                console.error('Error checking payment status:', error);
            });
        },

        /**
         * 更新状态UI
         * 
         * @private
         * @param {string} status - 状态类型: 'processing', 'success', 'error'
         * @param {string} message - 显示的消息
         */
        _updateStatusUI: function (status, message) {
            // 隐藏所有状态信息
            this.$('.wechatpay-status .alert').hide();
            
            if (status === 'processing') {
                this.$('.wechatpay-processing').show();
            } 
            else if (status === 'success') {
                this.$('.wechatpay-success').show();
                // 添加成功样式
                this.$el.addClass('payment-done');
            } 
            else if (status === 'error') {
                this.$('.wechatpay-error').text(message).show();
                // 添加错误样式
                this.$el.addClass('payment-failed');
            }
        },

        /**
         * 刷新二维码处理
         * 
         * @private
         * @param {Event} ev - 点击事件
         */
        _onRefreshQRCode: function (ev) {
            ev.preventDefault();
            const $button = $(ev.currentTarget);
            
            // 禁用按钮并显示加载状态
            $button.prop('disabled', true)
                .find('i').removeClass('fa-refresh').addClass('fa-spinner wechatpay-spin');
            
            // 重置状态显示
            this._updateStatusUI('processing', '');
            this.$el.removeClass('payment-done payment-failed');
            this.$('.wechatpay-qrcode-display').removeClass('expired');
            
            // 调用后端获取新的二维码
            ajax.jsonRpc('/payment/wechatpay/get_qrcode', 'call', {
                provider_id: this.$el.data('provider-id'),
                reference: this.txReference,
                tx_id: this.txId
            })
            .then(result => {
                if (result.success) {
                    // 更新二维码图片
                    if (result.qrcode_img) {
                        const $qrcodeImg = this.$('.wechatpay-qrcode-image');
                        if ($qrcodeImg.length) {
                            $qrcodeImg.attr('src', 'data:image/png;base64,' + result.qrcode_img);
                        } else {
                            this.$('.wechatpay-qrcode-placeholder').replaceWith(
                                $('<img>').addClass('wechatpay-qrcode-image')
                                    .attr('src', 'data:image/png;base64,' + result.qrcode_img)
                                    .attr('alt', 'Scan to pay')
                            );
                        }
                    }
                    
                    // 重新开始倒计时
                    clearInterval(this.countdownInterval);
                    this._startCountdown();
                    
                    // 重新开始状态轮询
                    clearInterval(this.statusInterval);
                    this._startStatusPolling();
                } else {
                    // 显示错误信息
                    this._updateStatusUI('error', result.message || _t('获取二维码失败'));
                }
            })
            .catch(() => {
                this._updateStatusUI('error', _t('刷新二维码失败，请稍后再试'));
            })
            .finally(() => {
                // 恢复按钮状态
                $button.prop('disabled', false)
                    .find('i').removeClass('fa-spinner wechatpay-spin').addClass('fa-refresh');
            });
        },

        /**
         * 取消支付处理
         * 
         * @private
         * @param {Event} ev - 点击事件
         */
        _onCancelPayment: function (ev) {
            // 取消支付前确认
            if (!confirm(_t('确定要取消本次支付吗？'))) {
                ev.preventDefault();
            }
        },

        /**
         * 模拟支付处理 (仅测试环境)
         * 
         * @private
         * @param {Event} ev - 点击事件
         */
        _onSimulatePayment: function (ev) {
            // 表单提交处理已内置，无需额外JS处理
            const $button = $(ev.currentTarget);
            $button.prop('disabled', true).text(_t('处理中...'));
        }
    });

    return publicWidget.registry.WeChatPayForm;
}); 