odoo.define('pethome_payment_wechatpay.wechatpay', function (require) {
    'use strict';

    var core = require('web.core');
    var publicWidget = require('web.public.widget');
    var _t = core._t;

    publicWidget.registry.PetHomeWechatPayWidget = publicWidget.Widget.extend({
        selector: '.o_wechatpay_qrcode_container',
        events: {
            'click .o_wechatpay_check_status': '_onClickCheckStatus',
        },

        /**
         * @override
         */
        start: function () {
            var self = this;
            return this._super.apply(this, arguments).then(function () {
                // 如果存在自动轮询参数则启动轮询
                if (self.$el.data('auto-poll') === true || self.$el.data('auto-poll') === 'true') {
                    self._startPolling();
                }
            });
        },

        /**
         * 开始轮询检查支付状态
         * @private
         */
        _startPolling: function () {
            var self = this;
            var reference = this.$el.data('reference');
            if (!reference) {
                console.error('[WeChat Pay] 缺少轮询所需的订单参考号');
                return;
            }

            // 设置轮询间隔
            this._pollingInterval = setInterval(function () {
                self._checkPaymentStatus(reference);
            }, 3000); // 每3秒检查一次

            // 设置超时时间，避免长时间轮询
            this._pollingTimeout = setTimeout(function () {
                self._stopPolling();
                console.log('[WeChat Pay] 支付状态轮询已超时');
            }, 5 * 60 * 1000); // 5分钟超时
        },

        /**
         * 停止轮询
         * @private
         */
        _stopPolling: function () {
            if (this._pollingInterval) {
                clearInterval(this._pollingInterval);
                this._pollingInterval = null;
            }
            if (this._pollingTimeout) {
                clearTimeout(this._pollingTimeout);
                this._pollingTimeout = null;
            }
        },

        /**
         * 检查支付状态
         * @private
         * @param {string} reference - 订单参考号
         */
        _checkPaymentStatus: function (reference) {
            var self = this;
            this._rpc({
                route: '/payment/wechatpay/check_status',
                params: {
                    reference: reference,
                },
            }).then(function (result) {
                if (result.error) {
                    console.error('[WeChat Pay] 检查支付状态错误:', result.error);
                    // 显示错误信息
                    self.$('.o_wechatpay_status_message').removeClass('d-none').addClass('text-danger')
                        .text(result.error);
                } else if (result.done) {
                    // 支付成功，停止轮询
                    self._stopPolling();
                    // 显示成功信息
                    self.$('.o_wechatpay_status_message').removeClass('d-none').addClass('text-success')
                        .text(_t('支付成功，正在跳转...'));
                    
                    // 使用表单提交方式跳转，避免直接跳转可能导致的DOM操作时序问题
                    self._redirectAfterPayment(reference);
                } else if (result.pending) {
                    // 支付待处理
                    self.$('.o_wechatpay_status_message').removeClass('d-none').removeClass('text-danger')
                        .addClass('text-info').text(result.message || _t('支付处理中，请稍候...'));
                }
            }).guardedCatch(function (error) {
                console.error('[WeChat Pay] 检查支付状态请求失败:', error);
            });
        },

        /**
         * 支付成功后进行跳转
         * @private
         * @param {string} reference - 订单参考号
         */
        _redirectAfterPayment: function (reference) {
            // 创建表单进行POST提交
            var $form = $('<form>', {
                action: '/payment/process',
                method: 'post'
            });
            
            // 添加必要的参数
            $form.append($('<input>', {
                type: 'hidden',
                name: 'reference',
                value: reference
            }));
            
            // 添加CSRF令牌
            var csrf_token = odoo.csrf_token;
            if (csrf_token) {
                $form.append($('<input>', {
                    type: 'hidden',
                    name: 'csrf_token',
                    value: csrf_token
                }));
            }
            
            // 添加到文档并提交
            $(document.body).append($form);
            $form.submit();
        },

        /**
         * 点击检查状态按钮处理函数
         * @private
         * @param {MouseEvent} ev
         */
        _onClickCheckStatus: function (ev) {
            ev.preventDefault();
            var reference = this.$el.data('reference');
            if (reference) {
                this._checkPaymentStatus(reference);
            }
        },

        /**
         * 组件销毁时清理
         * @override
         */
        destroy: function () {
            this._stopPolling();
            this._super.apply(this, arguments);
        },
    });

    return publicWidget.registry.PetHomeWechatPayWidget;
}); 