# 微信支付 for Odoo 18

本模块实现了Odoo 18中微信支付的功能，支持以下特性：

- 通过微信扫码支付（Native）
- 支付结果同步和异步通知
- 查询订单状态
- 关闭订单
- 申请退款
- 退款结果通知

## 系统需求

- Odoo 18
- Python 3.10+
- 必要的Python依赖库（见下文安装说明）

## 安装说明

### 1. 安装模块
将本模块上传到Odoo的自定义插件目录（通常是 `/addons` 目录），并通过Odoo的应用管理界面安装。

### 2. 安装必要的依赖库
本模块依赖一些外部Python库。请通过以下命令安装：

```bash
# 进入模块目录
cd /path/to/pethome_payment_wechatpay

# 执行安装脚本（给予执行权限）
chmod +x install_dependencies.sh
./install_dependencies.sh
```

或者手动安装依赖：
```bash
pip3 install pycryptodome>=3.17.0 requests>=2.25.0 cryptography>=38.0.0 qrcode>=7.3.1 Pillow>=9.0.0
```
pip3 install --break-system-packages "cryptography>=38.0.0" "pycryptodome>=3.17.0" "qrcode>=7.3.1" "requests>=2.28.0" "Pillow>=9.0.0"


## 配置说明

安装模块后，需要进行以下配置：

### 正式环境配置
1. 进入Odoo后台，导航至"会计" -> "配置" -> "支付方式"
2. 查找并选择"WeChat Pay"
3. 点击"启用"按钮
4. 填写以下信息：
   - AppID
   - 商户号 (mch_id)
   - API密钥 (API V3密钥)
   - 证书序列号
   - 商户私钥（apiclient_key.pem）
   - 商户证书（apiclient_cert.pem）

### 测试模式配置
微信支付官方不提供沙箱环境，但本模块提供了测试模式功能：

1. 在支付方式配置页面选择"测试"模式而不是"启用"
2. 填写测试环境配置（可以使用与正式环境相同的值）
3. 在测试模式下，模块不会发送真正的API请求到微信支付服务器，而是使用模拟数据进行测试

## 支付流程

本模块实现了微信支付的Native（扫码支付）模式：

1. 用户在Odoo商城选择商品后，选择"微信支付"作为支付方式
2. 系统生成支付二维码
3. 用户使用微信扫描二维码支付
4. 支付完成后，微信服务器向Odoo服务器发送异步通知
5. Odoo收到通知后，更新订单状态

## 测试模式说明

由于微信支付不提供官方沙箱环境，本模块实现了测试模式：

1. 测试模式下生成的二维码为固定测试码，不会触发实际支付
2. 系统会模拟支付成功的回调和查询响应
3. 可以通过手动点击交易记录中的"检查支付状态"按钮模拟支付成功
4. 所有API调用都不会发送到微信支付服务器，避免产生真实交易
5. 测试模式适合在开发和测试环境下使用，上线前需切换到正式环境

## 开发信息

### 文件结构
```
pethome_payment_wechatpay/
├── __init__.py                  # 模块初始化文件
├── __manifest__.py              # 模块配置文件
├── const.py                     # 常量定义
├── requirements.txt             # 依赖库列表
├── install_dependencies.sh      # 依赖安装脚本
├── controllers/                 # 控制器目录
│   ├── __init__.py
│   └── controllers.py           # 通知和回调控制器
├── models/                      # 模型目录
│   ├── __init__.py
│   ├── payment_provider.py      # 支付提供商实现
│   └── payment_transaction.py   # 交易处理实现
├── data/                        # 数据文件目录
│   └── payment_provider_data.xml # 支付提供商数据
├── security/                    # 安全设置
│   ├── ir.model.access.csv
│   └── data.xml
├── static/                      # 静态资源
│   └── src/
│       └── img/
│           └── wechatpay.png    # 微信支付图标
├── i18n/                        # 国际化翻译
│   └── zh_CN.po                 # 中文翻译文件
└── views/                       # 视图定义
    ├── templates.xml            # 模板定义
    └── views.xml                # 视图定义
```

## 与其他支付插件共存

本模块设计为可以与其他支付模块（如支付宝）共存：

1. 所有方法和字段都使用微信支付特定的前缀
2. 模块钩子和初始化函数只处理微信支付相关的功能
3. 日志消息使用特定前缀，便于区分和调试
4. 所有API调用和处理都是封装的，不会影响其他支付模块

## 技术支持

如需技术支持，请联系：

- 邮箱：support@catlover.cn
- 网站：https://www.catlover.cn

## 许可证

本模块基于LGPL-3许可证发布，详情请参阅LICENSE文件。 