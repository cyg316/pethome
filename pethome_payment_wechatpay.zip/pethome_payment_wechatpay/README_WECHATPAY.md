# Odoo 18 微信支付集成 - 基于WeChat Pay V3 API

本模块实现了微信支付在Odoo 18中的完整集成，支持扫码支付（Native）方式。基于微信支付V3 API开发。

## 技术特点

- 基于微信支付V3 API，支持最新的接口规范和安全标准
- 完整实现RSA签名和验签机制，确保支付安全
- 支持AEAD_AES_256_GCM算法解密通知数据
- 自动生成和展示支付二维码
- 异步轮询支付状态，提供实时反馈
- 全中文界面，适合国内用户使用

## 依赖库

本模块依赖以下Python库：

- `pycryptodome`: 加密算法支持
- `requests`: HTTP请求库
- `cryptography`: 加密库，用于RSA签名和验签
- `qrcode`: 生成二维码
- `Pillow`: 图片处理，用于二维码生成

## 安装

1. 将本模块放置在Odoo的addons目录下
2. 安装依赖库：

```bash
pip install pycryptodome requests cryptography qrcode Pillow
```

或者使用提供的安装脚本：

```bash
bash install_dependencies.sh
```

3. 在Odoo的应用列表中找到"Payment WeChat Pay"并安装

## 配置

### 1. 获取微信支付商户资料

在使用本模块前，您需要：

- 申请微信支付商户号
- 生成API v3密钥
- 申请商户API证书
- 获取商户号对应的APPID

### 2. 配置支付方式

在Odoo后台：

1. 进入`会计/发票 > 配置 > 支付方式`
2. 找到"WeChat Pay"并点击"激活"
3. 填写以下信息：
   - AppID: 微信支付 AppID
   - 商户号: 微信支付商户号
   - API密钥: 微信支付 API V3密钥
   - 证书序列号: 商户API证书序列号
   - 商户私钥: 上传商户API私钥文件(apiclient_key.pem)

### 3. 设置回调地址

确保您的Odoo服务器可以通过互联网访问，并设置正确的域名。微信支付回调URL将自动配置为：

```
https://您的域名/payment/wechatpay/notify
```

## 使用

### 在网站商城中使用

当客户选择"WeChat Pay"作为支付方式后：

1. 系统会生成一个支付二维码
2. 客户使用微信扫描二维码完成支付
3. 支付成功后，订单状态会自动更新，客户将收到订单确认信息

### 测试模式

本模块支持测试模式，可以在不实际调用微信支付API的情况下测试支付流程：

1. 在支付方式配置中，将"状态"设置为"测试"
2. 测试模式下会模拟生成二维码和支付响应
3. 测试页面上会提供"模拟支付完成"按钮，方便开发测试

## 错误排查

常见问题及解决方法：

1. **无法生成二维码**: 检查AppID、商户号和API密钥是否正确配置
2. **回调通知未收到**: 确认服务器可以从互联网访问，检查回调URL是否正确
3. **签名验证失败**: 确认证书和密钥文件内容正确且格式为PEM格式
4. **依赖库安装问题**: 使用`pip install -r requirements.txt`确保所有依赖正确安装

## 安全说明

- 商户敏感信息（如API密钥、证书）存储在Odoo数据库中，请确保数据库安全
- 商户私钥数据在传输和存储过程中会被加密处理
- 确保您的Odoo服务使用HTTPS协议，保护支付数据传输安全

## 参考资料

- [微信支付V3 API文档](https://pay.weixin.qq.com/wiki/doc/apiv3/index.shtml)
- [微信支付商户平台](https://pay.weixin.qq.com/index.php/core/home/login)

## 版权信息

本模块基于LGPL-3许可发布。

## 支持与维护

如有问题或需要支持，请联系开发者或在GitHub仓库提交issue。 