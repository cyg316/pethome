# -*- coding: utf-8 -*-

# 微信支付-支持的货币
# 微信支付只支持人民币
SUPPORTED_CURRENCIES = ['CNY']

# 默认支付方法
DEFAULT_PAYMENT_METHODS_CODES = ['wechatpay']

# 微信支付接口URLs
WECHATPAY_API_URLS = {
    # 正式环境URL
    'native': 'https://api.mch.weixin.qq.com/v3/pay/transactions/native',
    'query': 'https://api.mch.weixin.qq.com/v3/pay/transactions/out-trade-no/{out_trade_no}',
    'close': 'https://api.mch.weixin.qq.com/v3/pay/transactions/out-trade-no/{out_trade_no}/close',
    'refund': 'https://api.mch.weixin.qq.com/v3/refund/domestic/refunds',
}

# 测试模式下，不发送实际API请求，而是返回模拟数据
TEST_MODE_RESPONSES = {
    'native': {
        'code_url': 'weixin://wxpay/bizpayurl?pr=test_code_url'
    },
    'query': {
        'mchid': '{mch_id}',
        'appid': '{appid}',
        'out_trade_no': '{out_trade_no}',
        'transaction_id': 'test_transaction_id_{timestamp}',
        'trade_type': 'NATIVE',
        'trade_state': 'SUCCESS',
        'trade_state_desc': '支付成功',
        'bank_type': 'OTHERS',
        'attach': '',
        'success_time': '{success_time}',
        'payer': {
            'openid': 'test_openid'
        },
        'amount': {
            'total': '{amount}',
            'currency': 'CNY',
            'payer_total': '{amount}',
            'payer_currency': 'CNY'
        }
    },
    'close': {'status': 'success'},
    'refund': {
        'refund_id': 'test_refund_id_{timestamp}',
        'out_refund_no': '{out_refund_no}',
        'transaction_id': 'test_transaction_id_{timestamp}',
        'out_trade_no': '{out_trade_no}',
        'channel': 'ORIGINAL',
        'user_received_account': '支付用户零钱',
        'success_time': '{success_time}',
        'create_time': '{create_time}',
        'status': 'SUCCESS',
        'funds_account': 'AVAILABLE',
        'amount': {
            'total': '{total}',
            'refund': '{refund}',
            'payer_total': '{total}',
            'payer_refund': '{refund}',
            'currency': 'CNY'
        }
    }
} 