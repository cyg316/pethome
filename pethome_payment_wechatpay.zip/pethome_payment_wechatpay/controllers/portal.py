# -*- coding: utf-8 -*-
import logging
import werkzeug
import qrcode
import base64
from io import BytesIO
from odoo import http, _
from odoo.http import request
from odoo.addons.portal.controllers.portal import CustomerPortal

_logger = logging.getLogger(__name__)

class WeChatPayPortal(CustomerPortal):
    
    @http.route(['/my/wechatpay/payment/<int:tx_id>'], type='http', auth='public', website=True)
    def wechatpay_payment_page(self, tx_id, access_token=None, **kwargs):
        """展示微信支付二维码的页面"""
        # 安全检查
        try:
            tx_sudo = self._document_check_access('payment.transaction', tx_id, access_token)
        except (werkzeug.exceptions.NotFound, ValueError):
            return request.redirect('/my')
            
        if tx_sudo.provider_code != 'wechatpay' or tx_sudo.state != 'draft':
            return request.redirect('/my')
        
        # 生成微信支付二维码
        qrcode_url = tx_sudo.provider_id._wechatpay_create_transaction(tx_sudo.amount, tx_sudo.reference)
        
        # 生成图片二维码
        qrcode_img = None
        try:
            if qrcode_url:
                # 使用工具类生成二维码
                from ..models.utils import WechatPayUtils
                qrcode_img = WechatPayUtils.generate_qrcode(qrcode_url)
                
                # 如果工具类不可用，使用直接方法
                if not qrcode_img:
                    img = qrcode.make(qrcode_url)
                    buffer = BytesIO()
                    img.save(buffer)
                    qrcode_img = base64.b64encode(buffer.getvalue()).decode('utf-8')
        except Exception as qr_error:
            _logger.exception(f"[PetHome Payment WeChat Pay] 生成二维码图片失败: {str(qr_error)}")
        
        # 更新交易状态为等待中
        if tx_sudo.state == 'draft':
            tx_sudo._set_pending()
        
        # 渲染二维码页面
        return request.render('pethome_payment_wechatpay.payment_wechatpay_qrcode', {
            'tx': tx_sudo,
            'qrcode_img': qrcode_img,
            'qrcode_url': qrcode_url,
            'reference': tx_sudo.reference,
            'amount': tx_sudo.amount,
            'currency': tx_sudo.currency_id.name,
            'partner': tx_sudo.partner_id,
            'access_token': access_token,
        })
    
    @http.route(['/my/wechatpay/check_status_page/<int:tx_id>'], type='http', auth='public', website=True)
    def wechatpay_check_status_page(self, tx_id, access_token=None, **kwargs):
        """检查微信支付状态并显示状态页面"""
        try:
            tx_sudo = self._document_check_access('payment.transaction', tx_id, access_token)
        except (werkzeug.exceptions.NotFound, ValueError):
            return request.redirect('/my')
            
        if tx_sudo.provider_code != 'wechatpay':
            return request.redirect('/my')
        
        # 手动检查支付状态
        tx_sudo.action_wechatpay_check_status()
        
        # 如果支付成功，重定向到成功页面
        if tx_sudo.state == 'done':
            return request.redirect(tx_sudo.landing_route or '/payment/status')
        
        # 显示支付状态页面
        values = {
            'tx': tx_sudo,
            'reference': tx_sudo.reference,
            'amount': tx_sudo.amount,
            'currency': tx_sudo.currency_id.name,
            'partner': tx_sudo.partner_id,
            'access_token': access_token,
        }
        
        return request.render('pethome_payment_wechatpay.payment_wechatpay_status', values)
    
    @http.route(['/my/wechatpay/payment_status/<int:tx_id>'], type='http', auth='public', website=True)
    def wechatpay_payment_status_page(self, tx_id, access_token=None, **kwargs):
        """显示微信支付状态页面"""
        try:
            tx_sudo = self._document_check_access('payment.transaction', tx_id, access_token)
        except (werkzeug.exceptions.NotFound, ValueError):
            return request.redirect('/my')
            
        if tx_sudo.provider_code != 'wechatpay':
            return request.redirect('/my')
        
        values = {
            'tx': tx_sudo,
            'reference': tx_sudo.reference,
            'amount': tx_sudo.amount,
            'currency': tx_sudo.currency_id.name,
            'partner': tx_sudo.partner_id,
            'access_token': access_token,
        }
        
        return request.render('pethome_payment_wechatpay.payment_wechatpay_status', values)
