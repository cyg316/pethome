# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import logging
from odoo.exceptions import ValidationError
import json
import traceback
import base64
from cryptography.hazmat.primitives.asymmetric.padding import PKCS1v15
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
import time
from datetime import datetime

_logger = logging.getLogger(__name__)

class WeChatPay(http.Controller):

    @http.route('/payment/wechatpay/notify', csrf=False, type="http", auth='none', methods=["POST"])
    def wechatpay_notify(self, **kwargs):
        """
        接收来自微信支付的通知
        """
        _logger.info("[PetHome Payment WeChat Pay] 接收到微信支付通知")
        
        try:
            # 获取请求体
            data = request.httprequest.data
            
            # 记录请求头信息
            headers = request.httprequest.headers
            timestamp = headers.get('Wechatpay-Timestamp')
            nonce = headers.get('Wechatpay-Nonce')
            signature = headers.get('Wechatpay-Signature')
            serial_no = headers.get('Wechatpay-Serial')
            
            # 记录通知数据
            _logger.info(f"[PetHome Payment WeChat Pay] 通知数据: {data.decode('utf-8')}")
            _logger.info(f"[PetHome Payment WeChat Pay] 通知头信息: timestamp={timestamp}, nonce={nonce}, serial={serial_no}")
            
            # 查找支付提供商
            payment_provider = request.env["payment.provider"].sudo().search(
                [('code', '=', 'wechatpay')], limit=1)
                
            if not payment_provider:
                _logger.error("[PetHome Payment WeChat Pay] 未找到微信支付提供商")
                return json.dumps({
                    "code": "FAIL",
                    "message": "未找到微信支付提供商"
                })
            
            # 测试模式下跳过签名验证
            is_test_mode = payment_provider.state == 'test'
            
            # 验证通知签名 (测试模式下跳过验证)
            if not is_test_mode and not self._verify_notification(payment_provider, timestamp, nonce, signature, data, serial_no):
                _logger.error("[PetHome Payment WeChat Pay] 通知签名验证失败")
                return json.dumps({
                    "code": "FAIL",
                    "message": "签名验证失败"
                })
            
            # 解析通知数据
            notification_data = json.loads(data.decode('utf-8'))
            resource = notification_data.get('resource', {})
            
            # 测试模式下可以处理模拟通知
            if is_test_mode and not resource.get('ciphertext'):
                _logger.info("[PetHome Payment WeChat Pay] 测试模式：处理模拟通知数据")
                # 创建模拟解密后的数据
                decrypted_data = {
                    'mchid': payment_provider.wechatpay_test_mch_id or 'test_mch_id',
                    'appid': payment_provider.wechatpay_test_appid or 'test_appid',
                    'out_trade_no': notification_data.get('out_trade_no', f'test_order_{int(time.time())}'),
                    'transaction_id': f'test_transaction_id_{int(time.time())}',
                    'trade_type': 'NATIVE',
                    'trade_state': 'SUCCESS',
                    'trade_state_desc': '支付成功',
                    'success_time': datetime.now().strftime('%Y-%m-%dT%H:%M:%S+08:00'),
                    'amount': {
                        'total': 100,  # 1元人民币
                        'currency': 'CNY'
                    }
                }
            # 正常模式下解密数据
            elif 'ciphertext' in resource:
                decrypted_data = payment_provider._decrypt_resource(resource)
                _logger.info(f"[PetHome Payment WeChat Pay] 解密后数据: {decrypted_data}")
            else:
                _logger.error("[PetHome Payment WeChat Pay] 通知数据不包含加密资源")
                return json.dumps({
                    "code": "FAIL",
                    "message": "通知数据格式错误"
                })
                
            # 处理不同类型的通知
            event_type = notification_data.get('event_type', 'TRANSACTION.SUCCESS')  # 默认为支付成功事件
            
            if event_type == 'TRANSACTION.SUCCESS':
                # 支付成功通知
                out_trade_no = decrypted_data.get('out_trade_no')
                transaction_id = decrypted_data.get('transaction_id')
                
                if out_trade_no:
                    # 查找对应的交易记录
                    tx_obj = request.env['payment.transaction'].sudo()
                    tx = tx_obj.search([('reference', '=', out_trade_no), 
                                      ('provider_code', '=', 'wechatpay')], limit=1)
                    
                    if tx:
                        # 设置微信支付交易号
                        tx.provider_reference = transaction_id
                        
                        # 处理通知
                        tx._handle_notification_data('wechatpay', decrypted_data)
                        _logger.info(f"[PetHome Payment WeChat Pay] 成功处理交易 {out_trade_no} 的支付通知")
                    else:
                        _logger.warning(f"[PetHome Payment WeChat Pay] 未找到交易记录 {out_trade_no}")
                        
            elif event_type == 'REFUND.SUCCESS':
                # 退款成功通知
                out_trade_no = decrypted_data.get('out_trade_no')
                out_refund_no = decrypted_data.get('out_refund_no')
                
                _logger.info(f"[PetHome Payment WeChat Pay] 收到退款成功通知: {out_refund_no}")
                # 可以在此处理退款逻辑
                
            else:
                _logger.info(f"[PetHome Payment WeChat Pay] 收到其他类型通知: {event_type}")
            
            # 返回成功响应
            return json.dumps({
                "code": "SUCCESS",
                "message": "成功"
            })
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 处理通知异常: {str(e)}")
            _logger.error(f"[PetHome Payment WeChat Pay] 异常详情: {traceback.format_exc()}")
            
            # 即使发生异常也返回成功，避免微信重复通知
            return json.dumps({
                "code": "SUCCESS",
                "message": "成功"
            })
    
    def _verify_notification(self, provider, timestamp, nonce, signature, data, serial_no):
        """
        验证微信支付通知签名
        """
        # 测试模式下跳过验证
        if provider.state == 'test':
            _logger.info("[PetHome Payment WeChat Pay] 测试模式：跳过通知签名验证")
            return True
            
        try:
            if not all([timestamp, nonce, signature, serial_no]):
                _logger.error("[PetHome Payment WeChat Pay] 缺少验证签名所需的头信息")
                return False
                
            # 获取微信平台证书
            platform_cert = provider._get_platform_cert(serial_no)
            if not platform_cert:
                _logger.error(f"[PetHome Payment WeChat Pay] 未找到序列号为 {serial_no} 的平台证书")
                return False
                
            # 构造验签名串
            message = timestamp + "\n" + nonce + "\n" + data.decode('utf-8') + "\n"
            
            # 微信平台公钥
            try:
                public_key = serialization.load_pem_public_key(
                    platform_cert.encode('utf-8')
                )
            except Exception as e:
                _logger.exception(f"[PetHome Payment WeChat Pay] 加载平台公钥失败: {str(e)}")
                return False
            
            # Base64解码签名
            signature_bytes = base64.b64decode(signature)
            
            # 验证签名
            try:
                public_key.verify(
                    signature_bytes,
                    message.encode('utf-8'),
                    PKCS1v15(),
                    SHA256()
                )
                _logger.info("[PetHome Payment WeChat Pay] 通知签名验证成功")
                return True
            except Exception as e:
                _logger.exception(f"[PetHome Payment WeChat Pay] 验证签名失败: {str(e)}")
                return False
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 验证通知签名异常: {str(e)}")
            return False 