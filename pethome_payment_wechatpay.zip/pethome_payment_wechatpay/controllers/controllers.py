# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import logging
from odoo.exceptions import ValidationError
import json
import traceback
import base64
from cryptography.hazmat.primitives.asymmetric.padding import PKCS1v15
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
import time
from datetime import datetime
import qrcode
from io import BytesIO
import werkzeug
import pprint
from werkzeug.exceptions import Forbidden
from odoo.addons.pethome_payment_wechatpay.models.utils import WechatPayUtils

_logger = logging.getLogger(__name__)

class WeChatPay(http.Controller):

    @http.route('/payment/wechatpay/notify', csrf=False, type="http", auth='none', methods=["POST"])
    def wechatpay_notify(self, **kwargs):
        """
        接收来自微信支付的异步通知
        参考: https://pay.weixin.qq.com/wiki/doc/apiv3/apis/chapter3_4_5.shtml
        """
        _logger.info("[PetHome Payment WeChat Pay] 接收到微信支付通知")
        
        try:
            # 获取请求体
            data = request.httprequest.data
            
            # 记录请求头信息
            headers = request.httprequest.headers
            timestamp = headers.get('Wechatpay-Timestamp')
            nonce = headers.get('Wechatpay-Nonce')
            signature = headers.get('Wechatpay-Signature')
            serial_no = headers.get('Wechatpay-Serial')
            
            # 记录通知数据
            _logger.info(f"[PetHome Payment WeChat Pay] 通知数据: {data.decode('utf-8')}")
            _logger.info(f"[PetHome Payment WeChat Pay] 通知头信息: timestamp={timestamp}, nonce={nonce}, serial={serial_no}")
            
            # 查找支付提供商
            payment_provider = request.env["payment.provider"].sudo().search(
                [('code', '=', 'wechatpay')], limit=1)
                
            if not payment_provider:
                _logger.error("[PetHome Payment WeChat Pay] 未找到微信支付提供商")
                return json.dumps({
                    "code": "FAIL",
                    "message": "未找到微信支付提供商"
                })
            
            # 测试模式下跳过签名验证
            is_test_mode = payment_provider.state == 'test'
            
            # 验证通知签名 (测试模式下跳过验证)
            if not is_test_mode and not self._verify_notification(payment_provider, timestamp, nonce, signature, data, serial_no):
                _logger.error("[PetHome Payment WeChat Pay] 通知签名验证失败")
                return json.dumps({
                    "code": "FAIL",
                    "message": "签名验证失败"
                })
            
            # 解析通知数据
            notification_data = json.loads(data.decode('utf-8'))
            resource = notification_data.get('resource', {})
            
            # 测试模式下可以处理模拟通知
            if is_test_mode and not resource.get('ciphertext'):
                _logger.info("[PetHome Payment WeChat Pay] 测试模式：处理模拟通知数据")
                # 创建模拟解密后的数据
                decrypted_data = {
                    'mchid': payment_provider.wechatpay_mch_id or 'test_mch_id',
                    'appid': payment_provider.wechatpay_appid or 'test_appid',
                    'out_trade_no': notification_data.get('out_trade_no', f'test_order_{int(time.time())}'),
                    'transaction_id': f'test_transaction_id_{int(time.time())}',
                    'trade_type': 'NATIVE',
                    'trade_state': 'SUCCESS',
                    'trade_state_desc': '支付成功',
                    'success_time': datetime.now().strftime('%Y-%m-%dT%H:%M:%S+08:00'),
                    'amount': {
                        'total': 100,  # 1元人民币
                        'currency': 'CNY'
                    }
                }
            # 正常模式下解密数据
            elif 'ciphertext' in resource:
                try:
                    decrypted_data = payment_provider._decrypt_resource(resource)
                    _logger.info(f"[PetHome Payment WeChat Pay] 解密后数据: {decrypted_data}")
                except Exception as e:
                    _logger.exception(f"[PetHome Payment WeChat Pay] 解密通知数据异常: {str(e)}")
                    return json.dumps({
                        "code": "FAIL",
                        "message": "解密数据失败"
                    })
            else:
                _logger.error("[PetHome Payment WeChat Pay] 通知数据不包含加密资源")
                return json.dumps({
                    "code": "FAIL",
                    "message": "通知数据格式错误"
                })
                
            # 处理不同类型的通知
            event_type = notification_data.get('event_type', 'TRANSACTION.SUCCESS')  # 默认为支付成功事件
            
            if event_type == 'TRANSACTION.SUCCESS':
                # 支付成功通知
                out_trade_no = decrypted_data.get('out_trade_no')
                transaction_id = decrypted_data.get('transaction_id')
                trade_state = decrypted_data.get('trade_state')
                
                if not out_trade_no:
                    _logger.error("[PetHome Payment WeChat Pay] 通知数据缺少订单号")
                    return json.dumps({
                        "code": "FAIL",
                        "message": "通知数据缺少订单号"
                    })
                
                # 只处理成功状态的交易
                if trade_state != 'SUCCESS':
                    _logger.info(f"[PetHome Payment WeChat Pay] 交易 {out_trade_no} 状态不是成功: {trade_state}")
                    return json.dumps({
                        "code": "SUCCESS",
                        "message": "成功"
                    })
                
                # 查找对应的交易记录
                tx_obj = request.env['payment.transaction'].sudo()
                tx = tx_obj.search([('reference', '=', out_trade_no), 
                                  ('provider_code', '=', 'wechatpay')], limit=1)
                
                if tx:
                    # 避免重复处理
                    if tx.state == 'done' and tx.provider_reference == transaction_id:
                        _logger.info(f"[PetHome Payment WeChat Pay] 交易 {out_trade_no} 已处理，跳过")
                        return json.dumps({
                            "code": "SUCCESS",
                            "message": "成功"
                        })
                    
                    # 设置微信支付交易号
                    tx.provider_reference = transaction_id
                    
                    # 处理通知
                    tx._handle_notification_data('wechatpay', decrypted_data)
                    _logger.info(f"[PetHome Payment WeChat Pay] 成功处理交易 {out_trade_no} 的支付通知")
                else:
                    _logger.warning(f"[PetHome Payment WeChat Pay] 未找到交易记录 {out_trade_no}")
                        
            elif event_type == 'REFUND.SUCCESS':
                # 退款成功通知
                out_trade_no = decrypted_data.get('out_trade_no')
                out_refund_no = decrypted_data.get('out_refund_no')
                
                _logger.info(f"[PetHome Payment WeChat Pay] 收到退款成功通知: {out_refund_no}, 订单号: {out_trade_no}")
                # TODO: 处理退款逻辑
                
            else:
                _logger.info(f"[PetHome Payment WeChat Pay] 收到其他类型通知: {event_type}")
            
            # 返回成功响应
            return json.dumps({
                "code": "SUCCESS",
                "message": "成功"
            })
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 处理通知异常: {str(e)}")
            _logger.error(f"[PetHome Payment WeChat Pay] 异常详情: {traceback.format_exc()}")
            
            # 即使发生异常也返回成功，避免微信重复通知
            return json.dumps({
                "code": "SUCCESS",
                "message": "成功"
            })
    
    def _verify_notification(self, provider, timestamp, nonce, signature, data, serial_no):
        """
        验证微信支付通知签名
        """
        # 测试模式下跳过验证
        if provider.state == 'test':
            _logger.info("[PetHome Payment WeChat Pay] 测试模式：跳过通知签名验证")
            return True
            
        try:
            if not all([timestamp, nonce, signature, serial_no]):
                _logger.error("[PetHome Payment WeChat Pay] 缺少验证签名所需的头信息")
                return False
                
            # 获取微信平台证书
            platform_cert = provider._get_platform_cert(serial_no)
            if not platform_cert:
                _logger.error(f"[PetHome Payment WeChat Pay] 未找到序列号为 {serial_no} 的平台证书")
                return False
                
            # 构造验签名串
            message = timestamp + "\n" + nonce + "\n" + data.decode('utf-8') + "\n"
            
            # 微信平台公钥
            try:
                public_key = serialization.load_pem_public_key(
                    platform_cert.encode('utf-8')
                )
            except Exception as e:
                _logger.exception(f"[PetHome Payment WeChat Pay] 加载平台公钥失败: {str(e)}")
                return False
            
            # Base64解码签名
            signature_bytes = base64.b64decode(signature)
            
            # 验证签名
            try:
                public_key.verify(
                    signature_bytes,
                    message.encode('utf-8'),
                    PKCS1v15(),
                    SHA256()
                )
                _logger.info("[PetHome Payment WeChat Pay] 通知签名验证成功")
                return True
            except Exception as e:
                _logger.exception(f"[PetHome Payment WeChat Pay] 验证签名失败: {str(e)}")
                return False
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 验证通知签名异常: {str(e)}")
            return False

    @http.route('/payment/wechatpay/get_qrcode', type='json', auth='public')
    def wechatpay_get_qrcode(self, provider_id, reference, amount=0, currency_id=None, **kwargs):
        """获取微信支付二维码"""
        try:
            # 检查参数
            if not provider_id or not reference:
                return {
                    'error': '缺少必要参数'
                }
                
            amount = float(amount)
            if amount <= 0:
                return {
                    'error': '金额必须大于0'
                }

            # 获取支付提供商
            provider = request.env['payment.provider'].sudo().browse(int(provider_id))
            if not provider.exists() or provider.code != 'wechatpay':
                return {
                    'error': '找不到有效的微信支付提供商'
                }
                
            # 获取货币
            currency = None
            if currency_id:
                currency = request.env['res.currency'].sudo().browse(int(currency_id))
                if not currency.exists():
                    return {
                        'error': '找不到有效的货币'
                    }
            else:
                # 使用公司货币
                currency = request.env.company.currency_id
                
            if currency.name not in ['CNY']:
                return {
                    'error': '微信支付仅支持人民币(CNY)支付'
                }
            
            # 创建微信支付二维码
            try:
                # 使用 provider 的方法获取 code_url (可能包含 prepay_id 等)
                # 注意: _wechatpay_create_transaction 在模型中返回包含 code_url 的字典
                payment_data = provider._wechatpay_create_transaction(amount, reference)
                qrcode_url = payment_data.get('code_url') if isinstance(payment_data, dict) else None

                if not qrcode_url:
                    _logger.error(f"[PetHome Payment WeChat Pay]未能从_wechatpay_create_transaction获取qrcode_url: {reference}")
                    return {
                        'error': '创建微信支付交易失败，未能获取二维码URL。'
                    }
                
                # 生成图片二维码 using WechatPayUtils
                qrcode_img = None
                try:
                    qrcode_img = WechatPayUtils.generate_qrcode(qrcode_url)
                except ImportError:
                     _logger.warning("[PetHome Payment WeChat Pay] Controller: 未安装qrcode/Pillow依赖库，无法生成二维码图片")
                except Exception as qr_error:
                    _logger.exception(f"[PetHome Payment WeChat Pay] Controller: 使用 WechatPayUtils 生成二维码图片失败: {str(qr_error)}")
                
                return {
                    'reference': reference,
                    'amount': amount,
                    'currency_name': currency.name,
                    'qrcode_url': qrcode_url,
                    'qrcode_img': qrcode_img # 可能为 None
                }
            except Exception as e:
                _logger.exception(f"[PetHome Payment WeChat Pay] 创建支付二维码失败: {str(e)}")
                return {
                    'error': f'创建支付二维码失败: {str(e)}'
                }
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 获取支付二维码异常: {str(e)}")
            return {
                'error': f'处理请求时出错: {str(e)}'
            }
    
    @http.route('/payment/wechatpay/check_status', type='json', auth='public')
    def wechatpay_check_status(self, reference, **kwargs):
        """检查微信支付状态"""
        try:
            if not reference:
                return {
                    'error': '缺少订单编号'
                }
                
            # 查找交易记录
            tx = request.env['payment.transaction'].sudo().search([
                ('reference', '=', reference),
                ('provider_code', '=', 'wechatpay')
            ], limit=1)
            
            if not tx:
                return {
                    'error': '找不到对应的交易记录'
                }
                
            # 手动检查支付状态
            tx.action_wechatpay_check_status()
            
            # 返回最新状态
            if tx.state == 'done':
                return {
                    'done': True,
                    'message': '支付已完成'
                }
            elif tx.state == 'pending':
                return {
                    'pending': True,
                    'message': '支付处理中，请稍候'
                }
            elif tx.state == 'cancel':
                return {
                    'error': '支付已取消'
                }
            elif tx.state == 'error':
                return {
                    'error': '支付失败'
                }
            else:
                return {
                    'pending': True,
                    'message': f'当前状态: {tx.state}'
                }
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 检查支付状态异常: {str(e)}")
            return {
                'error': f'检查支付状态时出错: {str(e)}'
            }

    @http.route('/payment/wechatpay/return', type='http', auth='public', website=True)
    def wechatpay_return_view(self, reference=None, **kwargs):
        """处理支付完成后的返回"""
        if not reference:
            return request.redirect('/shop')
            
        # 查找交易记录
        tx = request.env['payment.transaction'].sudo().search([
            ('reference', '=', reference),
            ('provider_code', '=', 'wechatpay')
        ], limit=1)
        
        if not tx:
            _logger.warning(f"[PetHome Payment WeChat Pay] 未找到交易记录: {reference}")
            return request.redirect('/shop')
            
        # 检查支付状态
        if tx.state not in ['done', 'pending']:
            try:
                tx.action_wechatpay_check_status()
            except Exception as e:
                _logger.exception(f"[PetHome Payment WeChat Pay] 检查支付状态异常: {str(e)}")
                
        # 根据状态重定向
        if tx.state == 'done':
            return request.redirect('/payment/status')
        else:
            # 显示支付状态页面
            values = {
                'tx': tx,
                'reference': reference,
                'amount': tx.amount,
                'currency': tx.currency_id.name,
            }
            return request.render('pethome_payment_wechatpay.payment_wechatpay_status', values)
            
    @http.route('/payment/wechatpay/simulate', type='http', auth='public', website=True, csrf=True, methods=['POST'])
    def wechatpay_simulate(self, reference=None, **kwargs):
        """测试模式下模拟支付完成"""
        if not reference:
            return request.redirect('/shop')
            
        # 查找交易记录
        tx = request.env['payment.transaction'].sudo().search([
            ('reference', '=', reference),
            ('provider_code', '=', 'wechatpay')
        ], limit=1)
        
        if not tx or tx.provider_id.state != 'test':
            return request.redirect('/shop')
            
        # 模拟支付完成
        try:
            _logger.info(f"[PetHome Payment WeChat Pay] 测试模式：模拟支付完成 {reference}")
            # 设置模拟交易ID
            tx.provider_reference = f'test_simulated_{int(time.time())}'
            # 更新状态为已完成
            tx._set_done()
            tx._finalize_post_processing()
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 模拟支付完成异常: {str(e)}")
            
        # 重定向到支付完成页面
        return request.redirect('/payment/status')

    @http.route('/payment/wechatpay/redirect', type='http', auth='public', methods=['GET'], website=True, csrf=False)
    def wechatpay_redirect(self, **data):
        """处理微信支付重定向"""
        # 从查询参数中获取引用
        reference = data.get('reference')
        if not reference:
            _logger.warning("WeChat Pay: 返回页面缺少引用")
            return werkzeug.utils.redirect('/payment/status')

        # 寻找对应的交易记录
        tx = request.env['payment.transaction'].sudo().search([('reference', '=', reference)], limit=1)
        if not tx:
            _logger.warning(f"WeChat Pay: 未找到交易记录 {reference}")
            return werkzeug.utils.redirect('/payment/status')
            
        # 如果没有二维码URL，需要创建
        if not tx.wechatpay_qrcode_url:
            try:
                # 生成支付交易
                payment_data = tx.provider_id._wechatpay_create_transaction(tx.amount, reference)
                
                if payment_data and 'code_url' in payment_data:
                    qrcode_url = payment_data['code_url']
                    prepay_id = payment_data.get('prepay_id', '')
                    
                    # 更新交易记录
                    tx.write({
                        'wechatpay_qrcode_url': qrcode_url,
                        'wechatpay_prepay_id': prepay_id,
                        'wechatpay_trade_type': 'NATIVE'
                    })
                    
                    # 生成二维码图片
                    try:
                        qrcode_img = WechatPayUtils.generate_qrcode(qrcode_url)
                        if qrcode_img:
                            tx.wechatpay_qrcode = qrcode_img
                    except Exception as e:
                        _logger.exception(f"WeChat Pay: 生成二维码图片失败 - {str(e)}")
                else:
                    _logger.error(f"WeChat Pay: 创建支付交易失败 - {reference}")
                    return request.render("payment.pay_error", {
                        'error_msg': _("创建微信支付交易失败，请稍后重试")
                    })
            except Exception as e:
                _logger.exception(f"WeChat Pay: 创建支付交易异常 - {str(e)}")
                return request.render("payment.pay_error", {
                    'error_msg': _("创建微信支付交易失败: %s") % str(e)
                })

        # 渲染二维码扫码支付页面
        values = {
            'tx': tx,
            'reference': reference,
            'amount': tx.amount,
            'currency': tx.currency_id.name,
            'is_test_mode': tx.provider_id.state == 'test',
            'qrcode_img': tx.wechatpay_qrcode,
            'qrcode_url': tx.wechatpay_qrcode_url,
        }
        return request.render("pethome_payment_wechatpay.payment_wechatpay_qrcode", values)

    def _query_order_status(self, tx):
        """查询微信支付订单状态"""
        # 调用微信支付查询订单API
        provider = tx.provider_id
        reference = tx.reference

        if provider.state == 'test':
            # 测试模式返回模拟数据
            return {
                'trade_state': 'SUCCESS',
                'transaction_id': f'test_txn_{reference}',
                'trade_state_desc': '支付成功',
            }

        # 实际开发中需要调用微信支付API
        try:
            url_path = f'/v3/pay/transactions/out-trade-no/{reference}?mchid={provider.wechatpay_mch_id}'
            result = provider._make_wechatpay_request('GET', url_path)
            _logger.info(f"WeChat Pay: 查询订单状态结果 - {reference} - {result}")
            return result
        except Exception as e:
            _logger.exception(f"WeChat Pay: 查询订单异常 - {str(e)}")
            raise ValidationError(f"查询微信支付订单失败: {str(e)}") 