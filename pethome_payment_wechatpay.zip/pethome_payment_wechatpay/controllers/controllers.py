# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import logging
from odoo.exceptions import ValidationError
import json
import traceback
import base64
from cryptography.hazmat.primitives.asymmetric.padding import PKCS1v15
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
import time
from datetime import datetime
import qrcode
from io import BytesIO

_logger = logging.getLogger(__name__)

class WeChatPay(http.Controller):

    @http.route('/payment/wechatpay/notify', csrf=False, type="http", auth='none', methods=["POST"])
    def wechatpay_notify(self, **kwargs):
        """
        接收来自微信支付的通知
        """
        _logger.info("[PetHome Payment WeChat Pay] 接收到微信支付通知")
        
        try:
            # 获取请求体
            data = request.httprequest.data
            
            # 记录请求头信息
            headers = request.httprequest.headers
            timestamp = headers.get('Wechatpay-Timestamp')
            nonce = headers.get('Wechatpay-Nonce')
            signature = headers.get('Wechatpay-Signature')
            serial_no = headers.get('Wechatpay-Serial')
            
            # 记录通知数据
            _logger.info(f"[PetHome Payment WeChat Pay] 通知数据: {data.decode('utf-8')}")
            _logger.info(f"[PetHome Payment WeChat Pay] 通知头信息: timestamp={timestamp}, nonce={nonce}, serial={serial_no}")
            
            # 查找支付提供商
            payment_provider = request.env["payment.provider"].sudo().search(
                [('code', '=', 'wechatpay')], limit=1)
                
            if not payment_provider:
                _logger.error("[PetHome Payment WeChat Pay] 未找到微信支付提供商")
                return json.dumps({
                    "code": "FAIL",
                    "message": "未找到微信支付提供商"
                })
            
            # 测试模式下跳过签名验证
            is_test_mode = payment_provider.state == 'test'
            
            # 验证通知签名 (测试模式下跳过验证)
            if not is_test_mode and not self._verify_notification(payment_provider, timestamp, nonce, signature, data, serial_no):
                _logger.error("[PetHome Payment WeChat Pay] 通知签名验证失败")
                return json.dumps({
                    "code": "FAIL",
                    "message": "签名验证失败"
                })
            
            # 解析通知数据
            notification_data = json.loads(data.decode('utf-8'))
            resource = notification_data.get('resource', {})
            
            # 测试模式下可以处理模拟通知
            if is_test_mode and not resource.get('ciphertext'):
                _logger.info("[PetHome Payment WeChat Pay] 测试模式：处理模拟通知数据")
                # 创建模拟解密后的数据
                decrypted_data = {
                    'mchid': payment_provider.wechatpay_test_mch_id or 'test_mch_id',
                    'appid': payment_provider.wechatpay_test_appid or 'test_appid',
                    'out_trade_no': notification_data.get('out_trade_no', f'test_order_{int(time.time())}'),
                    'transaction_id': f'test_transaction_id_{int(time.time())}',
                    'trade_type': 'NATIVE',
                    'trade_state': 'SUCCESS',
                    'trade_state_desc': '支付成功',
                    'success_time': datetime.now().strftime('%Y-%m-%dT%H:%M:%S+08:00'),
                    'amount': {
                        'total': 100,  # 1元人民币
                        'currency': 'CNY'
                    }
                }
            # 正常模式下解密数据
            elif 'ciphertext' in resource:
                decrypted_data = payment_provider._decrypt_resource(resource)
                _logger.info(f"[PetHome Payment WeChat Pay] 解密后数据: {decrypted_data}")
            else:
                _logger.error("[PetHome Payment WeChat Pay] 通知数据不包含加密资源")
                return json.dumps({
                    "code": "FAIL",
                    "message": "通知数据格式错误"
                })
                
            # 处理不同类型的通知
            event_type = notification_data.get('event_type', 'TRANSACTION.SUCCESS')  # 默认为支付成功事件
            
            if event_type == 'TRANSACTION.SUCCESS':
                # 支付成功通知
                out_trade_no = decrypted_data.get('out_trade_no')
                transaction_id = decrypted_data.get('transaction_id')
                
                if out_trade_no:
                    # 查找对应的交易记录
                    tx_obj = request.env['payment.transaction'].sudo()
                    tx = tx_obj.search([('reference', '=', out_trade_no), 
                                      ('provider_code', '=', 'wechatpay')], limit=1)
                    
                    if tx:
                        # 设置微信支付交易号
                        tx.provider_reference = transaction_id
                        
                        # 处理通知
                        tx._handle_notification_data('wechatpay', decrypted_data)
                        _logger.info(f"[PetHome Payment WeChat Pay] 成功处理交易 {out_trade_no} 的支付通知")
                    else:
                        _logger.warning(f"[PetHome Payment WeChat Pay] 未找到交易记录 {out_trade_no}")
                        
            elif event_type == 'REFUND.SUCCESS':
                # 退款成功通知
                out_trade_no = decrypted_data.get('out_trade_no')
                out_refund_no = decrypted_data.get('out_refund_no')
                
                _logger.info(f"[PetHome Payment WeChat Pay] 收到退款成功通知: {out_refund_no}")
                # 可以在此处理退款逻辑
                
            else:
                _logger.info(f"[PetHome Payment WeChat Pay] 收到其他类型通知: {event_type}")
            
            # 返回成功响应
            return json.dumps({
                "code": "SUCCESS",
                "message": "成功"
            })
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 处理通知异常: {str(e)}")
            _logger.error(f"[PetHome Payment WeChat Pay] 异常详情: {traceback.format_exc()}")
            
            # 即使发生异常也返回成功，避免微信重复通知
            return json.dumps({
                "code": "SUCCESS",
                "message": "成功"
            })
    
    def _verify_notification(self, provider, timestamp, nonce, signature, data, serial_no):
        """
        验证微信支付通知签名
        """
        # 测试模式下跳过验证
        if provider.state == 'test':
            _logger.info("[PetHome Payment WeChat Pay] 测试模式：跳过通知签名验证")
            return True
            
        try:
            if not all([timestamp, nonce, signature, serial_no]):
                _logger.error("[PetHome Payment WeChat Pay] 缺少验证签名所需的头信息")
                return False
                
            # 获取微信平台证书
            platform_cert = provider._get_platform_cert(serial_no)
            if not platform_cert:
                _logger.error(f"[PetHome Payment WeChat Pay] 未找到序列号为 {serial_no} 的平台证书")
                return False
                
            # 构造验签名串
            message = timestamp + "\n" + nonce + "\n" + data.decode('utf-8') + "\n"
            
            # 微信平台公钥
            try:
                public_key = serialization.load_pem_public_key(
                    platform_cert.encode('utf-8')
                )
            except Exception as e:
                _logger.exception(f"[PetHome Payment WeChat Pay] 加载平台公钥失败: {str(e)}")
                return False
            
            # Base64解码签名
            signature_bytes = base64.b64decode(signature)
            
            # 验证签名
            try:
                public_key.verify(
                    signature_bytes,
                    message.encode('utf-8'),
                    PKCS1v15(),
                    SHA256()
                )
                _logger.info("[PetHome Payment WeChat Pay] 通知签名验证成功")
                return True
            except Exception as e:
                _logger.exception(f"[PetHome Payment WeChat Pay] 验证签名失败: {str(e)}")
                return False
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 验证通知签名异常: {str(e)}")
            return False

    @http.route('/payment/wechatpay/get_qrcode', type='json', auth='public')
    def wechatpay_get_qrcode(self, provider_id, reference, amount=0, currency_id=None, **kwargs):
        """获取微信支付二维码"""
        try:
            # 检查参数
            if not provider_id or not reference:
                return {
                    'error': '缺少必要参数'
                }
                
            amount = float(amount)
            if amount <= 0:
                return {
                    'error': '金额必须大于0'
                }

            # 获取支付提供商
            provider = request.env['payment.provider'].sudo().browse(int(provider_id))
            if not provider.exists() or provider.code != 'wechatpay':
                return {
                    'error': '找不到有效的微信支付提供商'
                }
                
            # 获取货币
            currency = None
            if currency_id:
                currency = request.env['res.currency'].sudo().browse(int(currency_id))
                if not currency.exists():
                    return {
                        'error': '找不到有效的货币'
                    }
            else:
                # 使用公司货币
                currency = request.env.company.currency_id
                
            if currency.name not in ['CNY']:
                return {
                    'error': '微信支付仅支持人民币(CNY)支付'
                }
            
            # 创建微信支付二维码
            try:
                qrcode_url = provider._wechatpay_create_transaction(amount, reference)
                
                # 生成图片二维码
                qrcode_img = None
                try:
                    if qrcode_url:
                        img = qrcode.make(qrcode_url)
                        buffer = BytesIO()
                        img.save(buffer)
                        qrcode_img = base64.b64encode(buffer.getvalue()).decode('utf-8')
                except Exception as qr_error:
                    _logger.exception(f"[PetHome Payment WeChat Pay] 生成二维码图片失败: {str(qr_error)}")
                
                return {
                    'reference': reference,
                    'amount': amount,
                    'currency_name': currency.name,
                    'qrcode_url': qrcode_url,
                    'qrcode_img': qrcode_img
                }
            except Exception as e:
                _logger.exception(f"[PetHome Payment WeChat Pay] 创建支付二维码失败: {str(e)}")
                return {
                    'error': f'创建支付二维码失败: {str(e)}'
                }
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 获取支付二维码异常: {str(e)}")
            return {
                'error': f'处理请求时出错: {str(e)}'
            }
    
    @http.route('/payment/wechatpay/check_status', type='json', auth='public')
    def wechatpay_check_status(self, reference, **kwargs):
        """检查微信支付状态"""
        try:
            if not reference:
                return {
                    'error': '缺少订单编号'
                }
                
            # 查找交易记录
            tx = request.env['payment.transaction'].sudo().search([
                ('reference', '=', reference),
                ('provider_code', '=', 'wechatpay')
            ], limit=1)
            
            if not tx:
                return {
                    'error': '找不到对应的交易记录'
                }
                
            # 手动检查支付状态
            tx.action_wechatpay_check_status()
            
            # 返回最新状态
            if tx.state == 'done':
                return {
                    'done': True,
                    'message': '支付已完成'
                }
            elif tx.state == 'pending':
                return {
                    'pending': True,
                    'message': '支付处理中，请稍候'
                }
            elif tx.state == 'cancel':
                return {
                    'error': '支付已取消'
                }
            elif tx.state == 'error':
                return {
                    'error': '支付失败'
                }
            else:
                return {
                    'pending': True,
                    'message': f'当前状态: {tx.state}'
                }
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 检查支付状态异常: {str(e)}")
            return {
                'error': f'检查支付状态时出错: {str(e)}'
            }

class WeChatPayFrontend(http.Controller):
    @http.route('/payment/wechatpay/qrcode', type='http', auth='public', website=True)
    def wechatpay_qrcode(self, reference=None, **kwargs):
        _logger.info(f"[WeChatPay] 进入二维码页面 reference={reference}")
        tx = request.env['payment.transaction'].sudo().search([('reference', '=', reference)], limit=1)
        if not tx:
            _logger.warning(f"[WeChatPay] 未找到交易 reference={reference}")
            return request.render('pethome_payment_wechatpay.payment_wechatpay_qrcode', {'error': '交易不存在'})
        # 直接生成二维码图片（base64）
        qrcode_img_url = None
        qrcode_url = None
        try:
            # 获取二维码URL
            qrcode_url = tx.provider_id._wechatpay_create_transaction(tx.amount, tx.reference)
            if qrcode_url:
                img = qrcode.make(qrcode_url)
                buffer = BytesIO()
                img.save(buffer, format='PNG')
                qrcode_img_url = f"data:image/png;base64,{base64.b64encode(buffer.getvalue()).decode('utf-8')}"
        except Exception as e:
            _logger.exception(f"[WeChatPay] 生成二维码图片失败: {str(e)}")
        _logger.info(f"[WeChatPay] 渲染二维码页面 reference={reference}, tx_id={tx.id}, qrcode_img_url={'有' if qrcode_img_url else '无'}")
        return request.render('pethome_payment_wechatpay.payment_wechatpay_qrcode', {
            'reference': tx.reference,
            'qrcode_img_url': qrcode_img_url,
            'amount': tx.amount,
            'currency': tx.currency_id.name,
        })

    @http.route('/payment/wechatpay/status', type='http', auth='public', website=True)
    def wechatpay_status(self, reference=None, **kwargs):
        tx = request.env['payment.transaction'].sudo().search([('reference', '=', reference)], limit=1)
        if not tx:
            return request.render('pethome_payment_wechatpay.payment_wechatpay_status', {'error': '交易不存在'})
        return request.render('pethome_payment_wechatpay.payment_wechatpay_status', {
            'tx': tx,
            'reference': tx.reference,
            'amount': tx.amount,
            'currency': tx.currency_id.name,
        })

class WeChatPayShopController(http.Controller):
    @http.route('/shop/payment/validate', type='http', auth='public', website=True, sitemap=False)
    def payment_validate(self, **post):
        tx = request.env['payment.transaction'].sudo().browse(request.session.get('sale_last_payment_tx'))
        if tx and tx.provider_code == 'wechatpay' and tx.state != 'done':
            return request.redirect('/shop/payment')
        return super(WeChatPayShopController, self).payment_validate(**post)