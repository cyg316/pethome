# -*- coding: utf-8 -*-
import logging
import pprint
import json
import werkzeug
from odoo import http
from odoo.http import request
from odoo.addons.payment.controllers.post_processing import PaymentPostProcessing

_logger = logging.getLogger(__name__)

class WeChatPayPostProcessing(PaymentPostProcessing):

    @http.route('/payment/wechatpay/process', type='http', auth='public', save_session=False)
    def wechatpay_process_payment(self, **post):
        """
        创建微信支付交易并重定向到二维码支付页面
        """
        # 获取请求参数
        reference = post.get('reference')
        provider_id = post.get('provider_id')
        access_token = post.get('access_token')
        
        if not reference or not provider_id:
            return werkzeug.utils.redirect('/payment/status')
        
        # 查找交易记录
        tx_sudo = request.env['payment.transaction'].sudo().search([
            ('reference', '=', reference),
            ('provider_id', '=', int(provider_id))
        ], limit=1)
        
        if not tx_sudo:
            _logger.warning("找不到要处理的交易: %s", reference)
            return werkzeug.utils.redirect('/payment/status')
            
        # 重定向到微信支付二维码页面
        return werkzeug.utils.redirect(
            f'/my/wechatpay/payment/{tx_sudo.id}?access_token={access_token}'
        )
    
    @http.route('/payment/wechatpay/return', type='http', auth='public', csrf=False, save_session=False)
    def wechatpay_return_from_checkout(self, **data):
        """用户从支付页面返回时的处理"""
        # 提取参数
        reference = data.get('reference')
        if not reference:
            return werkzeug.utils.redirect('/payment/status')
            
        # 查找交易记录
        tx_sudo = request.env['payment.transaction'].sudo().search([
            ('reference', '=', reference),
            ('provider_code', '=', 'wechatpay')
        ], limit=1)
        
        if not tx_sudo:
            return werkzeug.utils.redirect('/payment/status')
            
        # 手动检查支付状态
        tx_sudo.action_wechatpay_check_status()
        
        # 将交易ID添加到会话中，以便结账完成页面可以显示
        self._add_transaction_to_session(tx_sudo.id)
        
        # 根据支付状态重定向
        if tx_sudo.state == 'done':
            # 支付完成，重定向到成功页面
            return werkzeug.utils.redirect(tx_sudo.landing_route or '/payment/status')
        else:
            # 支付仍在处理中，或失败，重定向到状态页面
            return werkzeug.utils.redirect(f'/my/wechatpay/payment_status/{tx_sudo.id}')
    
    @http.route('/payment/wechatpay/simulate', type='http', auth='public', csrf=True, methods=['POST'])
    def wechatpay_simulate_payment(self, reference, **kwargs):
        """
        仅测试模式下：模拟支付完成
        用于开发和测试环境
        """
        # 检查是否处于测试模式
        if request.env['ir.config_parameter'].sudo().get_param('pethome_payment_wechatpay.test_mode', 'False') != 'True':
            return werkzeug.utils.redirect('/payment/status')
            
        # 查找交易记录
        tx_sudo = request.env['payment.transaction'].sudo().search([
            ('reference', '=', reference),
            ('provider_code', '=', 'wechatpay')
        ], limit=1)
        
        if not tx_sudo:
            return werkzeug.utils.redirect('/payment/status')
            
        # 模拟支付完成
        tx_sudo._set_done()
        tx_sudo.provider_reference = f'test_txn_{reference}'
        
        # 添加到会话
        self._add_transaction_to_session(tx_sudo.id)
        
        # 重定向到成功页面
        return werkzeug.utils.redirect(tx_sudo.landing_route or '/payment/status')
