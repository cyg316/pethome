import qrcode
import base64
import io
import logging

_logger = logging.getLogger(__name__)

class WechatPayUtils:
    """
    微信支付工具类
    """
    @staticmethod
    def generate_qrcode(data, box_size=6, border=4):
        """
        根据提供的数据生成二维码图像
        
        :param data: 要编码的数据 (通常是URL或支付码)
        :param box_size: 二维码中每个框的像素大小
        :param border: 二维码周围的边框大小 (以框为单位)
        :return: 包含二维码的base64编码图像
        """
        try:
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=box_size,
                border=border,
            )
            qr.add_data(data)
            qr.make(fit=True)
            
            img = qr.make_image(fill_color="black", back_color="white")
            
            buffered = io.BytesIO()
            img.save(buffered, format="PNG")
            img_str = base64.b64encode(buffered.getvalue()).decode()
            
            return img_str
        except Exception as e:
            _logger.error(f"二维码生成失败: {str(e)}")
            return None 