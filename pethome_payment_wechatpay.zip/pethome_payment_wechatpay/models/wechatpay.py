# -*- coding: utf-8 -*-

import logging
import requests
import json
import time
import uuid
import base64
from datetime import datetime
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from odoo.addons.payment import utils as payment_utils
from .utils import WechatPayUtils

_logger = logging.getLogger(__name__)

# 检查依赖是否已安装
DEPENDENCIES_INSTALLED = True
try:
    from cryptography.hazmat.primitives.asymmetric import padding, rsa, utils
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.exceptions import InvalidSignature
except ImportError as e:
    DEPENDENCIES_INSTALLED = False
    _logger.warning(f"WeChat Pay 依赖库缺失: {e.name}。请安装完整依赖: pip install pycryptodome requests cryptography")

try:
    import qrcode
    from PIL import Image
    from io import BytesIO
    QR_DEPENDENCIES_INSTALLED = True
except ImportError as e:
    QR_DEPENDENCIES_INSTALLED = False
    _logger.warning(f"WeChat Pay 二维码依赖库缺失: {e.name}。请安装完整依赖: pip install qrcode Pillow")

# 微信支付类型
class WeChatPayType:
    NATIVE = "NATIVE"
    JSAPI = "JSAPI"
    APP = "APP"
    H5 = "H5"
    MINIPROG = "MINIPROGRAM"
    
# 支持的货币
SUPPORTED_CURRENCIES = ['CNY']

class WeChatPayProvider(models.Model):
    _inherit = 'payment.provider'
    
    code = fields.Selection(
        selection_add=[("wechatpay", "WeChat Pay")], 
        ondelete={"wechatpay": "set default"}
    )
    
    # 微信支付基本配置
    wechatpay_appid = fields.Char("AppID", help="微信支付 AppID")
    wechatpay_mch_id = fields.Char("商户号", help="微信支付商户号")
    wechatpay_api_key = fields.Char("API密钥", help="微信支付 API V3密钥")
    wechatpay_serial_no = fields.Char("证书序列号", help="商户API证书序列号")
    wechatpay_private_key = fields.Text("商户私钥", help="商户API私钥 (apiclient_key.pem)")
    wechatpay_cert = fields.Text("商户证书", help="商户API证书 (apiclient_cert.pem)")
    
    # 平台证书缓存字段（存储从微信支付平台获取的证书）
    wechatpay_platform_certs = fields.Text("平台证书缓存", help="微信支付平台证书缓存", copy=False)
    
    def _get_default_payment_method_id(self):
        self.ensure_one()
        if self.code != 'wechatpay':
            return super()._get_default_payment_method_id()
        return self.env.ref('pethome_payment_wechatpay.payment_method_wechatpay').id
            
    def _get_wechatpay_api_url(self):
        """获取微信支付API URL"""
        self.ensure_one()
        
        # 生产环境URL
        if self.state == 'enabled':
            return "https://api.mch.weixin.qq.com"
        # 测试环境URL (实际与生产相同，但可以用于区分)
        return "https://api.mch.weixin.qq.com"
    
    def _get_wechatpay_credentials(self):
        """获取微信支付凭证"""
        self.ensure_one()
        
        return {
            'api_base': self._get_wechatpay_api_url(),
            'appid': self.wechatpay_appid,
            'mchid': self.wechatpay_mch_id,
            'api_key': self.wechatpay_api_key,
            'serial_no': self.wechatpay_serial_no,
        }
    
    def _get_private_key(self):
        """获取商户API私钥对象"""
        self.ensure_one()
        
        try:
            # 获取私钥数据
            private_key_data = self.wechatpay_private_key
                
            if not private_key_data:
                _logger.error(f"[PetHome Payment WeChat Pay] 未配置商户私钥")
                return None
                
            # 加载私钥对象
            private_key = serialization.load_pem_private_key(
                private_key_data.encode('utf-8'),
                password=None
            )
            
            return private_key
            
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 加载私钥失败: {str(e)}")
            return None
    
    def _get_supported_currencies(self):
        """返回支持的货币"""
        supported_currencies = super()._get_supported_currencies()
        if self.code == "wechatpay":
            supported_currencies = supported_currencies.filtered(
                lambda c: c.name in SUPPORTED_CURRENCIES
            )
        return supported_currencies
        
    def _generate_wechatpay_signature(self, http_method, url_path, body=''):
        """生成微信支付签名"""
        # 测试模式模拟签名
        if self.state == 'test':
            return "TEST_MODE_SIGNATURE", str(int(time.time())), str(uuid.uuid4())
            
        # 生成随机数
        nonce_str = str(uuid.uuid4())
        # 获取当前时间戳
        timestamp = str(int(time.time()))
        
        # 构建签名信息
        url_parts = url_path.split('?')
        canonical_url = url_parts[0]
        
        # 构造签名字符串
        sign_str = http_method + "\n" + canonical_url + "\n" + timestamp + "\n" + nonce_str + "\n"
        if body:
            sign_str += body
        sign_str += "\n"
        
        # 获取私钥并签名
        private_key = self._get_private_key()
        if not private_key:
            raise ValidationError(_("无法加载微信支付私钥"))
            
        # 签名
        signature = private_key.sign(
            sign_str.encode('utf-8'),
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        
        # Base64编码签名
        signature_base64 = base64.b64encode(signature).decode('utf-8')
        
        return signature_base64, timestamp, nonce_str
        
    def _get_wechatpay_authorization(self, http_method, url_path, body=''):
        """获取微信支付请求授权头"""
        # 获取签名
        signature, timestamp, nonce_str = self._generate_wechatpay_signature(http_method, url_path, body)
        creds = self._get_wechatpay_credentials()
        
        # 构建授权头
        return (
            f'WECHATPAY2-SHA256-RSA2048 mchid="{creds["mchid"]}",'
            f'nonce_str="{nonce_str}",'
            f'signature="{signature}",'
            f'timestamp="{timestamp}",'
            f'serial_no="{creds["serial_no"]}"'
        )
        
    def _make_wechatpay_request(self, http_method, url_path, data=None):
        """发送API请求到微信支付"""
        self.ensure_one()
        creds = self._get_wechatpay_credentials()
        url = creds['api_base'] + url_path
        
        # 测试模式返回模拟数据
        if self.state == 'test':
            _logger.info(f"[PetHome Payment WeChat Pay] 测试模式: 模拟请求 {http_method} {url_path}")
            return self._get_wechatpay_test_response(http_method, url_path, data)
            
        body = ''
        if data:
            body = json.dumps(data)
            
        # 构建授权头
        auth_header = self._get_wechatpay_authorization(http_method, url_path, body)
        
        headers = {
            'Authorization': auth_header,
            'User-Agent': 'Odoo WeChat Pay',
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        }
        
        try:
            if http_method == 'GET':
                response = requests.get(url, headers=headers, timeout=30)
            elif http_method == 'POST':
                response = requests.post(url, headers=headers, data=body, timeout=30)
            else:
                raise ValidationError(_("不支持的HTTP方法: %s") % http_method)
                
            response.raise_for_status()
            result = response.json()
            
            return result
        except requests.RequestException as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 请求异常: {str(e)}")
            raise ValidationError(_("微信支付API请求失败: %s") % str(e))
            
    def _get_wechatpay_test_response(self, http_method, url_path, data=None):
        """获取测试模式下的模拟响应"""
        creds = self._get_wechatpay_credentials()
        
        # 模拟Native下单响应
        if url_path.endswith('/v3/pay/transactions/native'):
            return {
                'code_url': f'weixin://wxpay/bizpayurl?pr=test_{str(uuid.uuid4())[:8]}',
                'prepay_id': f'test_prepay_id_{str(uuid.uuid4())[:8]}'
            }
        # 模拟查询订单响应
        elif '/v3/pay/transactions/out-trade-no/' in url_path:
            return {
                'mchid': creds['mchid'],
                'appid': creds['appid'],
                'out_trade_no': data.get('out_trade_no') if data else url_path.split('/')[-1].split('?')[0],
                'transaction_id': f'test_transaction_id_{int(time.time())}',
                'trade_type': 'NATIVE',
                'trade_state': 'SUCCESS',
                'trade_state_desc': '支付成功',
                'success_time': datetime.now().strftime('%Y-%m-%dT%H:%M:%S+08:00'),
                'amount': {
                    'total': data.get('amount', {}).get('total', 100) if data else 100,
                    'currency': 'CNY'
                }
            }
        # 模拟关闭订单响应
        elif url_path.endswith('/close'):
            return {}
        # 默认响应
        else:
            return {'status': 'SUCCESS'}
            
    def _wechatpay_create_transaction(self, amount, reference):
        """创建微信支付交易"""
        self.ensure_one()
        creds = self._get_wechatpay_credentials()
        
        # 测试模式返回模拟二维码
        if self.state == 'test':
            _logger.info(f"[PetHome Payment WeChat Pay] 测试模式: 模拟创建Native支付 {reference}")
            result = {
                'code_url': f'weixin://wxpay/bizpayurl?pr=test_{str(uuid.uuid4())[:8]}',
                'prepay_id': f'test_prepay_id_{str(uuid.uuid4())[:8]}'
            }
            return result
        
        # 准备通知URL
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        notify_url = f"{base_url}/payment/wechatpay/notify"
        
        # 设置请求数据
        company_name = self.env.company.name or "订单"
        description = f"{company_name} - {reference}"
        
        data = {
            'appid': creds['appid'],
            'mchid': creds['mchid'],
            'description': description,
            'out_trade_no': reference,
            'notify_url': notify_url,
            'amount': {
                'total': int(amount * 100),  # 金额单位为分
                'currency': 'CNY'
            }
        }
        
        # 发送请求
        result = self._make_wechatpay_request('POST', '/v3/pay/transactions/native', data)
        
        if 'code_url' in result:
            return result
            
        _logger.error(f"[PetHome Payment WeChat Pay] 创建支付交易失败: {result}")
        return None

    def _get_redirect_url(self, tx_type, **kwargs):
        """添加微信支付的重定向URL支持"""
        if self.code == 'wechatpay':
            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            return f"{base_url}/payment/wechatpay/redirect?reference={kwargs.get('reference')}"
        return super()._get_redirect_url(tx_type, **kwargs)

    def _check_wechatpay_status(self, tx):
        """查询微信支付订单状态"""
        self.ensure_one()
        
        if not tx or tx.provider_code != 'wechatpay':
            return False
        
        # 测试模式模拟支付成功
        if self.state == 'test':
            _logger.info(f"[PetHome Payment WeChat Pay] 测试模式: 模拟查询订单状态 {tx.reference}")
            tx._set_done()
            tx.provider_reference = f'test_transaction_id_{int(time.time())}'
            return True
            
        # 构建查询URL
        url_path = f"/v3/pay/transactions/out-trade-no/{tx.reference}?mchid={self.wechatpay_mch_id}"
        
        try:
            # 发送查询请求
            result = self._make_wechatpay_request('GET', url_path)
            
            if not result:
                _logger.warning(f"[PetHome Payment WeChat Pay] 查询订单返回空结果: {tx.reference}")
                return False
                
            # 提取交易状态
            trade_state = result.get('trade_state')
            transaction_id = result.get('transaction_id')
            
            _logger.info(f"[PetHome Payment WeChat Pay] 订单 {tx.reference} 状态: {trade_state}")
            
            # 更新交易类型
            if 'trade_type' in result:
                tx.wechatpay_trade_type = result['trade_type']
            
            # 处理不同状态
            if trade_state == 'SUCCESS':
                if tx.state not in ['done', 'authorized']:
                    tx._set_done()
                    tx.provider_reference = transaction_id
                return True
            elif trade_state == 'REFUND':
                # 退款状态，可能需要特殊处理
                _logger.info(f"[PetHome Payment WeChat Pay] 订单 {tx.reference} 已退款")
                return True
            elif trade_state in ['NOTPAY', 'USERPAYING']:
                # 未支付或用户支付中，保持pending状态
                if tx.state != 'pending':
                    tx._set_pending()
                return False
            elif trade_state == 'CLOSED':
                # 已关闭
                if tx.state != 'cancel':
                    tx._set_canceled()
                return False
            elif trade_state in ['PAYERROR', 'REVOKED']:
                # 支付失败或已撤销
                if tx.state != 'error':
                    tx._set_error(f"微信支付失败: {result.get('trade_state_desc')}")
                return False
            else:
                # 其他未知状态
                _logger.warning(f"[PetHome Payment WeChat Pay] 未知订单状态 {trade_state}: {tx.reference}")
                return False
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 查询订单状态异常: {str(e)}")
            return False

class WeChatPayTransaction(models.Model):
    _inherit = 'payment.transaction'

    wechatpay_trade_type = fields.Char('交易类型', help='微信支付交易类型，如NATIVE、JSAPI等')
    wechatpay_prepay_id = fields.Char('预支付ID', help='微信支付预支付交易ID')
    wechatpay_qrcode_url = fields.Char('二维码URL', help='微信支付二维码链接')
    wechatpay_qrcode = fields.Binary('二维码图片', attachment=True, readonly=True)
    wechatpay_txn_type = fields.Char('交易类型代码', help='微信支付内部交易类型')
    
    # 获取微信支付状态按钮
    def action_wechatpay_check_status(self):
        """手动查询微信支付状态"""
        self.ensure_one()
        if self.provider_code != 'wechatpay':
            return
            
        try:
            # 调用查询订单接口
            self.provider_id._check_wechatpay_status(self)
            return {
                'type': 'ir.actions.client',
                'tag': 'reload',
            }
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 查询支付状态异常: {str(e)}")
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _("查询支付状态失败"),
                    'message': str(e),
                    'sticky': False,
                    'type': 'danger',
                }
            }

    def _get_specific_rendering_values(self, processing_values):
        """返回微信支付特定的渲染值"""
        res = super()._get_specific_rendering_values(processing_values)
        if self.provider_id.code != 'wechatpay':
            return res
            
        # 设置重定向URL，让页面能够通过重定向显示二维码页面
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        reference = processing_values.get('reference')
        
        res.update({
            'provider_code': 'wechatpay',
            'redirect_url': f"{base_url}/payment/wechatpay/redirect?reference={reference}"
        })
        
        _logger.info(f"[PetHome Payment WeChat Pay] 生成支付渲染值: {res}")
        return res 