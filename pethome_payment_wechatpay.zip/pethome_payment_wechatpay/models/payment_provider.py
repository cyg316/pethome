# -*- coding: utf-8 -*-

SUPPORTED_CURRENCIES = ['CNY']
DEFAULT_PAYMENT_METHODS_CODES = ['wechatpay']

import logging
import requests
import json
import time
import uuid
import hashlib
import base64
from datetime import datetime
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError

_logger = logging.getLogger(__name__)

# 检查依赖是否已安装
DEPENDENCIES_INSTALLED = True
try:
    from cryptography.hazmat.primitives.asymmetric import padding, rsa, utils
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.exceptions import InvalidSignature
except ImportError as e:
    DEPENDENCIES_INSTALLED = False
    _logger.warning(f"WeChat Pay 依赖库缺失: {e.name}。请安装完整依赖: pip install pycryptodome requests cryptography")

class WeChatPayAPI:
    """微信支付API封装"""
    
    def __init__(self, provider):
        self.provider = provider
        
        if provider.state == 'test':
            self.is_test_mode = True
            self.appid = provider.wechatpay_appid or ""
            self.mchid = provider.wechatpay_mch_id or ""
            self.api_key = provider.wechatpay_api_key or ""
            self.serial_no = provider.wechatpay_serial_no or ""
        else:
            self.is_test_mode = False
            self.appid = provider.wechatpay_appid or ""
            self.mchid = provider.wechatpay_mch_id or ""
            self.api_key = provider.wechatpay_api_key or ""
            self.serial_no = provider.wechatpay_serial_no or ""
            
        # API端点
        self.api_base = "https://api.mch.weixin.qq.com"
        
    def _get_private_key(self):
        """获取私钥对象"""
        return self.provider._get_private_key(self.is_test_mode)
        
    def _generate_signature(self, http_method, url_path, body=''):
        """生成签名"""
        # 测试模式模拟签名
        if self.is_test_mode:
            return "TEST_MODE_SIGNATURE", str(int(time.time())), str(uuid.uuid4())
            
        # 生成随机数
        nonce_str = str(uuid.uuid4())
        # 获取当前时间戳
        timestamp = str(int(time.time()))
        
        # 构建签名信息
        url_parts = url_path.split('?')
        canonical_url = url_parts[0]
        
        # 构造签名字符串
        sign_str = http_method + "\n" + canonical_url + "\n" + timestamp + "\n" + nonce_str + "\n"
        if body:
            sign_str += body
        sign_str += "\n"
        
        # 获取私钥并签名
        private_key = self._get_private_key()
        if not private_key:
            raise ValidationError(_("无法加载微信支付私钥"))
            
        # 签名
        signature = private_key.sign(
            sign_str.encode('utf-8'),
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        
        # Base64编码签名
        signature_base64 = base64.b64encode(signature).decode('utf-8')
        
        return signature_base64, timestamp, nonce_str
        
    def _build_authorization_header(self, http_method, url_path, body=''):
        """构建授权头"""
        # 获取签名
        signature, timestamp, nonce_str = self._generate_signature(http_method, url_path, body)
        
        # 构建授权头
        return (
            f'WECHATPAY2-SHA256-RSA2048 mchid="{self.mchid}",'
            f'nonce_str="{nonce_str}",'
            f'signature="{signature}",'
            f'timestamp="{timestamp}",'
            f'serial_no="{self.serial_no}"'
        )
        
    def _send_request(self, http_method, url_path, data=None):
        """发送API请求"""
        url = self.api_base + url_path
        
        # 测试模式返回模拟数据
        if self.is_test_mode:
            _logger.info(f"[PetHome Payment WeChat Pay] 测试模式: 模拟请求 {http_method} {url_path}")
            return self._get_test_mode_response(http_method, url_path, data)
            
        body = ''
        if data:
            body = json.dumps(data)
            
        # 构建授权头
        auth_header = self._build_authorization_header(http_method, url_path, body)
        
        headers = {
            'Authorization': auth_header,
            'User-Agent': 'Odoo WeChat Pay',
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        }
        
        try:
            if http_method == 'GET':
                response = requests.get(url, headers=headers, timeout=30)
            elif http_method == 'POST':
                response = requests.post(url, headers=headers, data=body, timeout=30)
            else:
                raise ValidationError(_("不支持的HTTP方法: %s") % http_method)
                
            response.raise_for_status()
            result = response.json()
            
            return result
        except requests.RequestException as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 请求异常: {str(e)}")
            raise ValidationError(_("微信支付API请求失败: %s") % str(e))
            
    def _get_test_mode_response(self, http_method, url_path, data=None):
        """获取测试模式下的模拟响应"""
        # 模拟Native下单响应
        if url_path.endswith('/v3/pay/transactions/native'):
            return {
                'code_url': f'weixin://wxpay/bizpayurl?pr=test_{str(uuid.uuid4())[:8]}',
            }
        # 模拟查询订单响应
        elif '/v3/pay/transactions/out-trade-no/' in url_path:
            return {
                'mchid': self.mchid,
                'appid': self.appid,
                'out_trade_no': data.get('out_trade_no') if data else url_path.split('/')[-1].split('?')[0],
                'transaction_id': f'test_transaction_id_{int(time.time())}',
                'trade_type': 'NATIVE',
                'trade_state': 'SUCCESS',
                'trade_state_desc': '支付成功',
                'success_time': datetime.now().strftime('%Y-%m-%dT%H:%M:%S+08:00'),
                'amount': {
                    'total': data.get('amount', {}).get('total', 100) if data else 100,
                    'currency': 'CNY'
                }
            }
        # 模拟关闭订单响应
        elif url_path.endswith('/close'):
            return {}
        # 默认响应
        else:
            return {'status': 'SUCCESS'}
        
    def native_pay(self, out_trade_no, amount, description, notify_url=None):
        """发起Native支付，返回二维码URL"""
        try:
            # 测试模式返回模拟二维码
            if self.is_test_mode:
                _logger.info(f"[PetHome Payment WeChat Pay] 测试模式: 模拟创建Native支付 {out_trade_no}")
                return f'weixin://wxpay/bizpayurl?pr=test_{str(uuid.uuid4())[:8]}'
            
            # 设置请求数据
            data = {
                'appid': self.appid,
                'mchid': self.mchid,
                'description': description,
                'out_trade_no': out_trade_no,
                'notify_url': notify_url,
                'amount': {
                    'total': int(amount * 100),  # 金额单位为分
                    'currency': 'CNY'
                }
            }
            
            # 发送请求
            result = self._send_request('POST', '/v3/pay/transactions/native', data)
            
            if 'code_url' in result:
                return result['code_url']
            else:
                _logger.error(f"[PetHome Payment WeChat Pay] 创建Native支付失败: {result}")
                return None
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 创建Native支付异常: {str(e)}")
            return None
            
    def query_order(self, out_trade_no):
        """查询订单状态"""
        try:
            # 构建查询参数
            query_params = f"?mchid={self.mchid}"
            url_path = f"/v3/pay/transactions/out-trade-no/{out_trade_no}{query_params}"
            
            # 发送请求
            result = self._send_request('GET', url_path)
            
            return result
            
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 查询订单异常: {str(e)}")
            return None
            
    def close_order(self, out_trade_no):
        """关闭订单"""
        try:
            # 构建请求数据
            data = {
                'mchid': self.mchid
            }
            
            # 构建URL
            url_path = f"/v3/pay/transactions/out-trade-no/{out_trade_no}/close"
            
            # 发送请求
            result = self._send_request('POST', url_path, data)
            
            # 返回是否成功
            if isinstance(result, dict) and result.get('status') == 'FAILED':
                return False
            return True
            
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 关闭订单异常: {str(e)}")
            return False
            
    def refund(self, out_refund_no, out_trade_no, amount, reason=None):
        """申请退款"""
        try:
            # 构建请求数据
            data = {
                'out_refund_no': out_refund_no,
                'out_trade_no': out_trade_no,
                'reason': reason or '商户退款',
                'amount': {
                    'refund': int(amount * 100),  # 退款金额，单位为分
                    'total': int(amount * 100),   # 原订单金额，单位为分
                    'currency': 'CNY'
                }
            }
            
            # 发送请求
            result = self._send_request('POST', '/v3/refund/domestic/refunds', data)
            
            if 'status' in result and result['status'] == 'SUCCESS':
                return True, result
            else:
                return False, result
                
        except requests.RequestException as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 申请退款请求异常: {str(e)}")
            return False, {'error': str(e)}
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 申请退款异常: {str(e)}")
            return False, {'error': str(e)}


class PaymentProvider(models.Model):
    _inherit = 'payment.provider'
    
    code = fields.Selection(
        selection_add=[("wechatpay", "WeChat Pay")], 
        ondelete={"wechatpay": "set default"}
    )
    
    wechatpay_appid = fields.Char("AppID", help="微信支付 AppID")
    wechatpay_mch_id = fields.Char("商户号", help="微信支付商户号")
    wechatpay_api_key = fields.Char("API密钥", help="微信支付 API V3密钥")
    wechatpay_serial_no = fields.Char("证书序列号", help="商户API证书序列号")
    wechatpay_private_key = fields.Binary("商户私钥", help="商户API私钥 (apiclient_key.pem)")
    wechatpay_cert = fields.Binary("商户证书", help="商户API证书 (apiclient_cert.pem)")
    
    # 平台证书缓存字段（存储从微信支付平台获取的证书）
    wechatpay_platform_certs = fields.Text("平台证书缓存", help="微信支付平台证书缓存", copy=False)
    
    @api.model
    def _register_payment_methods(self):
        """注册支付方法（仅限微信支付方法）"""
        # 只创建或更新微信支付提供商
        provider = self.sudo().search([('code', '=', 'wechatpay')], limit=1)
        if not provider:
            values = {
                'name': 'WeChat Pay',
                'code': 'wechatpay',
                'company_id': self.env.ref('base.main_company').id,
                'state': 'disabled',
            }
            redirect_form = self.env.ref('pethome_payment_wechatpay.wechatpay_redirect_form', raise_if_not_found=False)
            if redirect_form:
                values['redirect_form_view_id'] = redirect_form.id
            
            provider = self.sudo().create(values)
            _logger.info(f"已创建 WeChat Pay 支付提供商 (ID: {provider.id})")
        else:
            _logger.info(f"已找到 WeChat Pay 支付提供商 (ID: {provider.id})")
        
        # 激活微信支付方法
        self._activate_payment_methods()
        
        return True
    
    def _get_wechatpay_api(self):
        """获取微信支付API"""
        if not DEPENDENCIES_INSTALLED:
            _logger.warning(
                "WeChat Pay 依赖库未安装。"
                "请安装必要的依赖: pip install pycryptodome requests cryptography"
            )
        
        return WeChatPayAPI(self)
    
    def _get_private_key(self, test_mode=False):
        """获取商户API私钥对象"""
        try:
            # 获取私钥数据
            private_key_data = self.wechatpay_private_key
                
            if not private_key_data:
                _logger.error(f"[PetHome Payment WeChat Pay] 未配置商户私钥")
                return None
                
            # 解码Base64编码的私钥数据
            private_key_pem = base64.b64decode(private_key_data).decode('utf-8')
            
            # 加载私钥对象
            private_key = serialization.load_pem_private_key(
                private_key_pem.encode('utf-8'),
                password=None
            )
            
            return private_key
            
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 加载私钥失败: {str(e)}")
            return None
    
    def _get_platform_cert(self, serial_no):
        """获取微信支付平台证书"""
        try:
            # 测试模式下返回测试证书
            if self.state == 'test':
                _logger.info(f"[PetHome Payment WeChat Pay] 测试模式：使用模拟平台证书")
                # 返回模拟证书数据
                return "TEST_MODE_CERTIFICATE"
                
            # 尝试从缓存获取证书
            certs_cache = {}
            if self.wechatpay_platform_certs:
                certs_cache = json.loads(self.wechatpay_platform_certs)
                
            # 如果找到缓存的证书，直接返回
            if serial_no in certs_cache:
                return certs_cache[serial_no]
                
            # 如果未找到缓存的证书，返回None
            _logger.warning(f"[PetHome Payment WeChat Pay] 未找到序列号为 {serial_no} 的平台证书")
            return None
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 获取平台证书异常: {str(e)}")
            return None
    
    def _decrypt_resource(self, resource):
        """解密微信支付通知资源数据"""
        try:
            # 测试模式下使用模拟数据
            if self.state == 'test':
                _logger.info(f"[PetHome Payment WeChat Pay] 测试模式：使用模拟解密数据")
                # 返回模拟解密后的数据
                return {
                    'mchid': self.wechatpay_mch_id or 'test_mch_id',
                    'appid': self.wechatpay_appid or 'test_appid',
                    'out_trade_no': resource.get('out_trade_no', f'test_order_{int(time.time())}'),
                    'transaction_id': f'test_transaction_id_{int(time.time())}',
                    'trade_type': 'NATIVE',
                    'trade_state': 'SUCCESS',
                    'trade_state_desc': '支付成功',
                    'success_time': datetime.now().strftime('%Y-%m-%dT%H:%M:%S+08:00'),
                    'amount': {
                        'total': 100,  # 1元人民币
                        'currency': 'CNY'
                    }
                }
            
            # 获取加密信息
            algorithm = resource.get('algorithm')
            ciphertext = resource.get('ciphertext')
            associated_data = resource.get('associated_data', '')
            nonce = resource.get('nonce')
            
            if algorithm != 'AEAD_AES_256_GCM':
                _logger.error(f"[PetHome Payment WeChat Pay] 不支持的加密算法: {algorithm}")
                return {}
                
            # 获取API密钥
            api_key = self.wechatpay_api_key
            if not api_key:
                _logger.error("[PetHome Payment WeChat Pay] 未配置API密钥")
                return {}
                
            # 解密
            key_bytes = api_key.encode('utf-8')
            nonce_bytes = nonce.encode('utf-8')
            ad_bytes = associated_data.encode('utf-8') if associated_data else b''
            ciphertext_bytes = base64.b64decode(ciphertext)
            
            aes_gcm = AESGCM(key_bytes)
            plaintext_bytes = aes_gcm.decrypt(nonce_bytes, ciphertext_bytes, ad_bytes)
            
            # 解析JSON
            plaintext = plaintext_bytes.decode('utf-8')
            result = json.loads(plaintext)
            
            return result
            
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 解密资源数据异常: {str(e)}")
            return {}
    
    def _wechatpay_create_transaction(self, amount, reference):
        """创建微信支付交易并获取支付二维码URL"""
        try:
            if amount <= 0:
                raise UserError(_("支付金额必须大于0"))
                
            # 获取微信支付API
            wechatpay_api = self._get_wechatpay_api()
            
            # 设置异步通知URL
            cfg_obj = self.env["ir.config_parameter"].sudo()
            base_url = cfg_obj.get_param("web.base.url")
            notify_url = f"{base_url}/payment/wechatpay/notify"
            
            # 发起Native支付
            code_url = wechatpay_api.native_pay(
                out_trade_no=reference,
                amount=amount,
                description=f"订单 {reference}",
                notify_url=notify_url
            )
            
            return code_url
            
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 创建支付交易异常: {str(e)}")
            raise UserError(_("创建微信支付交易失败: %s", str(e)))

    def _get_supported_currencies(self):
        """返回支持的货币"""
        supported_currencies = super()._get_supported_currencies()
        if self.code == "wechatpay":
            supported_currencies = supported_currencies.filtered(
                lambda c: c.name in SUPPORTED_CURRENCIES
            )
        return supported_currencies

    def _get_default_payment_method_codes(self):
        """返回默认支付方式代码"""
        default_codes = super()._get_default_payment_method_codes()
        if self.code != "wechatpay":
            return default_codes
        return DEFAULT_PAYMENT_METHODS_CODES

    @api.model
    def _get_compatible_payment_methods(self):
        """获取兼容的支付方式"""
        compatible_methods = super()._get_compatible_payment_methods()
        if self.code == 'wechatpay':
            # 添加WeChat Pay支付方法
            wechatpay_method = self.env.ref('pethome_payment_wechatpay.payment_method_wechatpay', raise_if_not_found=False)
            if wechatpay_method and wechatpay_method.id not in compatible_methods.ids:
                compatible_methods |= wechatpay_method
                _logger.info(f"已添加 WeChat Pay 支付方法 (ID: {wechatpay_method.id}) 到兼容方法列表")
        return compatible_methods
        
    @api.model
    def _activate_payment_methods(self):
        """激活支付方法（仅限微信支付方法）"""
        # 只处理微信支付相关的方法，避免影响其他支付插件
        wechatpay_methods = self.env['payment.method'].search([('code', '=', 'wechatpay')])
        if wechatpay_methods:
            wechatpay_methods.write({'active': True})
            _logger.info(f"已激活 {len(wechatpay_methods)} 个 WeChat Pay 支付方法")
        
        # 确保方法关联到提供商，但只处理微信支付提供商
        wechatpay_provider = self.search([('code', '=', 'wechatpay')], limit=1)
        if wechatpay_provider and wechatpay_methods:
            for method in wechatpay_methods:
                if method.id not in wechatpay_provider.payment_method_ids.ids:
                    wechatpay_provider.write({
                        'payment_method_ids': [(4, method.id)]
                    })
                    _logger.info(f"已将支付方法 '{method.name}' 关联到提供商 '{wechatpay_provider.name}'")
        
        return True

    def write(self, vals):
        """重写write方法，确保在状态变更后激活支付方法（仅限微信支付提供商）"""
        result = super().write(vals)
        # 只处理微信支付提供商的状态变更
        if 'state' in vals and vals['state'] in ['enabled', 'test'] and self.filtered(lambda p: p.code == 'wechatpay'):
            self._activate_payment_methods()
        return result