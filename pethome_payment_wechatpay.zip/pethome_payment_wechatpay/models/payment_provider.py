# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError
import logging
import json
import time
import hmac
import hashlib
import base64
import uuid
import requests
from datetime import datetime
import urllib.parse
import os
import traceback
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric.padding import PKCS1v15
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from ..const import WECHATPAY_API_URLS, SUPPORTED_CURRENCIES, DEFAULT_PAYMENT_METHODS_CODES, TEST_MODE_RESPONSES

_logger = logging.getLogger(__name__)

# 检查是否安装了必要的依赖库
DEPENDENCIES_INSTALLED = True
try:
    import requests
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except ImportError as e:
    DEPENDENCIES_INSTALLED = False
    _logger.warning(f"WeChat Pay 依赖库缺失: {e.name}。请安装完整依赖: pip install pycryptodome requests cryptography")


class WeChatPayAPI:
    """微信支付API实现类"""
    
    def __init__(self, provider):
        """初始化微信支付API"""
        self.provider = provider
        # 当模式为'test'时使用测试模式
        self.test_mode = provider.state == 'test'
        
        # 设置API参数
        if self.test_mode:
            self.mch_id = provider.wechatpay_test_mch_id
            self.api_key = provider.wechatpay_test_api_key
            self.appid = provider.wechatpay_test_appid
            self.private_key = provider._get_private_key(test_mode=True)
            self.serial_no = provider.wechatpay_test_serial_no
        else:
            self.mch_id = provider.wechatpay_mch_id
            self.api_key = provider.wechatpay_api_key
            self.appid = provider.wechatpay_appid
            self.private_key = provider._get_private_key(test_mode=False)
            self.serial_no = provider.wechatpay_serial_no
        
        # API URLs (微信支付没有沙箱环境，只使用正式环境URL)
        self.native_url = WECHATPAY_API_URLS['native']
        self.query_url = WECHATPAY_API_URLS['query']
        self.close_url = WECHATPAY_API_URLS['close']
        self.refund_url = WECHATPAY_API_URLS['refund']
    
    def _generate_sign(self, url, method, body=None):
        """生成微信支付API签名"""
        # 测试模式下不需要生成实际签名
        if self.test_mode:
            return {
                'Authorization': 'TEST_MODE_AUTH',
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'User-Agent': 'PetHome-WeChat-Pay/1.0'
            }
            
        timestamp = str(int(time.time()))
        nonce_str = str(uuid.uuid4()).replace('-', '')
        
        # 构造签名串
        method = method.upper()
        canonical_url = urllib.parse.urlparse(url).path
        body_str = body if body else ''
        if isinstance(body_str, dict):
            body_str = json.dumps(body_str)
        
        message = method + "\n" + canonical_url + "\n" + timestamp + "\n" + nonce_str + "\n" + body_str + "\n"
        
        # 使用商户私钥签名
        try:
            signature = self.private_key.sign(
                message.encode('utf-8'),
                PKCS1v15(),
                SHA256()
            )
            sign_str = base64.b64encode(signature).decode('utf-8')
            
            # 构造 Authorization
            auth = f'WECHATPAY2-SHA256-RSA2048 mchid="{self.mch_id}",nonce_str="{nonce_str}",signature="{sign_str}",timestamp="{timestamp}",serial_no="{self.serial_no}"'
            return {
                'Authorization': auth,
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'User-Agent': 'PetHome-WeChat-Pay/1.0'
            }
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 生成签名异常: {str(e)}")
            return {}
    
    def native_pay(self, out_trade_no, amount, description, notify_url):
        """发起Native支付"""
        try:
            # 准备请求参数
            data = {
                "appid": self.appid,
                "mchid": self.mch_id,
                "description": description,
                "out_trade_no": out_trade_no,
                "notify_url": notify_url,
                "amount": {
                    "total": int(amount * 100),  # 转换为分
                    "currency": "CNY"
                }
            }
            
            # 测试模式下返回模拟数据
            if self.test_mode:
                _logger.info(f"[PetHome Payment WeChat Pay] 测试模式: Native支付 {out_trade_no}")
                return TEST_MODE_RESPONSES['native']['code_url']
            
            # 生成签名
            headers = self._generate_sign(self.native_url, 'POST', data)
            
            # 发送请求
            response = requests.post(
                self.native_url,
                json=data,
                headers=headers
            )
            
            # 处理响应
            result = response.json()
            _logger.info(f"[PetHome Payment WeChat Pay] Native支付响应: {result}")
            
            # 返回支付二维码链接
            if 'code_url' in result:
                return result['code_url']
            elif 'message' in result:
                raise UserError(_("微信支付下单失败: %s", result['message']))
            else:
                raise UserError(_("微信支付下单失败"))
                
        except requests.RequestException as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] Native支付请求异常: {str(e)}")
            raise UserError(_("微信支付下单失败: 网络请求异常"))
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] Native支付异常: {str(e)}")
            raise UserError(_("微信支付下单失败: %s", str(e)))
    
    def query_order(self, out_trade_no):
        """查询订单状态"""
        try:
            # 测试模式下返回模拟数据
            if self.test_mode:
                _logger.info(f"[PetHome Payment WeChat Pay] 测试模式: 查询订单 {out_trade_no}")
                response = TEST_MODE_RESPONSES['query'].copy()
                # 填充模板变量
                response['mchid'] = self.mch_id
                response['appid'] = self.appid
                response['out_trade_no'] = out_trade_no
                response['transaction_id'] = response['transaction_id'].format(timestamp=int(time.time()))
                response['success_time'] = datetime.now().strftime('%Y-%m-%dT%H:%M:%S+08:00')
                # 模拟金额，假设为1.00元
                response['amount']['total'] = 100
                response['amount']['payer_total'] = 100
                return response
            
            # 构造查询URL
            query_url = self.query_url.format(out_trade_no=out_trade_no)
            query_url += "?mchid=" + self.mch_id
            
            # 生成签名
            headers = self._generate_sign(query_url, 'GET')
            
            # 发送请求
            response = requests.get(
                query_url,
                headers=headers
            )
            
            # 处理响应
            result = response.json()
            _logger.info(f"[PetHome Payment WeChat Pay] 查询订单响应: {result}")
            
            return result
                
        except requests.RequestException as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 查询订单请求异常: {str(e)}")
            return None
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 查询订单异常: {str(e)}")
            return None
    
    def close_order(self, out_trade_no):
        """关闭订单"""
        try:
            # 测试模式下返回模拟数据
            if self.test_mode:
                _logger.info(f"[PetHome Payment WeChat Pay] 测试模式: 关闭订单 {out_trade_no}")
                return True
            
            # 构造关闭URL
            close_url = self.close_url.format(out_trade_no=out_trade_no)
            
            # 准备请求参数
            data = {
                "mchid": self.mch_id
            }
            
            # 生成签名
            headers = self._generate_sign(close_url, 'POST', data)
            
            # 发送请求
            response = requests.post(
                close_url,
                json=data,
                headers=headers
            )
            
            # 处理响应
            if response.status_code == 204:
                _logger.info(f"[PetHome Payment WeChat Pay] 关闭订单成功: {out_trade_no}")
                return True
            else:
                result = response.json()
                _logger.warning(f"[PetHome Payment WeChat Pay] 关闭订单失败: {result}")
                return False
                
        except requests.RequestException as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 关闭订单请求异常: {str(e)}")
            return False
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 关闭订单异常: {str(e)}")
            return False
    
    def refund(self, out_trade_no, out_refund_no, total, refund, reason=None):
        """申请退款"""
        try:
            # 准备请求参数
            data = {
                "out_trade_no": out_trade_no,
                "out_refund_no": out_refund_no,
                "reason": reason or "商品退款",
                "amount": {
                    "refund": int(refund * 100),  # 退款金额，单位为分
                    "total": int(total * 100),    # 订单总金额，单位为分
                    "currency": "CNY"
                }
            }
            
            # 如果有通知地址，添加通知URL
            cfg_obj = self.provider.env["ir.config_parameter"].sudo()
            base_url = cfg_obj.get_param("web.base.url")
            notify_url = f"{base_url}/payment/wechatpay/notify"
            data["notify_url"] = notify_url
            
            # 测试模式下返回模拟数据
            if self.test_mode:
                _logger.info(f"[PetHome Payment WeChat Pay] 测试模式: 申请退款 {out_refund_no}")
                response = TEST_MODE_RESPONSES['refund'].copy()
                # 填充模板变量
                timestamp = int(time.time())
                response['transaction_id'] = response['transaction_id'].format(timestamp=timestamp)
                response['refund_id'] = response['refund_id'].format(timestamp=timestamp)
                response['out_refund_no'] = out_refund_no
                response['out_trade_no'] = out_trade_no
                response['success_time'] = datetime.now().strftime('%Y-%m-%dT%H:%M:%S+08:00')
                response['create_time'] = datetime.now().strftime('%Y-%m-%dT%H:%M:%S+08:00')
                response['amount']['total'] = int(total * 100)
                response['amount']['refund'] = int(refund * 100)
                response['amount']['payer_total'] = int(total * 100)
                response['amount']['payer_refund'] = int(refund * 100)
                return True, response
            
            # 生成签名
            headers = self._generate_sign(self.refund_url, 'POST', data)
            
            # 发送请求
            response = requests.post(
                self.refund_url,
                json=data,
                headers=headers
            )
            
            # 处理响应
            result = response.json()
            _logger.info(f"[PetHome Payment WeChat Pay] 申请退款响应: {result}")
            
            if 'status' in result and result['status'] == 'SUCCESS':
                return True, result
            else:
                return False, result
                
        except requests.RequestException as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 申请退款请求异常: {str(e)}")
            return False, {'error': str(e)}
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 申请退款异常: {str(e)}")
            return False, {'error': str(e)}


class PaymentProvider(models.Model):
    _inherit = 'payment.provider'
    
    code = fields.Selection(
        selection_add=[("wechatpay", "WeChat Pay")], 
        ondelete={"wechatpay": "set default"}
    )
    
    # 微信支付基本配置
    wechatpay_appid = fields.Char("AppID", help="微信支付 AppID")
    wechatpay_mch_id = fields.Char("商户号", help="微信支付商户号")
    wechatpay_api_key = fields.Char("API密钥", help="微信支付 API V3密钥")
    wechatpay_serial_no = fields.Char("证书序列号", help="商户API证书序列号")
    wechatpay_private_key = fields.Binary("商户私钥", help="商户API私钥 (apiclient_key.pem)")
    wechatpay_cert = fields.Binary("商户证书", help="商户API证书 (apiclient_cert.pem)")
    
    # 测试模式配置 (微信支付没有沙箱环境，我们使用测试模式模拟)
    wechatpay_test_appid = fields.Char("测试 AppID", help="测试环境 AppID（可以使用与正式环境相同的值）")
    wechatpay_test_mch_id = fields.Char("测试商户号", help="测试环境商户号（可以使用与正式环境相同的值）")
    wechatpay_test_api_key = fields.Char("测试API密钥", help="测试环境 API V3密钥（可以使用与正式环境相同的值）")
    wechatpay_test_serial_no = fields.Char("测试证书序列号", help="测试环境商户API证书序列号（可以使用与正式环境相同的值）")
    wechatpay_test_private_key = fields.Binary("测试商户私钥", help="测试环境商户API私钥（可以使用与正式环境相同的值）")
    wechatpay_test_cert = fields.Binary("测试商户证书", help="测试环境商户API证书（可以使用与正式环境相同的值）")
    
    # 平台证书缓存字段（存储从微信支付平台获取的证书）
    wechatpay_platform_certs = fields.Text("平台证书缓存", help="微信支付平台证书缓存", copy=False)
    
    @api.model
    def _register_payment_methods(self):
        """注册支付方法（仅限微信支付方法）"""
        # 只创建或更新微信支付提供商
        provider = self.sudo().search([('code', '=', 'wechatpay')], limit=1)
        if not provider:
            values = {
                'name': 'WeChat Pay',
                'code': 'wechatpay',
                'company_id': self.env.ref('base.main_company').id,
                'state': 'disabled',
            }
            redirect_form = self.env.ref('pethome_payment_wechatpay.wechatpay_redirect_form', raise_if_not_found=False)
            if redirect_form:
                values['redirect_form_view_id'] = redirect_form.id
            
            provider = self.sudo().create(values)
            _logger.info(f"已创建 WeChat Pay 支付提供商 (ID: {provider.id})")
        else:
            _logger.info(f"已找到 WeChat Pay 支付提供商 (ID: {provider.id})")
        
        # 激活微信支付方法
        self._activate_payment_methods()
        
        return True
    
    def _get_wechatpay_api(self):
        """获取微信支付API"""
        if not DEPENDENCIES_INSTALLED:
            _logger.warning(
                "WeChat Pay 依赖库未安装。"
                "请安装必要的依赖: pip install pycryptodome requests cryptography"
            )
        
        return WeChatPayAPI(self)
    
    def _get_private_key(self, test_mode=False):
        """获取商户API私钥对象"""
        try:
            # 获取私钥数据
            if test_mode:
                private_key_data = self.wechatpay_test_private_key
                if not private_key_data:
                    _logger.info("[PetHome Payment WeChat Pay] 测试模式：未配置测试环境私钥，尝试使用正式环境私钥")
                    private_key_data = self.wechatpay_private_key
            else:
                private_key_data = self.wechatpay_private_key
                
            if not private_key_data:
                _logger.error(f"[PetHome Payment WeChat Pay] {'测试' if test_mode else '正式'}环境未配置商户私钥")
                return None
                
            # 解码Base64编码的私钥数据
            private_key_pem = base64.b64decode(private_key_data).decode('utf-8')
            
            # 加载私钥对象
            private_key = serialization.load_pem_private_key(
                private_key_pem.encode('utf-8'),
                password=None
            )
            
            return private_key
            
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 加载私钥失败: {str(e)}")
            return None
    
    def _get_platform_cert(self, serial_no):
        """获取微信支付平台证书"""
        try:
            # 测试模式下返回测试证书
            if self.state == 'test':
                _logger.info(f"[PetHome Payment WeChat Pay] 测试模式：使用模拟平台证书")
                # 返回模拟证书数据
                return "TEST_MODE_CERTIFICATE"
                
            # 尝试从缓存获取证书
            certs_cache = {}
            if self.wechatpay_platform_certs:
                certs_cache = json.loads(self.wechatpay_platform_certs)
                
            # 如果找到缓存的证书，直接返回
            if serial_no in certs_cache:
                return certs_cache[serial_no]
                
            # 如果未找到缓存的证书，返回None
            _logger.warning(f"[PetHome Payment WeChat Pay] 未找到序列号为 {serial_no} 的平台证书")
            return None
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 获取平台证书异常: {str(e)}")
            return None
    
    def _decrypt_resource(self, resource):
        """解密微信支付通知资源数据"""
        try:
            # 测试模式下使用模拟数据
            if self.state == 'test':
                _logger.info(f"[PetHome Payment WeChat Pay] 测试模式：使用模拟解密数据")
                # 返回模拟解密后的数据
                return {
                    'mchid': self.wechatpay_test_mch_id or 'test_mch_id',
                    'appid': self.wechatpay_test_appid or 'test_appid',
                    'out_trade_no': resource.get('out_trade_no', f'test_order_{int(time.time())}'),
                    'transaction_id': f'test_transaction_id_{int(time.time())}',
                    'trade_type': 'NATIVE',
                    'trade_state': 'SUCCESS',
                    'trade_state_desc': '支付成功',
                    'success_time': datetime.now().strftime('%Y-%m-%dT%H:%M:%S+08:00'),
                    'amount': {
                        'total': 100,  # 1元人民币
                        'currency': 'CNY'
                    }
                }
            
            # 获取加密信息
            algorithm = resource.get('algorithm')
            ciphertext = resource.get('ciphertext')
            associated_data = resource.get('associated_data', '')
            nonce = resource.get('nonce')
            
            if algorithm != 'AEAD_AES_256_GCM':
                _logger.error(f"[PetHome Payment WeChat Pay] 不支持的加密算法: {algorithm}")
                return {}
                
            # 获取API密钥
            api_key = self.wechatpay_api_key
            if not api_key:
                _logger.error("[PetHome Payment WeChat Pay] 未配置API密钥")
                return {}
                
            # 解密
            key_bytes = api_key.encode('utf-8')
            nonce_bytes = nonce.encode('utf-8')
            ad_bytes = associated_data.encode('utf-8') if associated_data else b''
            ciphertext_bytes = base64.b64decode(ciphertext)
            
            aes_gcm = AESGCM(key_bytes)
            plaintext_bytes = aes_gcm.decrypt(nonce_bytes, ciphertext_bytes, ad_bytes)
            
            # 解析JSON
            plaintext = plaintext_bytes.decode('utf-8')
            result = json.loads(plaintext)
            
            return result
            
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 解密资源数据异常: {str(e)}")
            return {}
    
    def _wechatpay_create_transaction(self, amount, reference):
        """创建微信支付交易并获取支付二维码URL"""
        try:
            if amount <= 0:
                raise UserError(_("支付金额必须大于0"))
                
            # 获取微信支付API
            wechatpay_api = self._get_wechatpay_api()
            
            # 设置异步通知URL
            cfg_obj = self.env["ir.config_parameter"].sudo()
            base_url = cfg_obj.get_param("web.base.url")
            notify_url = f"{base_url}/payment/wechatpay/notify"
            
            # 发起Native支付
            code_url = wechatpay_api.native_pay(
                out_trade_no=reference,
                amount=amount,
                description=f"订单 {reference}",
                notify_url=notify_url
            )
            
            return code_url
            
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 创建支付交易异常: {str(e)}")
            raise UserError(_("创建微信支付交易失败: %s", str(e)))
    
    def _get_supported_currencies(self):
        """返回支持的货币"""
        supported_currencies = super()._get_supported_currencies()
        if self.code == "wechatpay":
            supported_currencies = supported_currencies.filtered(
                lambda c: c.name in SUPPORTED_CURRENCIES
            )
        return supported_currencies

    def _get_default_payment_method_codes(self):
        """返回默认支付方式代码"""
        default_codes = super()._get_default_payment_method_codes()
        if self.code != "wechatpay":
            return default_codes
        return DEFAULT_PAYMENT_METHODS_CODES

    @api.model
    def _get_compatible_payment_methods(self):
        """获取兼容的支付方式"""
        compatible_methods = super()._get_compatible_payment_methods()
        if self.code == 'wechatpay':
            # 添加WeChat Pay支付方法
            wechatpay_method = self.env.ref('pethome_payment_wechatpay.payment_method_wechatpay', raise_if_not_found=False)
            if wechatpay_method and wechatpay_method.id not in compatible_methods.ids:
                compatible_methods |= wechatpay_method
                _logger.info(f"已添加 WeChat Pay 支付方法 (ID: {wechatpay_method.id}) 到兼容方法列表")
        return compatible_methods
        
    @api.model
    def _activate_payment_methods(self):
        """激活支付方法（仅限微信支付方法）"""
        # 只处理微信支付相关的方法，避免影响其他支付插件
        wechatpay_methods = self.env['payment.method'].search([('code', '=', 'wechatpay')])
        if wechatpay_methods:
            wechatpay_methods.write({'active': True})
            _logger.info(f"已激活 {len(wechatpay_methods)} 个 WeChat Pay 支付方法")
        
        # 确保方法关联到提供商，但只处理微信支付提供商
        wechatpay_provider = self.search([('code', '=', 'wechatpay')], limit=1)
        if wechatpay_provider and wechatpay_methods:
            for method in wechatpay_methods:
                if method.id not in wechatpay_provider.payment_method_ids.ids:
                    wechatpay_provider.write({
                        'payment_method_ids': [(4, method.id)]
                    })
                    _logger.info(f"已将支付方法 '{method.name}' 关联到提供商 '{wechatpay_provider.name}'")
        
        return True

    def write(self, vals):
        """重写write方法，确保在状态变更后激活支付方法（仅限微信支付提供商）"""
        result = super().write(vals)
        # 只处理微信支付提供商的状态变更
        if 'state' in vals and vals['state'] in ['enabled', 'test'] and self.filtered(lambda p: p.code == 'wechatpay'):
            self._activate_payment_methods()
        return result 