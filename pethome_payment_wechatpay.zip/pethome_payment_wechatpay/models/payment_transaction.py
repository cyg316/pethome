# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.http import request
from odoo.exceptions import ValidationError
import logging
import json
import time
import base64
from io import BytesIO
from datetime import datetime

_logger = logging.getLogger(__name__)

# 检查qrcode依赖库
QR_DEPENDENCIES_INSTALLED = True
try:
    import qrcode
    from PIL import Image
except ImportError as e:
    QR_DEPENDENCIES_INSTALLED = False
    _logger.warning(f"WeChat Pay 二维码依赖库缺失: {e.name}。请安装完整依赖: pip install qrcode Pillow")

class TxWeChatPay(models.Model):
    _inherit = 'payment.transaction'

    wechatpay_txn_type = fields.Char('WeChat Pay Transaction Type')
    wechatpay_qrcode = fields.Binary('WeChat Pay QR Code', attachment=True, readonly=True)
    wechatpay_qrcode_url = fields.Char('WeChat Pay QR Code URL', readonly=True)

    def _get_specific_rendering_values(self, processing_values):
        res = super()._get_specific_rendering_values(processing_values)
        if self.provider_code != 'wechatpay':
            return res
        _logger.info(f"[WeChatPay] _get_specific_rendering_values for {self.reference}: {res}")
        # 关键修复：强制将交易状态设为 pending
        self._set_pending()
        return {
            'type': 'redirect',
            'redirect_url': '/payment/wechatpay/qrcode?reference=%s' % self.reference,
        }

    def _get_tx_from_notification_data(self, provider_code, notification_data):
        """
        从通知数据中获取交易记录
        """
        tx = super()._get_tx_from_notification_data(provider_code, notification_data)
        if provider_code != 'wechatpay' or len(tx) == 1:
            return tx
        
        reference = notification_data.get('out_trade_no')
        if not reference:
            raise ValidationError(
                "WeChat Pay: " + _("No transaction reference found in notification data.")
            )
            
        tx = self.search([('reference', '=', reference), ('provider_code', '=', 'wechatpay')])
        if not tx:
            raise ValidationError(
                "WeChat Pay: " + _("No transaction found matching reference %s.", reference)
            )
        return tx
    
    def _process_notification_data(self, notification_data):
        """
        处理微信支付通知数据
        """
        super()._process_notification_data(notification_data)
        if self.provider_code != 'wechatpay':
            return
        
        if not notification_data:
            self._set_canceled(_("The customer left the payment page."))
            return
        
        try:
            # 检查交易状态
            trade_state = notification_data.get('trade_state')
            transaction_id = notification_data.get('transaction_id')
            
            # 测试模式下记录更详细的日志
            if self.provider_id.state == 'test':
                _logger.info(f"[PetHome Payment WeChat Pay] 测试模式处理通知数据: {notification_data}")
            
            if trade_state == 'SUCCESS':
                _logger.info(f"[PetHome Payment WeChat Pay] 支付成功: {self.reference}")
                self.provider_reference = transaction_id
                self._set_done()
                self._finalize_post_processing()
                return
                
            elif trade_state == 'REFUND':
                _logger.info(f"[PetHome Payment WeChat Pay] 交易已退款: {self.reference}")
                self._set_canceled(_("Transaction has been refunded."))
                return
                
            elif trade_state == 'NOTPAY' or trade_state == 'USERPAYING':
                _logger.info(f"[PetHome Payment WeChat Pay] 等待支付: {self.reference}")
                self._set_pending()
                return
                
            elif trade_state == 'CLOSED':
                _logger.info(f"[PetHome Payment WeChat Pay] 交易已关闭: {self.reference}")
                self._set_canceled(_("Transaction has been closed."))
                return
                
            elif trade_state == 'REVOKED':
                _logger.info(f"[PetHome Payment WeChat Pay] 交易已撤销: {self.reference}")
                self._set_canceled(_("Transaction has been revoked."))
                return
                
            elif trade_state == 'PAYERROR':
                _logger.info(f"[PetHome Payment WeChat Pay] 支付失败: {self.reference}")
                self._set_error(_("Payment failed."))
                return
                
            else:
                # 查询订单状态
                payment = self.env["payment.provider"].sudo().search([('code', '=', 'wechatpay')], limit=1)
                wechatpay_api = payment._get_wechatpay_api()
                
                # 测试模式下模拟查询结果
                if payment.state == 'test':
                    _logger.info(f"[PetHome Payment WeChat Pay] 测试模式: 模拟查询订单 {self.reference}")
                    order_result = {
                        'trade_state': 'SUCCESS',
                        'transaction_id': f'test_transaction_id_{int(time.time())}',
                        'out_trade_no': self.reference,
                        'success_time': datetime.now().strftime('%Y-%m-%dT%H:%M:%S+08:00'),
                    }
                else:
                    order_result = wechatpay_api.query_order(self.reference)
                
                if order_result and 'trade_state' in order_result:
                    trade_state = order_result['trade_state']
                    transaction_id = order_result.get('transaction_id')
                    
                    if trade_state == 'SUCCESS':
                        _logger.info(f"[PetHome Payment WeChat Pay] 查询支付成功: {self.reference}")
                        self.provider_reference = transaction_id
                        self._set_done()
                        self._finalize_post_processing()
                    elif trade_state == 'REFUND':
                        _logger.info(f"[PetHome Payment WeChat Pay] 查询交易已退款: {self.reference}")
                        self._set_canceled(_("Transaction has been refunded."))
                    elif trade_state == 'NOTPAY' or trade_state == 'USERPAYING':
                        _logger.info(f"[PetHome Payment WeChat Pay] 查询等待支付: {self.reference}")
                        self._set_pending()
                    elif trade_state == 'CLOSED':
                        _logger.info(f"[PetHome Payment WeChat Pay] 查询交易已关闭: {self.reference}")
                        self._set_canceled(_("Transaction has been closed."))
                    elif trade_state == 'REVOKED':
                        _logger.info(f"[PetHome Payment WeChat Pay] 查询交易已撤销: {self.reference}")
                        self._set_canceled(_("Transaction has been revoked."))
                    elif trade_state == 'PAYERROR':
                        _logger.info(f"[PetHome Payment WeChat Pay] 查询支付失败: {self.reference}")
                        self._set_error(_("Payment failed."))
                    else:
                        _logger.warning(f"[PetHome Payment WeChat Pay] 查询未知交易状态: {self.reference}, {trade_state}")
                        self._set_pending()
                else:
                    _logger.warning(f"[PetHome Payment WeChat Pay] 查询订单失败: {self.reference}")
                    # 保持当前状态不变
        
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 处理通知数据异常: {str(e)}")
    
    def _get_post_processing_values(self):
        """获取后处理值"""
        values = super()._get_post_processing_values()
        if self.provider_code == 'wechatpay':
            # 可以在这里添加微信支付特定的后处理值
            pass
        return values
    
    def action_wechatpay_check_status(self):
        """手动检查微信支付状态"""
        self.ensure_one()
        if self.provider_code != 'wechatpay':
            return
            
        try:
            # 查询订单状态
            payment = self.env["payment.provider"].sudo().search([('code', '=', 'wechatpay')], limit=1)
            wechatpay_api = payment._get_wechatpay_api()
            
            # 测试模式模拟查询结果
            if payment.state == 'test':
                _logger.info(f"[PetHome Payment WeChat Pay] 测试模式: 手动检查订单状态 {self.reference}")
                order_result = {
                    'trade_state': 'SUCCESS',
                    'transaction_id': f'test_transaction_id_{int(time.time())}',
                    'out_trade_no': self.reference,
                    'success_time': datetime.now().strftime('%Y-%m-%dT%H:%M:%S+08:00'),
                }
            else:
                order_result = wechatpay_api.query_order(self.reference)
            
            if order_result and 'trade_state' in order_result:
                # 使用通知数据处理状态
                self._process_notification_data(order_result)
                
                # 返回消息
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Payment Status'),
                        'message': _('Payment status has been updated.'),
                        'sticky': False,
                        'type': 'success',
                    }
                }
            else:
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Payment Status'),
                        'message': _('Failed to check payment status.'),
                        'sticky': False,
                        'type': 'warning',
                    }
                }
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 检查支付状态异常: {str(e)}")
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Error'),
                    'message': _('Failed to check payment status: %s', str(e)),
                    'sticky': False,
                    'type': 'danger',
                }
            }
    
    def action_wechatpay_close_order(self):
        """手动关闭微信支付订单"""
        self.ensure_one()
        if self.provider_code != 'wechatpay':
            return
            
        try:
            # 查询订单状态
            payment = self.env["payment.provider"].sudo().search([('code', '=', 'wechatpay')], limit=1)
            wechatpay_api = payment._get_wechatpay_api()
            
            # 测试模式下模拟操作
            if payment.state == 'test':
                _logger.info(f"[PetHome Payment WeChat Pay] 测试模式: 关闭订单 {self.reference}")
                order_result = {
                    'trade_state': 'NOTPAY',
                    'out_trade_no': self.reference,
                }
                close_result = True
            else:
                # 先检查订单状态
                order_result = wechatpay_api.query_order(self.reference)
            
            if order_result and 'trade_state' in order_result:
                trade_state = order_result['trade_state']
                
                if trade_state in ['SUCCESS', 'REFUND']:
                    return {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Warning'),
                            'message': _('Cannot close a paid or refunded order.'),
                            'sticky': False,
                            'type': 'warning',
                        }
                    }
                
                # 正常模式关闭订单，测试模式已在上面模拟
                if payment.state != 'test':
                    close_result = wechatpay_api.close_order(self.reference)
                
                if close_result:
                    # 更新状态
                    self._set_canceled(_("Transaction has been closed."))
                    
                    return {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Success'),
                            'message': _('Order has been closed successfully.'),
                            'sticky': False,
                            'type': 'success',
                        }
                    }
                else:
                    return {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                        'title': _('Warning'),
                        'message': _('Failed to close the order.'),
                        'sticky': False,
                        'type': 'warning',
                        }
                    }
            else:
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Warning'),
                        'message': _('Failed to check order status before closing.'),
                        'sticky': False,
                        'type': 'warning',
                    }
                }
                
        except Exception as e:
            _logger.exception(f"[PetHome Payment WeChat Pay] 关闭订单异常: {str(e)}")
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Error'),
                    'message': _('Failed to close order: %s', str(e)),
                    'sticky': False,
                    'type': 'danger',
                }
            }