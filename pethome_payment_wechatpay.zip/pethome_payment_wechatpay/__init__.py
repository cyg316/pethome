# -*- coding: utf-8 -*-

import logging
_logger = logging.getLogger(__name__)

_logger.info("正在加载微信支付模块...")

from . import controllers
from . import models

from odoo.addons.payment import setup_provider, reset_payment_provider

def post_init_hook(env):
    """
    初始化钩子 - 在模块安装完成后运行
    此函数只处理微信支付相关的初始化工作，不会影响其他支付方式
    """
    _logger.info("执行微信支付模块安装后钩子...")
    
    try:
        # 只处理微信支付相关的初始化
        provider_model = env['payment.provider'].sudo()
        # 注册微信支付方法
        register_method = getattr(provider_model, '_register_payment_methods', None)
        if register_method and callable(register_method):
            provider_model._register_payment_methods()
            
        # 查找微信支付提供商
        wechatpay_provider = provider_model.search([('code', '=', 'wechatpay')], limit=1)
        if wechatpay_provider:
            # 激活微信支付方法
            wechatpay_methods = env['payment.method'].sudo().search([('code', '=', 'wechatpay')])
            if wechatpay_methods:
                wechatpay_methods.write({'active': True})
                _logger.info(f"已激活 {len(wechatpay_methods)} 个 WeChat Pay 支付方法")
                
                # 确保方法关联到提供商
                for method in wechatpay_methods:
                    if method.id not in wechatpay_provider.payment_method_ids.ids:
                        wechatpay_provider.write({
                            'payment_method_ids': [(4, method.id)]
                        })
                        _logger.info(f"已将支付方法 '{method.name}' 关联到提供商 '{wechatpay_provider.name}'")
            
        _logger.info("微信支付模块安装完成")
    except Exception as e:
        _logger.error(f"微信支付模块安装钩子执行失败: {str(e)}")

def uninstall_hook(cr, registry):
    """
    卸载钩子 - 在模块卸载时运行
    此函数只处理微信支付相关的卸载工作，不会影响其他支付方式
    """
    _logger.info("执行微信支付模块卸载钩子...")
    
    try:
        from odoo.api import Environment
        with Environment.manage():
            env = Environment(cr, registry)
            # 只重置微信支付提供商
            reset_payment_provider(env, 'wechatpay')
        
        _logger.info("微信支付模块卸载完成")
    except Exception as e:
        _logger.error(f"微信支付模块卸载钩子执行失败: {str(e)}") 