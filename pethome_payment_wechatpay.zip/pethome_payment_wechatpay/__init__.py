# -*- coding: utf-8 -*-

import logging
_logger = logging.getLogger(__name__)

_logger.info("正在加载微信支付模块...")

from . import controllers
from . import models

from odoo.addons.payment import reset_payment_provider

def post_init_hook(env):
    """
    安装后钩子，确保微信支付 provider 启用，method 激活
    """
    _logger.info("执行微信支付模块安装后钩子...")
    try:
        provider = env['payment.provider'].sudo().search([('code', '=', 'wechatpay')], limit=1)
        if provider:
            provider.write({'state': 'enabled'})
            _logger.info("已启用微信支付 provider")
        method = env['payment.method'].sudo().search([('code', '=', 'wechatpay')], limit=1)
        if method:
            method.write({'active': True})
            _logger.info("已激活微信支付 payment.method")
    except Exception as e:
        _logger.error(f"微信支付 post_init_hook 执行失败: {str(e)}")

def uninstall_hook(env):
    """
    卸载钩子 - 在模块卸载时运行
    此函数只处理微信支付相关的卸载工作，不会影响其他支付方式
    """
    _logger.info("执行微信支付模块卸载钩子...")
    try:
        from odoo.addons.payment import reset_payment_provider
        reset_payment_provider(env, 'wechatpay')
        _logger.info("微信支付模块卸载完成")
    except Exception as e:
        _logger.error(f"微信支付模块卸载钩子执行失败: {str(e)}")