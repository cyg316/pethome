# -*- coding: utf-8 -*-
{
    'name': 'Payment WeChat Pay',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Payment Providers',
    'sequence': 351,
    'summary': '使用微信支付处理付款',
    'description': """
        使用微信支付处理付款，支持扫码支付和APP支付。
    """,
    'author': "OdooMaster PetHome Technology",
    'website': "https://www.catlover.cn",
    'depends': ['payment'],
    'external_dependencies': {
        'python': ['pycryptodome', 'requests', 'cryptography', 'qrcode', 'Pillow'],
    },
    'data': [
        'security/ir.model.access.csv',
        'security/data.xml',
        'views/payment_templates.xml',
        'views/payment_provider_views.xml',
        'views/transaction_views.xml',
        'views/payment_wechatpay_templates.xml',
        'data/payment_provider_data.xml',
    ],
    'assets': {
        'web.assets_common': [
            'pethome_payment_wechatpay/static/src/css/payment_wechatpay.css',
            'pethome_payment_wechatpay/static/src/js/payment_wechatpay.js',
            'pethome_payment_wechatpay/static/src/xml/payment_wechatpay.xml',
        ],
        'web.assets_backend': [
            'pethome_payment_wechatpay/static/src/img/wechatpay.png',
        ],
    },
    'demo': [],
    'images': ['static/description/icon.png'],
    'installable': True,
    'application': False,
    'post_init_hook': 'post_init_hook',
    'uninstall_hook': 'uninstall_hook',
    'auto_install': False,
    'license': 'LGPL-3',
} 