# -*- coding: utf-8 -*-
{
    'name': 'Payment WeChat Pay',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Payment Acquirers',
    'sequence': 351,
    'summary': 'Payment Acquirer: WeChat Pay Implementation',
    'description': """
        WeChat Pay Payment Acquirer for Odoo.
        This module implements the WeChat Pay payment gateway.
    """,
    'author': "OdooMaster PetHome Technology",
    'website': "https://www.catlover.cn",
    'depends': ['payment'],
    'external_dependencies': {
        'python': ['pycryptodome', 'requests', 'cryptography', 'qrcode', 'Pillow'],
    },
    'data': [
        'security/ir.model.access.csv',
        'security/data.xml',
        'views/payment_provider_views.xml',
        'views/transaction_views.xml',
        'views/payment_templates.xml',
        'data/payment_provider_data.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'pethome_payment_wechatpay/static/src/img/wechatpay.png',
            'pethome_payment_wechatpay/static/src/js/wechatpay.js',
        ],
    },
    'demo': [],
    'images': [
        'static/src/img/wechatpay.png',
    ],
    'installable': True,
    'application': True,
    'post_init_hook': 'post_init_hook',
    'uninstall_hook': 'uninstall_hook',
    'license': 'LGPL-3',
} 