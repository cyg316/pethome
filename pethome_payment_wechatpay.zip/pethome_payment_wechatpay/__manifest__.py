# -*- coding: utf-8 -*-
{
    'name': 'Payment WeChat Pay',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Payment Acquirers',
    'sequence': 351,
    'summary': 'Payment Acquirer: WeChat Pay Implementation',
    'description': """
        WeChat Pay Payment Acquirer for Odoo.
        This module implements the WeChat Pay payment gateway.
    """,
    'author': "OdooMaster PetHome Technology",
    'website': "https://www.catlover.cn",
    'depends': ['payment'],
    'external_dependencies': {
        'python': ['pycryptodome', 'requests', 'cryptography', 'qrcode', 'Pillow'],
    },
    'data': [
        'security/ir.model.access.csv',
        'security/data.xml',
        'views/templates.xml',
        'views/views.xml',
        'data/payment_provider_data.xml',
    ],
    'demo': [],
    'images': [
        'static/src/img/wechatpay.png',
    ],
    'installable': True,
    'application': True,
    'post_init_hook': 'post_init_hook',
    'uninstall_hook': 'uninstall_hook',
    'license': 'LGPL-3',
} 